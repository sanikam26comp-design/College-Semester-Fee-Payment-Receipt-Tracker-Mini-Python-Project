import tkinter as tk
from tkinter import messagebox, filedialog
import sqlite3


# ==========================================================
# OPTIONAL PDF / WORD LIBRARIES
# ==========================================================

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.lib import colors
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False


try:
    from docx import Document
    from docx.shared import Pt
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    WORD_AVAILABLE = True
except ImportError:
    WORD_AVAILABLE = False


# ==========================================================
# DATABASE
# ==========================================================

DB_NAME = "college_fee_tracker.db"


def get_connection():
    return sqlite3.connect(DB_NAME)


# ==========================================================
# STUDENT DASHBOARD
# ==========================================================

def open_student_dashboard(parent=None, student_id=None, student_name=None):

    if student_id is None:
        messagebox.showerror(
            "Student Error",
            "Student ID was not provided."
        )
        return

    # ======================================================
    # WINDOW
    # ======================================================

    if parent is not None:
        window = tk.Toplevel(parent)
        parent.withdraw()
    else:
        window = tk.Tk()

    window.title("College Fee Tracker - Student Dashboard")

    try:
        window.state("zoomed")
    except tk.TclError:
        window.geometry("1400x800")

    window.configure(
        bg="#F3F7FB"
    )

    # ======================================================
    # COLORS
    # ======================================================

    SIDEBAR = "#174A70"
    SIDEBAR_ACTIVE = "#276D96"
    SIDEBAR_HOVER = "#205F87"

    WHITE = "#FFFFFF"
    LIGHT_BG = "#F3F7FB"

    TEXT = "#1F2937"
    GRAY = "#6B7280"

    BORDER = "#C7D5DF"
    TABLE_BORDER = "#B8C7D1"

    HEADER_BG = "#174A70"
    HEADER_TEXT = "#FFFFFF"

    ROW_1 = "#FFFFFF"
    ROW_2 = "#F7FAFC"

    GREEN = "#2E7D32"
    GREEN_HOVER = "#256628"

    BLUE = "#1976D2"
    BLUE_HOVER = "#125EAA"

    RED = "#D32F2F"
    RED_HOVER = "#B71C1C"

    # ======================================================
    # GET STUDENT DETAILS
    # ======================================================

    student = None
    conn = None

    try:

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT
                student_id,
                name,
                username,
                course,
                department,
                semester,
                academic_year,
                contact
            FROM students
            WHERE student_id = ?
            """,
            (student_id,)
        )

        student = cursor.fetchone()

    except sqlite3.Error as e:

        messagebox.showerror(
            "Database Error",
            "Could not load student information.\n\n" + str(e),
            parent=window
        )

        window.destroy()
        return

    finally:

        if conn:
            conn.close()

    # ======================================================
    # STUDENT NOT FOUND
    # ======================================================

    if student is None:

        messagebox.showerror(
            "Student Not Found",
            "Student record could not be found.",
            parent=window
        )

        window.destroy()
        return

    # ======================================================
    # STUDENT VARIABLES
    # ======================================================

    student_id = student[0]
    student_name = student[1] or "Student"
    username = student[2] or "N/A"
    course = student[3] or "N/A"
    department = student[4] or "N/A"
    semester = student[5] if student[5] is not None else "N/A"
    academic_year = student[6] or "N/A"
    contact = student[7] or "N/A"

    # ======================================================
    # MAIN FRAME
    # ======================================================

    main_frame = tk.Frame(
        window,
        bg=LIGHT_BG
    )

    main_frame.pack(
        fill="both",
        expand=True
    )

    # ======================================================
    # SIDEBAR
    # ======================================================

    sidebar = tk.Frame(
        main_frame,
        bg=SIDEBAR,
        width=290
    )

    sidebar.pack(
        side="left",
        fill="y"
    )

    sidebar.pack_propagate(False)

    # ======================================================
    # SIDEBAR LOGO
    # ======================================================

    tk.Label(
        sidebar,
        text="🎓",
        font=("Segoe UI Emoji", 40),
        bg=SIDEBAR,
        fg=WHITE
    ).pack(
        pady=(35, 5)
    )

    tk.Label(
        sidebar,
        text="College Fee Tracker",
        font=("Arial", 20, "bold"),
        bg=SIDEBAR,
        fg=WHITE
    ).pack()

    tk.Label(
        sidebar,
        text="STUDENT PANEL",
        font=("Arial", 10, "bold"),
        bg=SIDEBAR,
        fg="#B9D4E8"
    ).pack(
        pady=(25, 20)
    )

    # ======================================================
    # CONTENT
    # ======================================================

    content = tk.Frame(
        main_frame,
        bg=LIGHT_BG
    )

    content.pack(
        side="left",
        fill="both",
        expand=True
    )

    page_container = tk.Frame(
        content,
        bg=LIGHT_BG
    )

    page_container.pack(
        fill="both",
        expand=True
    )

    # ======================================================
    # CLEAR PAGE
    # ======================================================

    def clear_page():

        for widget in page_container.winfo_children():
            widget.destroy()

    # ======================================================
    # HEADER
    # ======================================================

    def create_header(title, subtitle):

        header = tk.Frame(
            page_container,
            bg=WHITE,
            height=110,
            highlightbackground=BORDER,
            highlightthickness=1
        )

        header.pack(
            fill="x"
        )

        header.pack_propagate(False)

        # --------------------------------------------------
        # LEFT
        # --------------------------------------------------

        left = tk.Frame(
            header,
            bg=WHITE
        )

        left.pack(
            side="left",
            padx=40,
            pady=18
        )

        tk.Label(
            left,
            text=title,
            font=("Arial", 28, "bold"),
            fg=TEXT,
            bg=WHITE
        ).pack(
            anchor="w"
        )

        tk.Label(
            left,
            text=subtitle,
            font=("Arial", 11),
            fg="#78909C",
            bg=WHITE
        ).pack(
            anchor="w",
            pady=(3, 0)
        )

        # --------------------------------------------------
        # STUDENT NAME
        # --------------------------------------------------

        tk.Label(
            header,
            text="👤   " + str(student_name),
            font=("Arial", 12, "bold"),
            fg=TEXT,
            bg=WHITE
        ).pack(
            side="right",
            padx=40
        )

    # ======================================================
    # BORDERED TABLE
    # ======================================================

    def create_table(
        parent_widget,
        headers,
        rows,
        column_widths=None,
        header_height=40,
        row_height=42
    ):

        table_wrapper = tk.Frame(
            parent_widget,
            bg=TABLE_BORDER
        )

        table_wrapper.pack(
            fill="x",
            padx=18,
            pady=10
        )

        table = tk.Frame(
            table_wrapper,
            bg=TABLE_BORDER
        )

        table.pack(
            fill="x"
        )

        number_of_columns = len(headers)

        if column_widths is None:
            column_widths = [180] * number_of_columns

        # --------------------------------------------------
        # COLUMN CONFIGURATION
        # --------------------------------------------------

        for column in range(number_of_columns):

            table.columnconfigure(
                column,
                weight=1
            )

        # --------------------------------------------------
        # HEADER
        # --------------------------------------------------

        for column, heading in enumerate(headers):

            cell = tk.Frame(
                table,
                bg=HEADER_BG,
                height=header_height,
                highlightbackground=TABLE_BORDER,
                highlightthickness=1
            )

            cell.grid(
                row=0,
                column=column,
                sticky="nsew"
            )

            cell.grid_propagate(False)

            tk.Label(
                cell,
                text=heading,
                font=("Arial", 10, "bold"),
                fg=HEADER_TEXT,
                bg=HEADER_BG
            ).pack(
                fill="both",
                expand=True,
                padx=5
            )

        # --------------------------------------------------
        # DATA
        # --------------------------------------------------

        if rows:

            for row_number, row_data in enumerate(rows, start=1):

                row_bg = (
                    ROW_1
                    if row_number % 2
                    else ROW_2
                )

                for column, value in enumerate(row_data):

                    cell = tk.Frame(
                        table,
                        bg=row_bg,
                        height=row_height,
                        highlightbackground=TABLE_BORDER,
                        highlightthickness=1
                    )

                    cell.grid(
                        row=row_number,
                        column=column,
                        sticky="nsew"
                    )

                    cell.grid_propagate(False)

                    tk.Label(
                        cell,
                        text=str(value),
                        font=("Arial", 10),
                        fg=TEXT,
                        bg=row_bg
                    ).pack(
                        fill="both",
                        expand=True,
                        padx=6
                    )

        else:

            empty = tk.Frame(
                table,
                bg=WHITE,
                height=55,
                highlightbackground=TABLE_BORDER,
                highlightthickness=1
            )

            empty.grid(
                row=1,
                column=0,
                columnspan=number_of_columns,
                sticky="nsew"
            )

            empty.grid_propagate(False)

            tk.Label(
                empty,
                text="No records found.",
                font=("Arial", 10),
                fg=GRAY,
                bg=WHITE
            ).pack(
                fill="both",
                expand=True
            )

        return table_wrapper

    # ======================================================
    # SCROLLABLE TABLE
    # ======================================================

    def create_scroll_table(
        parent_widget,
        headers,
        rows,
        column_widths
    ):

        outer = tk.Frame(
            parent_widget,
            bg=WHITE
        )

        outer.pack(
            fill="both",
            expand=True,
            padx=18,
            pady=(5, 18)
        )

        # --------------------------------------------------
        # CANVAS
        # --------------------------------------------------

        canvas = tk.Canvas(
            outer,
            bg=WHITE,
            highlightthickness=0
        )

        scrollbar = tk.Scrollbar(
            outer,
            orient="vertical",
            command=canvas.yview
        )

        canvas.configure(
            yscrollcommand=scrollbar.set
        )

        scrollbar.pack(
            side="right",
            fill="y"
        )

        canvas.pack(
            side="left",
            fill="both",
            expand=True
        )

        # --------------------------------------------------
        # TABLE FRAME
        # --------------------------------------------------

        table_frame = tk.Frame(
            canvas,
            bg=TABLE_BORDER
        )

        canvas_window = canvas.create_window(
            (0, 0),
            window=table_frame,
            anchor="nw"
        )

        def update_scroll(event=None):

            canvas.configure(
                scrollregion=canvas.bbox("all")
            )

        table_frame.bind(
            "<Configure>",
            update_scroll
        )

        def resize_table(event):

            canvas.itemconfig(
                canvas_window,
                width=event.width
            )

        canvas.bind(
            "<Configure>",
            resize_table
        )

        number_of_columns = len(headers)

        for column in range(number_of_columns):

            table_frame.columnconfigure(
                column,
                weight=1
            )

        # --------------------------------------------------
        # HEADER
        # --------------------------------------------------

        for column, heading in enumerate(headers):

            cell = tk.Frame(
                table_frame,
                bg=HEADER_BG,
                height=42,
                highlightbackground=TABLE_BORDER,
                highlightthickness=1
            )

            cell.grid(
                row=0,
                column=column,
                sticky="nsew"
            )

            cell.grid_propagate(False)

            tk.Label(
                cell,
                text=heading,
                font=("Arial", 10, "bold"),
                fg=HEADER_TEXT,
                bg=HEADER_BG
            ).pack(
                fill="both",
                expand=True,
                padx=5
            )

        # --------------------------------------------------
        # DATA ROWS
        # --------------------------------------------------

        if rows:

            for row_number, row_data in enumerate(rows, start=1):

                row_bg = (
                    ROW_1
                    if row_number % 2
                    else ROW_2
                )

                for column, value in enumerate(row_data):

                    cell = tk.Frame(
                        table_frame,
                        bg=row_bg,
                        height=44,
                        highlightbackground=TABLE_BORDER,
                        highlightthickness=1
                    )

                    cell.grid(
                        row=row_number,
                        column=column,
                        sticky="nsew"
                    )

                    cell.grid_propagate(False)

                    tk.Label(
                        cell,
                        text=str(value),
                        font=("Arial", 10),
                        fg=TEXT,
                        bg=row_bg
                    ).pack(
                        fill="both",
                        expand=True,
                        padx=5
                    )

        else:

            empty = tk.Frame(
                table_frame,
                bg=WHITE,
                height=55,
                highlightbackground=TABLE_BORDER,
                highlightthickness=1
            )

            empty.grid(
                row=1,
                column=0,
                columnspan=number_of_columns,
                sticky="nsew"
            )

            empty.grid_propagate(False)

            tk.Label(
                empty,
                text="No records found.",
                font=("Arial", 10),
                fg=GRAY,
                bg=WHITE
            ).pack(
                fill="both",
                expand=True
            )

        return outer

    # ======================================================
    # DASHBOARD PAGE
    # ======================================================

    def show_dashboard():

        clear_page()

        create_header(
            "Student Dashboard",
            "Overview of your college fee account"
        )

        body = tk.Frame(
            page_container,
            bg=LIGHT_BG
        )

        body.pack(
            fill="both",
            expand=True,
            padx=30,
            pady=25
        )

        # --------------------------------------------------
        # WELCOME
        # --------------------------------------------------

        tk.Label(
            body,
            text="Welcome, " + str(student_name) + " 👋",
            font=("Arial", 21, "bold"),
            fg=TEXT,
            bg=LIGHT_BG
        ).pack(
            anchor="w",
            padx=10,
            pady=(0, 4)
        )

        tk.Label(
            body,
            text="Here is your latest fee and payment information.",
            font=("Arial", 11),
            fg=GRAY,
            bg=LIGHT_BG
        ).pack(
            anchor="w",
            padx=10,
            pady=(0, 15)
        )

        # --------------------------------------------------
        # GET FEE INFORMATION
        # --------------------------------------------------

        total_fee = 0
        paid_fee = 0
        pending_fee = 0
        status = "No Fee Record"

        conn = None

        try:

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT
                    COALESCE(SUM(total_fee), 0),
                    COALESCE(SUM(paid_fee), 0),
                    COALESCE(SUM(pending_fee), 0)
                FROM fees
                WHERE student_id = ?
                """,
                (student_id,)
            )

            fee_data = cursor.fetchone()

            if fee_data:

                total_fee = float(
                    fee_data[0] or 0
                )

                paid_fee = float(
                    fee_data[1] or 0
                )

                pending_fee = float(
                    fee_data[2] or 0
                )

            if total_fee == 0:

                status = "No Fee Record"

            elif pending_fee <= 0:

                status = "Paid"

            elif paid_fee <= 0:

                status = "Pending"

            else:

                status = "Partially Paid"

        except sqlite3.Error:

            pass

        finally:

            if conn:
                conn.close()

        # --------------------------------------------------
        # FEE SUMMARY
        # --------------------------------------------------

        summary_box = tk.Frame(
            body,
            bg=WHITE,
            highlightbackground=BORDER,
            highlightthickness=1
        )

        summary_box.pack(
            fill="x",
            pady=(0, 18)
        )

        tk.Label(
            summary_box,
            text="₹   Fee Summary",
            font=("Arial", 17, "bold"),
            fg=TEXT,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=18,
            pady=(15, 5)
        )

        create_table(
            summary_box,
            [
                "Total Fee",
                "Paid Fee",
                "Pending Fee",
                "Status"
            ],
            [
                [
                    f"₹{total_fee:,.2f}",
                    f"₹{paid_fee:,.2f}",
                    f"₹{pending_fee:,.2f}",
                    status
                ]
            ],
            [220, 220, 220, 220],
            40,
            48
        )

        # --------------------------------------------------
        # STUDENT INFORMATION
        # --------------------------------------------------

        info_box = tk.Frame(
            body,
            bg=WHITE,
            highlightbackground=BORDER,
            highlightthickness=1
        )

        info_box.pack(
            fill="both",
            expand=True
        )

        tk.Label(
            info_box,
            text="👤   Student Information",
            font=("Arial", 17, "bold"),
            fg=TEXT,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=18,
            pady=(15, 5)
        )

        information_rows = [
            ["Student ID", student_id],
            ["Name", student_name],
            ["Username", username],
            ["Course", course],
            ["Department", department],
            ["Semester", semester],
            ["Academic Year", academic_year],
            ["Contact", contact]
        ]

        create_table(
            info_box,
            ["Field", "Information"],
            information_rows,
            [300, 700],
            40,
            42
        )

    # ======================================================
    # PROFILE PAGE
    # ======================================================

    def show_profile():

        clear_page()

        create_header(
            "My Profile",
            "View your personal and academic information"
        )

        body = tk.Frame(
            page_container,
            bg=LIGHT_BG
        )

        body.pack(
            fill="both",
            expand=True,
            padx=30,
            pady=25
        )

        box = tk.Frame(
            body,
            bg=WHITE,
            highlightbackground=BORDER,
            highlightthickness=1
        )

        box.pack(
            fill="both",
            expand=True
        )

        tk.Label(
            box,
            text="👤   Student Profile",
            font=("Arial", 20, "bold"),
            fg=TEXT,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=20,
            pady=(20, 5)
        )

        tk.Label(
            box,
            text="Your registered student information",
            font=("Arial", 10),
            fg=GRAY,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=20,
            pady=(0, 8)
        )

        profile_rows = [
            ["Student ID", student_id],
            ["Name", student_name],
            ["Username", username],
            ["Course", course],
            ["Department", department],
            ["Semester", semester],
            ["Academic Year", academic_year],
            ["Contact", contact]
        ]

        create_table(
            box,
            ["Field", "Information"],
            profile_rows,
            [300, 850],
            42,
            48
        )

        tk.Label(
            box,
            text="Student information is managed by the administrator.",
            font=("Arial", 10),
            fg=GRAY,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=20,
            pady=(5, 20)
        )

    # ======================================================
    # FEES PAGE
    # ======================================================

    def show_fees():

        clear_page()

        create_header(
            "My Fees",
            "View your current fee details"
        )

        body = tk.Frame(
            page_container,
            bg=LIGHT_BG
        )

        body.pack(
            fill="both",
            expand=True,
            padx=30,
            pady=25
        )

        box = tk.Frame(
            body,
            bg=WHITE,
            highlightbackground=BORDER,
            highlightthickness=1
        )

        box.pack(
            fill="both",
            expand=True
        )

        tk.Label(
            box,
            text="₹   Fee Details",
            font=("Arial", 20, "bold"),
            fg=TEXT,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=20,
            pady=(20, 5)
        )

        tk.Label(
            box,
            text="All fee records associated with your student account",
            font=("Arial", 10),
            fg=GRAY,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=20,
            pady=(0, 10)
        )

        rows = []

        conn = None

        try:

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT
                    fee_id,
                    total_fee,
                    paid_fee,
                    pending_fee,
                    due_date,
                    status
                FROM fees
                WHERE student_id = ?
                ORDER BY fee_id DESC
                """,
                (student_id,)
            )

            database_rows = cursor.fetchall()

            for row in database_rows:

                rows.append(
                    [
                        row[0],
                        f"₹{float(row[1] or 0):,.2f}",
                        f"₹{float(row[2] or 0):,.2f}",
                        f"₹{float(row[3] or 0):,.2f}",
                        row[4] or "N/A",
                        row[5] or "Pending"
                    ]
                )

        except sqlite3.Error as e:

            messagebox.showerror(
                "Database Error",
                "Could not load fee records.\n\n" + str(e),
                parent=window
            )

        finally:

            if conn:
                conn.close()

        create_scroll_table(
            box,
            [
                "Fee ID",
                "Total Fee",
                "Paid Fee",
                "Pending Fee",
                "Due Date",
                "Status"
            ],
            rows,
            [100, 180, 180, 180, 170, 180]
        )

    # ======================================================
    # PAYMENTS PAGE
    # ======================================================

    def show_payments():

        clear_page()

        create_header(
            "My Payments",
            "View your payment history"
        )

        body = tk.Frame(
            page_container,
            bg=LIGHT_BG
        )

        body.pack(
            fill="both",
            expand=True,
            padx=30,
            pady=25
        )

        box = tk.Frame(
            body,
            bg=WHITE,
            highlightbackground=BORDER,
            highlightthickness=1
        )

        box.pack(
            fill="both",
            expand=True
        )

        tk.Label(
            box,
            text="▣   Payment History",
            font=("Arial", 20, "bold"),
            fg=TEXT,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=20,
            pady=(20, 5)
        )

        tk.Label(
            box,
            text="Payments made by you",
            font=("Arial", 10),
            fg=GRAY,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=20,
            pady=(0, 10)
        )

        rows = []

        conn = None

        try:

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT
                    payment_id,
                    amount,
                    payment_date,
                    payment_mode,
                    transaction_id
                FROM payments
                WHERE student_id = ?
                ORDER BY payment_id DESC
                """,
                (student_id,)
            )

            database_rows = cursor.fetchall()

            for row in database_rows:

                rows.append(
                    [
                        row[0],
                        f"₹{float(row[1] or 0):,.2f}",
                        row[2] or "N/A",
                        row[3] or "N/A",
                        row[4] or "N/A"
                    ]
                )

        except sqlite3.Error as e:

            messagebox.showerror(
                "Database Error",
                "Could not load payment records.\n\n" + str(e),
                parent=window
            )

        finally:

            if conn:
                conn.close()

        create_scroll_table(
            box,
            [
                "Payment ID",
                "Amount",
                "Payment Date",
                "Payment Mode",
                "Transaction ID"
            ],
            rows,
            [140, 200, 200, 200, 250]
        )

    # ======================================================
    # GET PAYMENT FOR RECEIPT
    # ======================================================

    def get_payment(payment_id):

        conn = None

        try:

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT
                    p.payment_id,
                    p.student_id,
                    s.name,
                    s.course,
                    s.department,
                    p.amount,
                    p.payment_date,
                    p.payment_mode,
                    p.transaction_id
                FROM payments p
                JOIN students s
                    ON p.student_id = s.student_id
                WHERE p.payment_id = ?
                  AND p.student_id = ?
                """,
                (
                    payment_id,
                    student_id
                )
            )

            return cursor.fetchone()

        except sqlite3.Error as e:

            messagebox.showerror(
                "Database Error",
                "Could not load payment information.\n\n" + str(e),
                parent=window
            )

            return None

        finally:

            if conn:
                conn.close()

    # ======================================================
    # SAVE RECEIPT AS PDF
    # ======================================================

    def save_receipt_pdf(payment):

        if not PDF_AVAILABLE:

            messagebox.showerror(
                "PDF Library Missing",
                "ReportLab is not installed.\n\n"
                "Open Command Prompt and run:\n\n"
                "py -m pip install reportlab",
                parent=window
            )

            return

        payment_id = payment[0]
        sid = payment[1]
        name = payment[2]
        student_course = payment[3]
        student_department = payment[4]
        amount = float(payment[5] or 0)
        payment_date = payment[6] or "N/A"
        payment_mode = payment[7] or "N/A"
        transaction_id = payment[8] or "N/A"

        receipt_number = f"REC-{int(payment_id):05d}"

        filename = filedialog.asksaveasfilename(
            parent=window,
            title="Save Receipt as PDF",
            defaultextension=".pdf",
            initialfile=f"{receipt_number}.pdf",
            filetypes=[
                ("PDF Files", "*.pdf")
            ]
        )

        if not filename:
            return

        try:

            pdf = canvas.Canvas(
                filename,
                pagesize=A4
            )

            width, height = A4

            # ------------------------------------------------
            # BORDER
            # ------------------------------------------------

            pdf.setStrokeColor(
                colors.HexColor("#174A70")
            )

            pdf.setLineWidth(2)

            pdf.rect(
                35,
                35,
                width - 70,
                height - 100
            )

            # ------------------------------------------------
            # TITLE
            # ------------------------------------------------

            pdf.setFillColor(
                colors.HexColor("#174A70")
            )

            pdf.setFont(
                "Helvetica-Bold",
                22
            )

            pdf.drawCentredString(
                width / 2,
                height - 85,
                "COLLEGE FEE TRACKER"
            )

            pdf.setFont(
                "Helvetica-Bold",
                16
            )

            pdf.drawCentredString(
                width / 2,
                height - 115,
                "PAYMENT RECEIPT"
            )

            # ------------------------------------------------
            # RECEIPT NUMBER
            # ------------------------------------------------

            pdf.setFont(
                "Helvetica-Bold",
                11
            )

            pdf.setFillColor(
                colors.black
            )

            pdf.drawString(
                70,
                height - 160,
                "Receipt No.:"
            )

            pdf.setFont(
                "Helvetica",
                11
            )

            pdf.drawString(
                160,
                height - 160,
                receipt_number
            )

            # ------------------------------------------------
            # STUDENT DETAILS
            # ------------------------------------------------

            y = height - 210

            pdf.setFont(
                "Helvetica-Bold",
                13
            )

            pdf.setFillColor(
                colors.HexColor("#174A70")
            )

            pdf.drawString(
                70,
                y,
                "Student Details"
            )

            y -= 30

            pdf.setFillColor(
                colors.black
            )

            details = [
                ("Student ID", sid),
                ("Name", name),
                ("Course", student_course),
                ("Department", student_department)
            ]

            for label, value in details:

                pdf.setFont(
                    "Helvetica-Bold",
                    10
                )

                pdf.drawString(
                    80,
                    y,
                    str(label) + ":"
                )

                pdf.setFont(
                    "Helvetica",
                    10
                )

                pdf.drawString(
                    190,
                    y,
                    str(value)
                )

                y -= 25

            # ------------------------------------------------
            # PAYMENT DETAILS
            # ------------------------------------------------

            y -= 15

            pdf.setFont(
                "Helvetica-Bold",
                13
            )

            pdf.setFillColor(
                colors.HexColor("#174A70")
            )

            pdf.drawString(
                70,
                y,
                "Payment Details"
            )

            y -= 30

            pdf.setFillColor(
                colors.black
            )

            payment_details = [
                ("Payment ID", payment_id),
                ("Amount Paid", f"Rs. {amount:,.2f}"),
                ("Payment Date", payment_date),
                ("Payment Mode", payment_mode),
                ("Transaction ID", transaction_id)
            ]

            for label, value in payment_details:

                pdf.setFont(
                    "Helvetica-Bold",
                    10
                )

                pdf.drawString(
                    80,
                    y,
                    str(label) + ":"
                )

                pdf.setFont(
                    "Helvetica",
                    10
                )

                pdf.drawString(
                    190,
                    y,
                    str(value)
                )

                y -= 25

            # ------------------------------------------------
            # AMOUNT BOX
            # ------------------------------------------------

            y -= 20

            pdf.setFillColor(
                colors.HexColor("#EAF3FA")
            )

            pdf.setStrokeColor(
                colors.HexColor("#B8C7D1")
            )

            pdf.rect(
                70,
                y - 25,
                width - 140,
                55,
                fill=1,
                stroke=1
            )

            pdf.setFillColor(
                colors.HexColor("#174A70")
            )

            pdf.setFont(
                "Helvetica-Bold",
                14
            )

            pdf.drawString(
                90,
                y,
                "TOTAL AMOUNT PAID"
            )

            pdf.drawRightString(
                width - 90,
                y,
                f"Rs. {amount:,.2f}"
            )

            # ------------------------------------------------
            # FOOTER
            # ------------------------------------------------

            pdf.setFillColor(
                colors.HexColor("#6B7280")
            )

            pdf.setFont(
                "Helvetica",
                9
            )

            pdf.drawCentredString(
                width / 2,
                75,
                "This is a computer-generated payment receipt."
            )

            pdf.drawCentredString(
                width / 2,
                60,
                "College Fee Tracker"
            )

            pdf.save()

            messagebox.showinfo(
                "Receipt Saved",
                "Receipt has been saved successfully as PDF.",
                parent=window
            )

        except Exception as e:

            messagebox.showerror(
                "PDF Error",
                "Could not save PDF receipt.\n\n" + str(e),
                parent=window
            )

    # ======================================================
    # SAVE RECEIPT AS WORD
    # ======================================================

    def save_receipt_word(payment):

        if not WORD_AVAILABLE:

            messagebox.showerror(
                "Word Library Missing",
                "python-docx is not installed.\n\n"
                "Open Command Prompt and run:\n\n"
                "py -m pip install python-docx",
                parent=window
            )

            return

        payment_id = payment[0]
        sid = payment[1]
        name = payment[2]
        student_course = payment[3]
        student_department = payment[4]
        amount = float(payment[5] or 0)
        payment_date = payment[6] or "N/A"
        payment_mode = payment[7] or "N/A"
        transaction_id = payment[8] or "N/A"

        receipt_number = f"REC-{int(payment_id):05d}"

        filename = filedialog.asksaveasfilename(
            parent=window,
            title="Save Receipt as Word",
            defaultextension=".docx",
            initialfile=f"{receipt_number}.docx",
            filetypes=[
                ("Word Document", "*.docx")
            ]
        )

        if not filename:
            return

        try:

            document = Document()

            # ------------------------------------------------
            # TITLE
            # ------------------------------------------------

            title = document.add_paragraph()

            title.alignment = WD_ALIGN_PARAGRAPH.CENTER

            run = title.add_run(
                "COLLEGE FEE TRACKER"
            )

            run.bold = True
            run.font.size = Pt(20)

            subtitle = document.add_paragraph()

            subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER

            run = subtitle.add_run(
                "PAYMENT RECEIPT"
            )

            run.bold = True
            run.font.size = Pt(16)

            # ------------------------------------------------
            # RECEIPT NUMBER
            # ------------------------------------------------

            paragraph = document.add_paragraph()

            run = paragraph.add_run(
                "Receipt No.: "
            )

            run.bold = True

            paragraph.add_run(
                receipt_number
            )

            # ------------------------------------------------
            # STUDENT DETAILS
            # ------------------------------------------------

            heading = document.add_paragraph()

            run = heading.add_run(
                "Student Details"
            )

            run.bold = True
            run.font.size = Pt(14)

            student_table = document.add_table(
                rows=4,
                cols=2
            )

            student_table.style = "Table Grid"

            student_details = [
                ("Student ID", sid),
                ("Name", name),
                ("Course", student_course),
                ("Department", student_department)
            ]

            for index, (label, value) in enumerate(
                student_details
            ):

                student_table.cell(
                    index,
                    0
                ).text = str(label)

                student_table.cell(
                    index,
                    1
                ).text = str(value)

            # ------------------------------------------------
            # PAYMENT DETAILS
            # ------------------------------------------------

            heading = document.add_paragraph()

            run = heading.add_run(
                "Payment Details"
            )

            run.bold = True
            run.font.size = Pt(14)

            payment_table = document.add_table(
                rows=5,
                cols=2
            )

            payment_table.style = "Table Grid"

            payment_details = [
                ("Payment ID", payment_id),
                ("Amount Paid", f"Rs. {amount:,.2f}"),
                ("Payment Date", payment_date),
                ("Payment Mode", payment_mode),
                ("Transaction ID", transaction_id)
            ]

            for index, (label, value) in enumerate(
                payment_details
            ):

                payment_table.cell(
                    index,
                    0
                ).text = str(label)

                payment_table.cell(
                    index,
                    1
                ).text = str(value)

            # ------------------------------------------------
            # TOTAL
            # ------------------------------------------------

            paragraph = document.add_paragraph()

            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER

            run = paragraph.add_run(
                f"\nTOTAL AMOUNT PAID: Rs. {amount:,.2f}"
            )

            run.bold = True
            run.font.size = Pt(15)

            # ------------------------------------------------
            # FOOTER
            # ------------------------------------------------

            paragraph = document.add_paragraph()

            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER

            run = paragraph.add_run(
                "\nThis is a computer-generated payment receipt."
            )

            run.font.size = Pt(9)

            document.save(
                filename
            )

            messagebox.showinfo(
                "Receipt Saved",
                "Receipt has been saved successfully as Word document.",
                parent=window
            )

        except Exception as e:

            messagebox.showerror(
                "Word Error",
                "Could not save Word receipt.\n\n" + str(e),
                parent=window
            )

    # ======================================================
    # RECEIPTS PAGE
    # ======================================================

    def show_receipts():

        clear_page()

        create_header(
            "My Receipts",
            "View and save your payment receipts"
        )

        body = tk.Frame(
            page_container,
            bg=LIGHT_BG
        )

        body.pack(
            fill="both",
            expand=True,
            padx=30,
            pady=25
        )

        box = tk.Frame(
            body,
            bg=WHITE,
            highlightbackground=BORDER,
            highlightthickness=1
        )

        box.pack(
            fill="both",
            expand=True
        )

        # --------------------------------------------------
        # TITLE
        # --------------------------------------------------

        tk.Label(
            box,
            text="🧾   My Payment Receipts",
            font=("Arial", 20, "bold"),
            fg=TEXT,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=20,
            pady=(20, 5)
        )

        tk.Label(
            box,
            text="Select a payment below to save its receipt.",
            font=("Arial", 10),
            fg=GRAY,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=20,
            pady=(0, 10)
        )

        # --------------------------------------------------
        # PAYMENT DATA
        # --------------------------------------------------

        database_rows = []

        conn = None

        try:

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT
                    payment_id,
                    amount,
                    payment_date,
                    payment_mode,
                    transaction_id
                FROM payments
                WHERE student_id = ?
                ORDER BY payment_id DESC
                """,
                (student_id,)
            )

            database_rows = cursor.fetchall()

        except sqlite3.Error as e:

            messagebox.showerror(
                "Database Error",
                "Could not load receipts.\n\n" + str(e),
                parent=window
            )

        finally:

            if conn:
                conn.close()

        # --------------------------------------------------
        # TABLE AREA
        # --------------------------------------------------

        table_area = tk.Frame(
            box,
            bg=WHITE
        )

        table_area.pack(
            fill="both",
            expand=True,
            padx=18,
            pady=(0, 10)
        )

        # --------------------------------------------------
        # TREEVIEW
        # --------------------------------------------------

        import tkinter.ttk as ttk

        style = ttk.Style()

        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(
            "Receipt.Treeview",
            background=WHITE,
            foreground=TEXT,
            rowheight=42,
            fieldbackground=WHITE,
            bordercolor=TABLE_BORDER,
            borderwidth=1,
            font=("Arial", 10)
        )

        style.configure(
            "Receipt.Treeview.Heading",
            background=HEADER_BG,
            foreground=WHITE,
            font=("Arial", 10, "bold"),
            relief="flat"
        )

        style.map(
            "Receipt.Treeview",
            background=[
                ("selected", "#DCECF7")
            ],
            foreground=[
                ("selected", TEXT)
            ]
        )

        columns = (
            "receipt",
            "payment_id",
            "amount",
            "date",
            "mode",
            "transaction"
        )

        tree = ttk.Treeview(
            table_area,
            columns=columns,
            show="headings",
            style="Receipt.Treeview",
            selectmode="browse"
        )

        headings = {
            "receipt": "Receipt No.",
            "payment_id": "Payment ID",
            "amount": "Amount",
            "date": "Payment Date",
            "mode": "Payment Mode",
            "transaction": "Transaction ID"
        }

        widths = {
            "receipt": 150,
            "payment_id": 120,
            "amount": 180,
            "date": 180,
            "mode": 180,
            "transaction": 220
        }

        for column in columns:

            tree.heading(
                column,
                text=headings[column]
            )

            tree.column(
                column,
                width=widths[column],
                anchor="center"
            )

        # --------------------------------------------------
        # SCROLLBAR
        # --------------------------------------------------

        scrollbar = ttk.Scrollbar(
            table_area,
            orient="vertical",
            command=tree.yview
        )

        tree.configure(
            yscrollcommand=scrollbar.set
        )

        scrollbar.pack(
            side="right",
            fill="y"
        )

        tree.pack(
            side="left",
            fill="both",
            expand=True
        )

        # --------------------------------------------------
        # INSERT ROWS
        # --------------------------------------------------

        for index, row in enumerate(database_rows):

            receipt_number = (
                f"REC-{int(row[0]):05d}"
            )

            tree.insert(
                "",
                "end",
                iid=str(row[0]),
                values=(
                    receipt_number,
                    row[0],
                    f"₹{float(row[1] or 0):,.2f}",
                    row[2] or "N/A",
                    row[3] or "N/A",
                    row[4] or "N/A"
                )
            )

        # --------------------------------------------------
        # BUTTON AREA
        # --------------------------------------------------

        button_area = tk.Frame(
            box,
            bg=WHITE,
            height=75
        )

        button_area.pack(
            fill="x",
            pady=(5, 18)
        )

        button_area.pack_propagate(False)

        # --------------------------------------------------
        # BUTTON FUNCTION
        # --------------------------------------------------

        def get_selected_payment():

            selected = tree.selection()

            if not selected:

                messagebox.showwarning(
                    "Select Receipt",
                    "Please select a payment receipt first.",
                    parent=window
                )

                return None

            payment_id = int(
                selected[0]
            )

            return get_payment(
                payment_id
            )

        # --------------------------------------------------
        # PDF BUTTON
        # --------------------------------------------------

        def save_selected_pdf():

            payment = get_selected_payment()

            if payment:

                save_receipt_pdf(
                    payment
                )

        # --------------------------------------------------
        # WORD BUTTON
        # --------------------------------------------------

        def save_selected_word():

            payment = get_selected_payment()

            if payment:

                save_receipt_word(
                    payment
                )

        # --------------------------------------------------
        # BUTTON CREATOR
        # --------------------------------------------------

        def action_button(
            parent_widget,
            text,
            command,
            bg_color,
            hover_color
        ):

            button = tk.Button(
                parent_widget,
                text=text,
                font=("Arial", 11, "bold"),
                bg=bg_color,
                fg=WHITE,
                activebackground=hover_color,
                activeforeground=WHITE,
                bd=0,
                relief="flat",
                cursor="hand2",
                padx=25,
                pady=9,
                command=command
            )

            def enter(event):

                button.config(
                    bg=hover_color
                )

            def leave(event):

                button.config(
                    bg=bg_color
                )

            button.bind(
                "<Enter>",
                enter
            )

            button.bind(
                "<Leave>",
                leave
            )

            return button

        # --------------------------------------------------
        # BUTTONS
        # --------------------------------------------------

        button_container = tk.Frame(
            button_area,
            bg=WHITE
        )

        button_container.pack(
            anchor="center",
            pady=10
        )

        action_button(
            button_container,
            "📄   Save as PDF",
            save_selected_pdf,
            BLUE,
            BLUE_HOVER
        ).pack(
            side="left",
            padx=10
        )

        action_button(
            button_container,
            "📝   Save as Word",
            save_selected_word,
            GREEN,
            GREEN_HOVER
        ).pack(
            side="left",
            padx=10
        )

        # --------------------------------------------------
        # INFORMATION
        # --------------------------------------------------

        tk.Label(
            box,
            text="Select a payment row and choose PDF or Word to save the receipt.",
            font=("Arial", 9),
            fg=GRAY,
            bg=WHITE
        ).pack(
            pady=(0, 15)
        )

    # ======================================================
    # SIDEBAR BUTTONS
    # ======================================================

    sidebar_buttons = []

    def sidebar_button(
        text,
        command,
        active=False
    ):

        button = tk.Button(
            sidebar,
            text=text,
            font=("Arial", 13, "bold"),
            bg=SIDEBAR_ACTIVE if active else SIDEBAR,
            fg=WHITE,
            activebackground=SIDEBAR_ACTIVE,
            activeforeground=WHITE,
            bd=0,
            relief="flat",
            anchor="w",
            padx=30,
            cursor="hand2",
            command=command
        )

        button.pack(
            fill="x",
            ipady=14
        )

        sidebar_buttons.append(
            (button, active)
        )

        def hover_in(event):

            if not active:

                button.config(
                    bg=SIDEBAR_HOVER
                )

        def hover_out(event):

            if not active:

                button.config(
                    bg=SIDEBAR
                )

        button.bind(
            "<Enter>",
            hover_in
        )

        button.bind(
            "<Leave>",
            hover_out
        )

        return button

    # ======================================================
    # CLOSE WINDOW
    # ======================================================

    def close_window():

        try:
            window.destroy()
        except tk.TclError:
            pass

        if parent is not None:

            try:

                parent.deiconify()

                try:
                    parent.state("zoomed")
                except tk.TclError:
                    pass

            except tk.TclError:
                pass

    # ======================================================
    # LOGOUT
    # ======================================================

    def logout():

        answer = messagebox.askyesno(
            "Logout",
            "Are you sure you want to logout?",
            parent=window
        )

        if answer:
            close_window()

    # ======================================================
    # SIDEBAR
    # ======================================================

    sidebar_button(
        "⌂   Dashboard",
        show_dashboard,
        active=True
    )

    sidebar_button(
        "♟   My Profile",
        show_profile
    )

    sidebar_button(
        "₹   My Fees",
        show_fees
    )

    sidebar_button(
        "▣   My Payments",
        show_payments
    )

    sidebar_button(
        "🧾   My Receipts",
        show_receipts
    )

    # ======================================================
    # LOGOUT
    # ======================================================

    logout_frame = tk.Frame(
        sidebar,
        bg=SIDEBAR
    )

    logout_frame.pack(
        side="bottom",
        fill="x"
    )

    logout_button = tk.Button(
        logout_frame,
        text="↪   Logout",
        font=("Arial", 13, "bold"),
        bg=SIDEBAR,
        fg=WHITE,
        activebackground=SIDEBAR_HOVER,
        activeforeground=WHITE,
        bd=0,
        relief="flat",
        anchor="w",
        padx=30,
        cursor="hand2",
        command=logout
    )

    logout_button.pack(
        fill="x",
        ipady=15
    )

    # ======================================================
    # WINDOW CLOSE
    # ======================================================

    window.protocol(
        "WM_DELETE_WINDOW",
        close_window
    )

    # ======================================================
    # OPEN DASHBOARD
    # ======================================================

    show_dashboard()

    # ======================================================
    # MAINLOOP FOR TESTING
    # ======================================================

    if parent is None:
        window.mainloop()


# ==========================================================
# TEST
# ==========================================================

if __name__ == "__main__":

    open_student_dashboard(
        student_id=101
    )