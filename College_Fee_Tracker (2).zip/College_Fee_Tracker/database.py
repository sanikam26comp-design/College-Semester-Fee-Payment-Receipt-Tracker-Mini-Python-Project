import sqlite3


# ============================================================
# DATABASE NAME
# ============================================================

DB_NAME = "college_fee_tracker.db"


# ============================================================
# CONNECT TO DATABASE
# ============================================================

connection = sqlite3.connect(DB_NAME)
cursor = connection.cursor()


# ============================================================
# ADMIN TABLE
# ============================================================

cursor.execute("""
CREATE TABLE IF NOT EXISTS admin (
    admin_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
)
""")


# ============================================================
# STUDENT TABLE
# ============================================================

cursor.execute("""
CREATE TABLE IF NOT EXISTS students (
    student_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    course TEXT,
    department TEXT,
    semester INTEGER,
    academic_year TEXT,
    contact TEXT
)
""")


# ============================================================
# FEES TABLE MIGRATION
# ============================================================

# Check whether fees table already exists
cursor.execute("""
SELECT name
FROM sqlite_master
WHERE type='table'
AND name='fees'
""")

fees_exists = cursor.fetchone()


if not fees_exists:

    # --------------------------------------------------------
    # CREATE NEW FEES TABLE
    # --------------------------------------------------------

    cursor.execute("""
    CREATE TABLE fees (
        fee_id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        total_fee REAL NOT NULL,
        paid_fee REAL DEFAULT 0,
        pending_fee REAL DEFAULT 0,
        due_date TEXT,
        status TEXT DEFAULT 'Pending',

        FOREIGN KEY (student_id)
        REFERENCES students(student_id)
    )
    """)

else:

    # --------------------------------------------------------
    # CHECK EXISTING FEES TABLE
    # --------------------------------------------------------

    cursor.execute("PRAGMA table_info(fees)")

    fee_columns = [
        column[1]
        for column in cursor.fetchall()
    ]

    print("Existing fees columns:")
    print(fee_columns)


    # --------------------------------------------------------
    # CHECK FOR OLD DATABASE STRUCTURE
    # --------------------------------------------------------

    old_structure = (
        "balance" in fee_columns
        or
        "paid_amount" in fee_columns
    )


    if old_structure:

        print("Old fees table detected.")
        print("Migrating fees table...")


        # ----------------------------------------------------
        # CREATE TEMPORARY NEW TABLE
        # ----------------------------------------------------

        cursor.execute("""
        CREATE TABLE fees_new (
            fee_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            total_fee REAL NOT NULL,
            paid_fee REAL DEFAULT 0,
            pending_fee REAL DEFAULT 0,
            due_date TEXT,
            status TEXT DEFAULT 'Pending',

            FOREIGN KEY (student_id)
            REFERENCES students(student_id)
        )
        """)


        # ----------------------------------------------------
        # COPY OLD DATA
        # ----------------------------------------------------

        if "paid_amount" in fee_columns and "balance" in fee_columns:

            cursor.execute("""
            INSERT INTO fees_new
            (
                fee_id,
                student_id,
                total_fee,
                paid_fee,
                pending_fee,
                due_date,
                status
            )

            SELECT
                fee_id,
                student_id,
                total_fee,
                COALESCE(paid_amount, 0),
                COALESCE(balance, 0),
                NULL,
                CASE
                    WHEN COALESCE(balance, 0) <= 0
                        THEN 'Paid'

                    WHEN COALESCE(paid_amount, 0) > 0
                        THEN 'Partially Paid'

                    ELSE 'Pending'
                END

            FROM fees
            """)

        elif "paid_amount" in fee_columns:

            cursor.execute("""
            INSERT INTO fees_new
            (
                fee_id,
                student_id,
                total_fee,
                paid_fee,
                pending_fee,
                due_date,
                status
            )

            SELECT
                fee_id,
                student_id,
                total_fee,
                COALESCE(paid_amount, 0),
                total_fee - COALESCE(paid_amount, 0),
                NULL,
                CASE
                    WHEN total_fee - COALESCE(paid_amount, 0) <= 0
                        THEN 'Paid'

                    WHEN COALESCE(paid_amount, 0) > 0
                        THEN 'Partially Paid'

                    ELSE 'Pending'
                END

            FROM fees
            """)

        elif "balance" in fee_columns:

            cursor.execute("""
            INSERT INTO fees_new
            (
                fee_id,
                student_id,
                total_fee,
                paid_fee,
                pending_fee,
                due_date,
                status
            )

            SELECT
                fee_id,
                student_id,
                total_fee,
                total_fee - COALESCE(balance, 0),
                COALESCE(balance, 0),
                NULL,
                CASE
                    WHEN COALESCE(balance, 0) <= 0
                        THEN 'Paid'

                    WHEN total_fee - COALESCE(balance, 0) > 0
                        THEN 'Partially Paid'

                    ELSE 'Pending'
                END

            FROM fees
            """)


        # ----------------------------------------------------
        # DELETE OLD TABLE
        # ----------------------------------------------------

        cursor.execute("""
        DROP TABLE fees
        """)


        # ----------------------------------------------------
        # RENAME NEW TABLE
        # ----------------------------------------------------

        cursor.execute("""
        ALTER TABLE fees_new
        RENAME TO fees
        """)


        print("Fees table migrated successfully!")


    else:

        # ----------------------------------------------------
        # CURRENT TABLE IS ALREADY NEW
        # ----------------------------------------------------

        required_columns = [
            "paid_fee",
            "pending_fee",
            "due_date",
            "status"
        ]

        for column in required_columns:

            if column not in fee_columns:

                if column == "paid_fee":

                    cursor.execute("""
                    ALTER TABLE fees
                    ADD COLUMN paid_fee REAL DEFAULT 0
                    """)

                elif column == "pending_fee":

                    cursor.execute("""
                    ALTER TABLE fees
                    ADD COLUMN pending_fee REAL DEFAULT 0
                    """)

                elif column == "due_date":

                    cursor.execute("""
                    ALTER TABLE fees
                    ADD COLUMN due_date TEXT
                    """)

                elif column == "status":

                    cursor.execute("""
                    ALTER TABLE fees
                    ADD COLUMN status TEXT DEFAULT 'Pending'
                    """)


# ============================================================
# PAYMENTS TABLE
# ============================================================

cursor.execute("""
CREATE TABLE IF NOT EXISTS payments (
    payment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    payment_date TEXT NOT NULL,
    payment_mode TEXT,
    transaction_id TEXT,

    FOREIGN KEY (student_id)
    REFERENCES students(student_id)
)
""")


# ============================================================
# DEFAULT ADMIN
# ============================================================

cursor.execute("""
INSERT OR IGNORE INTO admin
(username, password)
VALUES
('admin', 'admin123')
""")


# ============================================================
# SAMPLE STUDENT 1
# ============================================================

cursor.execute("""
INSERT OR IGNORE INTO students
(
    student_id,
    name,
    username,
    password,
    course,
    department,
    semester,
    academic_year,
    contact
)
VALUES
(
    101,
    'Sanika Mistry',
    'sanika101',
    'student123',
    'B.Tech',
    'Computer Science',
    5,
    '2024-2025',
    '9876543210'
)
""")


# ============================================================
# SAMPLE STUDENT 2
# ============================================================

cursor.execute("""
INSERT OR IGNORE INTO students
(
    student_id,
    name,
    username,
    password,
    course,
    department,
    semester,
    academic_year,
    contact
)
VALUES
(
    102,
    'Riya Shah',
    'riya102',
    'student123',
    'BCA',
    'Computer Applications',
    3,
    '2024-2025',
    '8765432109'
)
""")


# ============================================================
# SAMPLE FEE 101
# ============================================================

cursor.execute("""
INSERT OR IGNORE INTO fees
(
    student_id,
    total_fee,
    paid_fee,
    pending_fee,
    due_date,
    status
)
VALUES
(
    101,
    50000,
    30000,
    20000,
    '30-09-2026',
    'Partially Paid'
)
""")


# ============================================================
# SAMPLE FEE 102
# ============================================================

cursor.execute("""
INSERT OR IGNORE INTO fees
(
    student_id,
    total_fee,
    paid_fee,
    pending_fee,
    due_date,
    status
)
VALUES
(
    102,
    45000,
    45000,
    0,
    '30-09-2026',
    'Paid'
)
""")


# ============================================================
# UPDATE EXISTING FEE VALUES
# ============================================================

cursor.execute("""
UPDATE fees
SET pending_fee = total_fee - paid_fee
""")


cursor.execute("""
UPDATE fees
SET status =
    CASE
        WHEN pending_fee <= 0
            THEN 'Paid'

        WHEN paid_fee > 0
            THEN 'Partially Paid'

        ELSE 'Pending'
    END
""")


# ============================================================
# COMMIT
# ============================================================

connection.commit()


# ============================================================
# CLOSE DATABASE
# ============================================================

connection.close()


# ============================================================
# SUCCESS MESSAGE
# ============================================================

print()
print("==============================================")
print("DATABASE CREATED / UPDATED SUCCESSFULLY")
print("==============================================")
print()
print("Fees table structure:")
print("fee_id")
print("student_id")
print("total_fee")
print("paid_fee")
print("pending_fee")
print("due_date")
print("status")
print()
print("Old 'balance' and 'paid_amount' columns removed.")
print("==============================================")