import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3

DB_NAME = "college_fee_tracker.db"

# ============================================================
# OPTIONAL PDF SUPPORT
# ============================================================

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.units import mm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False


# ============================================================
# OPTIONAL WORD SUPPORT
# ============================================================

try:
    from docx import Document
    from docx.shared import Inches, Pt
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
    WORD_AVAILABLE = True
except ImportError:
    WORD_AVAILABLE = False


# ============================================================
# DATABASE
# ============================================================

def get_connection():
    return sqlite3.connect(DB_NAME)


# ============================================================
# RECEIPT MANAGEMENT INTERNAL PAGE
# ============================================================

def show_receipt_management_page(parent_frame):
    """
    Displays Receipt Management INSIDE the existing Admin Dashboard.

    Important:
    - No Toplevel is created for the main page.
    - No sidebar is created here.
    - No second Admin Dashboard is created.
    - The Admin Dashboard remains the single main window.
    """

    # --------------------------------------------------------
    # CLEAR EXISTING ADMIN PAGE
    # --------------------------------------------------------

    for widget in parent_frame.winfo_children():
        widget.destroy()

    # --------------------------------------------------------
    # COLORS
    # --------------------------------------------------------

    WHITE = "#FFFFFF"
    BG = "#F3F7FB"
    SIDEBAR = "#174A70"
    BLUE = "#1976D2"
    BLUE_HOVER = "#1565C0"
    GREEN = "#2E7D32"
    GREEN_HOVER = "#256628"
    RED = "#D32F2F"
    RED_HOVER = "#B71C1C"
    TEXT = "#1F2937"
    GRAY = "#6B7280"
    BORDER = "#D6E2EC"
    LIGHT_BLUE = "#EAF3FA"

    # ========================================================
    # MAIN PAGE
    # ========================================================

    page = tk.Frame(
        parent_frame,
        bg=BG
    )
    page.pack(
        fill="both",
        expand=True
    )

    # ========================================================
    # NOTE
    # ========================================================
    # The Admin Dashboard already provides the main page header.
    # Receipt Management only renders its page content here so
    # the title is not displayed twice.

    # ========================================================
    # BODY
    # ========================================================

    body = tk.Frame(
        page,
        bg=BG
    )
    body.pack(
        fill="both",
        expand=True,
        padx=35,
        pady=25
    )

    # ========================================================
    # ACTION BAR
    # ========================================================

    action_frame = tk.Frame(
        body,
        bg=BG
    )
    action_frame.pack(
        fill="x",
        pady=(0, 15)
    )

    # --------------------------------------------------------
    # SEARCH
    # --------------------------------------------------------

    search_frame = tk.Frame(
        action_frame,
        bg=WHITE,
        highlightbackground=BORDER,
        highlightthickness=1
    )
    search_frame.pack(
        side="left",
        fill="x",
        expand=True,
        padx=(0, 15)
    )

    tk.Label(
        search_frame,
        text="🔍",
        font=("Arial", 14),
        bg=WHITE,
        fg=BLUE
    ).pack(
        side="left",
        padx=(15, 5)
    )

    search_entry = tk.Entry(
        search_frame,
        font=("Arial", 12),
        bd=0,
        bg=WHITE,
        fg=TEXT
    )
    search_entry.pack(
        side="left",
        fill="x",
        expand=True,
        ipady=11
    )

    # --------------------------------------------------------
    # BUTTON HELPER
    # --------------------------------------------------------

    def styled_button(parent, text, command, bg_color=BLUE, hover_color=BLUE_HOVER):
        button = tk.Button(
            parent,
            text=text,
            command=command,
            font=("Arial", 11, "bold"),
            bg=bg_color,
            fg=WHITE,
            activebackground=hover_color,
            activeforeground=WHITE,
            bd=0,
            relief="flat",
            padx=20,
            pady=11,
            cursor="hand2"
        )

        button.bind(
            "<Enter>",
            lambda e: button.configure(bg=hover_color)
        )
        button.bind(
            "<Leave>",
            lambda e: button.configure(bg=bg_color)
        )

        return button

    # ========================================================
    # TABLE CARD
    # ========================================================

    table_card = tk.Frame(
        body,
        bg=WHITE,
        highlightbackground=BORDER,
        highlightthickness=1
    )

    # ========================================================
    # TABLE HEADER
    # ========================================================

    table_header = tk.Frame(
        table_card,
        bg=WHITE,
        height=62
    )
    table_header.pack(fill="x")
    table_header.pack_propagate(False)

    tk.Label(
        table_header,
        text="Payment Receipts",
        font=("Arial", 17, "bold"),
        fg=TEXT,
        bg=WHITE
    ).pack(
        side="left",
        padx=20
    )

    receipt_count_label = tk.Label(
        table_header,
        text="(0 records)",
        font=("Arial", 10),
        fg=GRAY,
        bg=WHITE
    )
    receipt_count_label.pack(
        side="left",
        padx=5
    )

    # ========================================================
    # TABLE AREA
    # IMPORTANT: Treeview is created INSIDE tree_frame.
    # This keeps both scrollbars attached to the actual table.
    # ========================================================

    tree_frame = tk.Frame(
        table_card,
        bg=WHITE
    )
    tree_frame.pack(
        fill="both",
        expand=True,
        padx=15,
        pady=(0, 15)
    )

    tree_frame.grid_rowconfigure(0, weight=1)
    tree_frame.grid_columnconfigure(0, weight=1)

    columns = (
        "payment_id",
        "student_id",
        "name",
        "amount",
        "payment_date",
        "payment_mode",
        "transaction_id"
    )

    tree = ttk.Treeview(
        tree_frame,
        columns=columns,
        show="headings",
        selectmode="browse"
    )

    headings = {
        "payment_id": "Payment ID",
        "student_id": "Student ID",
        "name": "Student Name",
        "amount": "Amount",
        "payment_date": "Payment Date",
        "payment_mode": "Payment Mode",
        "transaction_id": "Transaction ID"
    }

    widths = {
        "payment_id": 100,
        "student_id": 110,
        "name": 190,
        "amount": 140,
        "payment_date": 140,
        "payment_mode": 150,
        "transaction_id": 190
    }

    for column in columns:
        tree.heading(
            column,
            text=headings[column]
        )
        tree.column(
            column,
            width=widths[column],
            minwidth=90,
            anchor="center",
            stretch=False
        )

    vertical_scrollbar = ttk.Scrollbar(
        tree_frame,
        orient="vertical",
        command=tree.yview
    )

    horizontal_scrollbar = ttk.Scrollbar(
        tree_frame,
        orient="horizontal",
        command=tree.xview
    )

    tree.configure(
        yscrollcommand=vertical_scrollbar.set,
        xscrollcommand=horizontal_scrollbar.set
    )

    tree.grid(
        row=0,
        column=0,
        sticky="nsew"
    )

    vertical_scrollbar.grid(
        row=0,
        column=1,
        sticky="ns"
    )

    horizontal_scrollbar.grid(
        row=1,
        column=0,
        sticky="ew"
    )

    # ========================================================
    # TREEVIEW STYLE
    # ========================================================

    style = ttk.Style()

    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    style.configure(
        "Treeview",
        background=WHITE,
        foreground=TEXT,
        rowheight=42,
        fieldbackground=WHITE,
        font=("Arial", 10)
    )

    style.configure(
        "Treeview.Heading",
        background="#EAF2F8",
        foreground=TEXT,
        font=("Arial", 10, "bold"),
        padding=10
    )

    style.map(
        "Treeview",
        background=[("selected", "#DCEEFF")],
        foreground=[("selected", TEXT)]
    )

    # ========================================================
    # GET SELECTED PAYMENT
    # ========================================================

    def get_selected_payment(show_warning=True):

        selected = tree.selection()

        if not selected:
            if show_warning:
                messagebox.showwarning(
                    "Select Payment",
                    "Please select a payment record first.",
                    parent=parent_frame.winfo_toplevel()
                )
            return None

        values = tree.item(
            selected[0],
            "values"
        )

        if not values or len(values) < 7:
            messagebox.showerror(
                "Receipt Error",
                "Invalid payment record selected.",
                parent=parent_frame.winfo_toplevel()
            )
            return None

        payment_id = values[0]
        student_id = values[1]
        student_name = values[2]

        amount_display = values[3]
        payment_date = values[4]
        payment_mode = values[5]
        transaction_id = values[6]

        conn = None
        student = None

        try:
            conn = get_connection()
            cur = conn.cursor()

            cur.execute("""
                SELECT
                    name,
                    course,
                    department,
                    semester,
                    academic_year,
                    contact
                FROM students
                WHERE student_id = ?
            """, (student_id,))

            student = cur.fetchone()

        except sqlite3.Error as e:
            messagebox.showerror(
                "Database Error",
                "Could not retrieve student details.\n\n" + str(e),
                parent=parent_frame.winfo_toplevel()
            )
            return None

        finally:
            if conn:
                conn.close()

        if student:
            name = student[0] or student_name or "N/A"
            course = student[1] or "N/A"
            department = student[2] or "N/A"
            semester = student[3] or "N/A"
            academic_year = student[4] or "N/A"
            contact = student[5] or "N/A"
        else:
            name = student_name or "N/A"
            course = "N/A"
            department = "N/A"
            semester = "N/A"
            academic_year = "N/A"
            contact = "N/A"

        try:
            amount = float(
                str(amount_display)
                .replace("₹", "")
                .replace(",", "")
            )
        except (ValueError, TypeError):
            amount = 0.0

        try:
            receipt_number = f"REC-{int(payment_id):05d}"
        except (ValueError, TypeError):
            receipt_number = f"REC-{payment_id}"

        return {
            "receipt_number": receipt_number,
            "payment_id": payment_id,
            "student_id": student_id,
            "name": name,
            "course": course,
            "department": department,
            "semester": semester,
            "academic_year": academic_year,
            "contact": contact,
            "amount": amount,
            "payment_date": payment_date or "N/A",
            "payment_mode": payment_mode or "N/A",
            "transaction_id": (
                transaction_id
                if transaction_id and transaction_id != "N/A"
                else "N/A"
            )
        }

    # ========================================================
    # GENERATE RECEIPT
    # ========================================================

    def generate_receipt():

        receipt = get_selected_payment()

        if not receipt:
            return

        receipt_window = tk.Toplevel(
            parent_frame.winfo_toplevel()
        )

        receipt_window.title(
            f"Payment Receipt - {receipt['receipt_number']}"
        )

        receipt_window.geometry("760x850")
        receipt_window.configure(bg=BG)
        receipt_window.resizable(False, False)
        receipt_window.transient(parent_frame.winfo_toplevel())
        receipt_window.grab_set()

        # ----------------------------------------------------
        # RECEIPT CARD
        # ----------------------------------------------------

        card = tk.Frame(
            receipt_window,
            bg=WHITE,
            highlightbackground=BORDER,
            highlightthickness=1
        )
        card.pack(
            fill="both",
            expand=True,
            padx=25,
            pady=18
        )

        tk.Label(
            card,
            text="🎓",
            font=("Arial", 30),
            bg=WHITE
        ).pack(pady=(12, 0))

        tk.Label(
            card,
            text="COLLEGE FEE TRACKER",
            font=("Arial", 21, "bold"),
            fg=SIDEBAR,
            bg=WHITE
        ).pack()

        tk.Label(
            card,
            text="OFFICIAL PAYMENT RECEIPT",
            font=("Arial", 10, "bold"),
            fg=BLUE,
            bg=WHITE
        ).pack(pady=(3, 8))

        ttk.Separator(
            card,
            orient="horizontal"
        ).pack(
            fill="x",
            padx=35,
            pady=5
        )

        details = tk.Frame(
            card,
            bg=WHITE
        )
        details.pack(
            fill="x",
            padx=45,
            pady=10
        )

        def receipt_row(label, value):
            row = tk.Frame(
                details,
                bg=WHITE
            )
            row.pack(
                fill="x",
                pady=3
            )

            tk.Label(
                row,
                text=label,
                font=("Arial", 10, "bold"),
                fg=GRAY,
                bg=WHITE,
                width=20,
                anchor="w"
            ).pack(side="left")

            tk.Label(
                row,
                text=str(value),
                font=("Arial", 10),
                fg=TEXT,
                bg=WHITE,
                anchor="w"
            ).pack(
                side="left",
                fill="x",
                expand=True
            )

        receipt_rows = [
            ("Receipt Number:", receipt["receipt_number"]),
            ("Payment ID:", receipt["payment_id"]),
            ("Student ID:", receipt["student_id"]),
            ("Student Name:", receipt["name"]),
            ("Course:", receipt["course"]),
            ("Department:", receipt["department"]),
            ("Semester:", receipt["semester"]),
            ("Academic Year:", receipt["academic_year"]),
            ("Contact:", receipt["contact"]),
            ("Payment Date:", receipt["payment_date"]),
            ("Payment Mode:", receipt["payment_mode"]),
            ("Transaction ID:", receipt["transaction_id"])
        ]

        for label, value in receipt_rows:
            receipt_row(label, value)

        amount_frame = tk.Frame(
            card,
            bg=LIGHT_BLUE,
            highlightbackground="#9FC5E0",
            highlightthickness=1
        )
        amount_frame.pack(
            fill="x",
            padx=45,
            pady=(10, 7)
        )

        tk.Label(
            amount_frame,
            text="AMOUNT PAID",
            font=("Arial", 11, "bold"),
            fg=SIDEBAR,
            bg=LIGHT_BLUE
        ).pack(pady=(10, 0))

        tk.Label(
            amount_frame,
            text=f"₹{receipt['amount']:,.2f}",
            font=("Arial", 27, "bold"),
            fg=GREEN,
            bg=LIGHT_BLUE
        ).pack(pady=(0, 10))

        tk.Label(
            card,
            text="✓  Payment received successfully.",
            font=("Arial", 10, "bold"),
            fg=GREEN,
            bg=WHITE
        ).pack(pady=(5, 1))

        tk.Label(
            card,
            text="Thank you!",
            font=("Arial", 10),
            fg=GRAY,
            bg=WHITE
        ).pack()

        # ====================================================
        # SAVE PDF
        # ====================================================

        def save_pdf():

            if not PDF_AVAILABLE:
                messagebox.showerror(
                    "ReportLab Not Installed",
                    "Install ReportLab using:\n\n"
                    "py -m pip install reportlab",
                    parent=receipt_window
                )
                return

            filename = filedialog.asksaveasfilename(
                parent=receipt_window,
                title="Save Receipt as PDF",
                defaultextension=".pdf",
                filetypes=[("PDF Files", "*.pdf")],
                initialfile=f"{receipt['receipt_number']}.pdf"
            )

            if not filename:
                return

            try:
                doc = SimpleDocTemplate(
                    filename,
                    pagesize=A4,
                    rightMargin=20 * mm,
                    leftMargin=20 * mm,
                    topMargin=18 * mm,
                    bottomMargin=18 * mm
                )

                styles = getSampleStyleSheet()

                title_style = ParagraphStyle(
                    "ReceiptTitle",
                    parent=styles["Title"],
                    fontName="Helvetica-Bold",
                    fontSize=20,
                    alignment=TA_CENTER,
                    textColor=colors.HexColor(SIDEBAR),
                    spaceAfter=4
                )

                subtitle_style = ParagraphStyle(
                    "ReceiptSubtitle",
                    parent=styles["Normal"],
                    fontName="Helvetica-Bold",
                    fontSize=10,
                    alignment=TA_CENTER,
                    textColor=colors.HexColor(BLUE),
                    spaceAfter=12
                )

                normal_style = ParagraphStyle(
                    "ReceiptNormal",
                    parent=styles["Normal"],
                    fontName="Helvetica",
                    fontSize=10,
                    leading=14
                )

                label_style = ParagraphStyle(
                    "ReceiptLabel",
                    parent=styles["Normal"],
                    fontName="Helvetica-Bold",
                    fontSize=9,
                    textColor=colors.HexColor(GRAY)
                )

                section_style = ParagraphStyle(
                    "SectionTitle",
                    parent=styles["Heading2"],
                    fontName="Helvetica-Bold",
                    fontSize=12,
                    textColor=colors.HexColor(SIDEBAR),
                    spaceAfter=6
                )

                amount_style = ParagraphStyle(
                    "ReceiptAmount",
                    parent=styles["Normal"],
                    fontName="Helvetica-Bold",
                    fontSize=22,
                    alignment=TA_CENTER,
                    textColor=colors.HexColor(GREEN)
                )

                def make_table(data):
                    table = Table(
                        data,
                        colWidths=[45 * mm, 120 * mm]
                    )

                    table.setStyle(
                        TableStyle([
                            (
                                "GRID", (0, 0), (-1, -1),
                                0.5, colors.HexColor(BORDER)
                            ),
                            (
                                "VALIGN", (0, 0), (-1, -1),
                                "MIDDLE"
                            ),
                            (
                                "BACKGROUND", (0, 0), (-1, -1),
                                colors.HexColor("#F8FBFD")
                            ),
                            (
                                "LEFTPADDING", (0, 0), (-1, -1), 8
                            ),
                            (
                                "RIGHTPADDING", (0, 0), (-1, -1), 8
                            ),
                            (
                                "TOPPADDING", (0, 0), (-1, -1), 7
                            ),
                            (
                                "BOTTOMPADDING", (0, 0), (-1, -1), 7
                            )
                        ])
                    )

                    return table

                story = [
                    Paragraph("COLLEGE FEE TRACKER", title_style),
                    Paragraph("OFFICIAL PAYMENT RECEIPT", subtitle_style),
                    Spacer(1, 5)
                ]

                payment_data = []

                for label, key in [
                    ("Receipt Number", "receipt_number"),
                    ("Payment ID", "payment_id"),
                    ("Payment Date", "payment_date"),
                    ("Payment Mode", "payment_mode"),
                    ("Transaction ID", "transaction_id")
                ]:
                    payment_data.append([
                        Paragraph(label, label_style),
                        Paragraph(str(receipt[key]), normal_style)
                    ])

                story.append(make_table(payment_data))
                story.append(Spacer(1, 12))
                story.append(
                    Paragraph("STUDENT DETAILS", section_style)
                )

                student_data = []

                for label, key in [
                    ("Student ID", "student_id"),
                    ("Student Name", "name"),
                    ("Course", "course"),
                    ("Department", "department"),
                    ("Semester", "semester"),
                    ("Academic Year", "academic_year"),
                    ("Contact", "contact")
                ]:
                    student_data.append([
                        Paragraph(label, label_style),
                        Paragraph(str(receipt[key]), normal_style)
                    ])

                story.append(make_table(student_data))
                story.append(Spacer(1, 18))

                amount_label_style = ParagraphStyle(
                    "AmountLabel",
                    parent=styles["Normal"],
                    fontName="Helvetica-Bold",
                    fontSize=11,
                    alignment=TA_CENTER,
                    textColor=colors.HexColor(SIDEBAR)
                )

                amount_table = Table(
                    [
                        [Paragraph("AMOUNT PAID", amount_label_style)],
                        [
                            Paragraph(
                                f"Rs. {receipt['amount']:,.2f}",
                                amount_style
                            )
                        ]
                    ],
                    colWidths=[165 * mm]
                )

                amount_table.setStyle(
                    TableStyle([
                        (
                            "BACKGROUND", (0, 0), (-1, -1),
                            colors.HexColor("#EAF3FA")
                        ),
                        (
                            "BOX", (0, 0), (-1, -1),
                            1, colors.HexColor("#9FC5E0")
                        ),
                        (
                            "TOPPADDING", (0, 0), (-1, 0), 8
                        ),
                        (
                            "BOTTOMPADDING", (0, 0), (-1, 0), 2
                        ),
                        (
                            "TOPPADDING", (0, 1), (-1, 1), 2
                        ),
                        (
                            "BOTTOMPADDING", (0, 1), (-1, 1), 10
                        )
                    ])
                )

                story.append(amount_table)
                story.append(Spacer(1, 20))

                success_style = ParagraphStyle(
                    "Success",
                    parent=styles["Normal"],
                    fontName="Helvetica-Bold",
                    fontSize=10,
                    alignment=TA_CENTER,
                    textColor=colors.HexColor(GREEN)
                )

                thank_style = ParagraphStyle(
                    "ThankYou",
                    parent=styles["Normal"],
                    fontName="Helvetica",
                    fontSize=10,
                    alignment=TA_CENTER,
                    textColor=colors.HexColor(GRAY)
                )

                story.append(
                    Paragraph(
                        "Payment received successfully.",
                        success_style
                    )
                )
                story.append(Spacer(1, 4))
                story.append(
                    Paragraph(
                        "Thank you!",
                        thank_style
                    )
                )

                doc.build(story)

                messagebox.showinfo(
                    "PDF Saved",
                    "Receipt saved successfully as PDF.",
                    parent=receipt_window
                )

            except Exception as e:
                messagebox.showerror(
                    "PDF Save Error",
                    "Could not save PDF receipt.\n\n" + str(e),
                    parent=receipt_window
                )

        # ====================================================
        # SAVE WORD
        # ====================================================

        def save_word():

            if not WORD_AVAILABLE:
                messagebox.showerror(
                    "python-docx Not Installed",
                    "Install python-docx using:\n\n"
                    "py -m pip install python-docx",
                    parent=receipt_window
                )
                return

            filename = filedialog.asksaveasfilename(
                parent=receipt_window,
                title="Save Receipt as Word",
                defaultextension=".docx",
                filetypes=[("Word Documents", "*.docx")],
                initialfile=f"{receipt['receipt_number']}.docx"
            )

            if not filename:
                return

            try:
                document = Document()

                section = document.sections[0]
                section.top_margin = Inches(0.6)
                section.bottom_margin = Inches(0.6)
                section.left_margin = Inches(0.7)
                section.right_margin = Inches(0.7)

                p = document.add_paragraph()
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER

                r = p.add_run("COLLEGE FEE TRACKER")
                r.bold = True
                r.font.size = Pt(20)
                r.font.name = "Arial"

                p = document.add_paragraph()
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER

                r = p.add_run("OFFICIAL PAYMENT RECEIPT")
                r.bold = True
                r.font.size = Pt(11)
                r.font.name = "Arial"

                p = document.add_paragraph()
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                p.add_run("_" * 55)

                def add_section(title, data):

                    p = document.add_paragraph()
                    r = p.add_run(title)
                    r.bold = True
                    r.font.size = Pt(13)
                    r.font.name = "Arial"

                    table = document.add_table(
                        rows=0,
                        cols=2
                    )
                    table.alignment = WD_TABLE_ALIGNMENT.CENTER
                    table.style = "Table Grid"

                    for label, value in data:
                        cells = table.add_row().cells

                        cells[0].text = str(label)
                        cells[1].text = str(value)

                        for cell in cells:
                            cell.vertical_alignment = (
                                WD_CELL_VERTICAL_ALIGNMENT.CENTER
                            )

                        if cells[0].paragraphs[0].runs:
                            cells[0].paragraphs[0].runs[0].bold = True

                    document.add_paragraph()

                add_section(
                    "PAYMENT DETAILS",
                    [
                        ("Receipt Number", receipt["receipt_number"]),
                        ("Payment ID", receipt["payment_id"]),
                        ("Payment Date", receipt["payment_date"]),
                        ("Payment Mode", receipt["payment_mode"]),
                        ("Transaction ID", receipt["transaction_id"])
                    ]
                )

                add_section(
                    "STUDENT DETAILS",
                    [
                        ("Student ID", receipt["student_id"]),
                        ("Student Name", receipt["name"]),
                        ("Course", receipt["course"]),
                        ("Department", receipt["department"]),
                        ("Semester", receipt["semester"]),
                        ("Academic Year", receipt["academic_year"]),
                        ("Contact", receipt["contact"])
                    ]
                )

                amount_table = document.add_table(
                    rows=2,
                    cols=1
                )
                amount_table.alignment = WD_TABLE_ALIGNMENT.CENTER
                amount_table.style = "Table Grid"

                amount_table.cell(0, 0).text = "AMOUNT PAID"
                amount_table.cell(1, 0).text = (
                    f"Rs. {receipt['amount']:,.2f}"
                )

                for row_index in range(2):
                    amount_table.cell(
                        row_index, 0
                    ).paragraphs[0].alignment = (
                        WD_ALIGN_PARAGRAPH.CENTER
                    )

                amount_run = (
                    amount_table.cell(1, 0)
                    .paragraphs[0]
                    .runs[0]
                )
                amount_run.bold = True
                amount_run.font.size = Pt(20)
                amount_run.font.name = "Arial"

                p = document.add_paragraph()
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER

                r = p.add_run(
                    "Payment received successfully."
                )
                r.bold = True
                r.font.size = Pt(11)
                r.font.name = "Arial"

                p = document.add_paragraph()
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER

                r = p.add_run("Thank you!")
                r.font.size = Pt(10)
                r.font.name = "Arial"

                document.save(filename)

                messagebox.showinfo(
                    "Word File Saved",
                    "Receipt saved successfully as Word document.",
                    parent=receipt_window
                )

            except Exception as e:
                messagebox.showerror(
                    "Word Save Error",
                    "Could not save Word receipt.\n\n" + str(e),
                    parent=receipt_window
                )

        # ====================================================
        # SAVE TEXT
        # ====================================================

        def save_text():

            filename = filedialog.asksaveasfilename(
                parent=receipt_window,
                title="Save Receipt as Text",
                defaultextension=".txt",
                filetypes=[("Text Files", "*.txt")],
                initialfile=f"{receipt['receipt_number']}.txt"
            )

            if not filename:
                return

            receipt_text = f"""
============================================================
                    COLLEGE FEE TRACKER
                  OFFICIAL PAYMENT RECEIPT
============================================================

Receipt Number : {receipt['receipt_number']}
Payment ID     : {receipt['payment_id']}

------------------------------------------------------------
STUDENT DETAILS
------------------------------------------------------------

Student ID     : {receipt['student_id']}
Student Name   : {receipt['name']}
Course         : {receipt['course']}
Department     : {receipt['department']}
Semester       : {receipt['semester']}
Academic Year  : {receipt['academic_year']}
Contact        : {receipt['contact']}

------------------------------------------------------------
PAYMENT DETAILS
------------------------------------------------------------

Payment Date   : {receipt['payment_date']}
Payment Mode   : {receipt['payment_mode']}
Transaction ID : {receipt['transaction_id']}

------------------------------------------------------------
AMOUNT PAID    : Rs. {receipt['amount']:,.2f}
------------------------------------------------------------

Payment received successfully.

                    Thank you!
============================================================
"""

            try:
                with open(
                    filename,
                    "w",
                    encoding="utf-8"
                ) as file:
                    file.write(receipt_text)

                messagebox.showinfo(
                    "Text Receipt Saved",
                    "Receipt saved successfully as text file.",
                    parent=receipt_window
                )

            except Exception as e:
                messagebox.showerror(
                    "Save Error",
                    "Could not save text receipt.\n\n" + str(e),
                    parent=receipt_window
                )

        # ====================================================
        # RECEIPT WINDOW BUTTONS
        # ====================================================

        button_frame = tk.Frame(
            card,
            bg=WHITE
        )
        button_frame.pack(pady=12)

        styled_button(
            button_frame,
            "📄  Save PDF",
            save_pdf,
            GREEN,
            GREEN_HOVER
        ).pack(side="left", padx=5)

        styled_button(
            button_frame,
            "📝  Save Word",
            save_word,
            BLUE,
            BLUE_HOVER
        ).pack(side="left", padx=5)

        styled_button(
            button_frame,
            "📃  Save TXT",
            save_text,
            SIDEBAR,
            "#21658F"
        ).pack(side="left", padx=5)

        def close_receipt():
            try:
                receipt_window.grab_release()
            except tk.TclError:
                pass

            try:
                receipt_window.destroy()
            except tk.TclError:
                pass

        styled_button(
            button_frame,
            "✕  Close",
            close_receipt,
            RED,
            RED_HOVER
        ).pack(side="left", padx=5)

        receipt_window.protocol(
            "WM_DELETE_WINDOW",
            close_receipt
        )

    # ========================================================
    # LOAD RECEIPTS
    # ========================================================

    def load_receipts(search_text=""):

        for item in tree.get_children():
            tree.delete(item)

        conn = None

        try:
            conn = get_connection()
            cur = conn.cursor()

            cur.execute("""
                SELECT name
                FROM sqlite_master
                WHERE type='table'
                AND name='payments'
            """)

            if cur.fetchone() is None:
                receipt_count_label.config(text="(0 records)")
                return

            query = """
                SELECT
                    p.payment_id,
                    p.student_id,
                    COALESCE(s.name, 'Unknown Student'),
                    p.amount,
                    p.payment_date,
                    COALESCE(p.payment_mode, 'N/A'),
                    COALESCE(p.transaction_id, 'N/A')
                FROM payments p
                LEFT JOIN students s
                    ON p.student_id = s.student_id
            """

            search_text = search_text.strip()

            if search_text:
                keyword = "%" + search_text + "%"

                query += """
                    WHERE
                        CAST(p.payment_id AS TEXT) LIKE ?
                        OR CAST(p.student_id AS TEXT) LIKE ?
                        OR COALESCE(s.name, '') LIKE ?
                        OR COALESCE(p.payment_mode, '') LIKE ?
                        OR COALESCE(p.transaction_id, '') LIKE ?
                """

                cur.execute(
                    query + " ORDER BY p.payment_id DESC",
                    (
                        keyword,
                        keyword,
                        keyword,
                        keyword,
                        keyword
                    )
                )
            else:
                cur.execute(
                    query + " ORDER BY p.payment_id DESC"
                )

            rows = cur.fetchall()

            for row in rows:
                try:
                    amount_value = float(row[3] or 0)
                except (ValueError, TypeError):
                    amount_value = 0.0

                tree.insert(
                    "",
                    "end",
                    values=(
                        row[0],
                        row[1],
                        row[2],
                        f"₹{amount_value:,.2f}",
                        row[4] or "N/A",
                        row[5] or "N/A",
                        row[6] or "N/A"
                    )
                )

            receipt_count_label.config(
                text=f"({len(rows)} records)"
            )

        except sqlite3.Error as e:
            messagebox.showerror(
                "Database Error",
                "Could not load receipts.\n\n" + str(e),
                parent=parent_frame.winfo_toplevel()
            )

        finally:
            if conn:
                conn.close()

    # ========================================================
    # REFRESH
    # ========================================================

    def refresh_receipts():
        search_entry.delete(0, tk.END)
        load_receipts()

    # ========================================================
    # TOP BUTTONS
    # ========================================================

    styled_button(
        action_frame,
        "🧾  Generate Receipt",
        generate_receipt,
        GREEN,
        GREEN_HOVER
    ).pack(
        side="right",
        padx=5
    )

    styled_button(
        action_frame,
        "↻  Refresh",
        refresh_receipts,
        BLUE,
        BLUE_HOVER
    ).pack(
        side="right",
        padx=5
    )

    # ========================================================
    # BOTTOM ACTION BAR
    # IMPORTANT: Pack this BEFORE the expandable table.
    # ========================================================

    bottom_frame = tk.Frame(
        body,
        bg=BG,
        height=72
    )

    bottom_frame.pack(
        side="bottom",
        fill="x",
        pady=(15, 0)
    )

    bottom_frame.pack_propagate(False)

    button_container = tk.Frame(
        bottom_frame,
        bg=BG
    )

    button_container.pack(
        anchor="center",
        pady=8
    )

    styled_button(
        button_container,
        "🧾  View Selected Receipt",
        generate_receipt,
        BLUE,
        BLUE_HOVER
    ).pack(
        side="left",
        padx=10
    )

    # ========================================================
    # TABLE NOW EXPANDS INTO ALL REMAINING SPACE
    # ========================================================

    table_card.pack(
        fill="both",
        expand=True
    )

    # ========================================================
    # SEARCH
    # ========================================================

    def perform_search(_event=None):
        load_receipts(search_entry.get())

    search_entry.bind(
        "<KeyRelease>",
        perform_search
    )

    # ========================================================
    # DOUBLE CLICK
    # ========================================================

    tree.bind(
        "<Double-1>",
        lambda _event: generate_receipt()
    )

    # ========================================================
    # INITIAL LOAD
    # ========================================================

    load_receipts()


# ============================================================
# BACKWARD-COMPATIBLE STANDALONE TEST
# ============================================================

def open_receipt_management(parent=None):

    # If called by old code with a parent, put the page
    # directly into that parent instead of creating another
    # dashboard/sidebar window.
    if parent is not None:
        show_receipt_management_page(parent)
        return

    window = tk.Tk()
    window.title("College Fee Tracker - Receipt Management")

    try:
        window.state("zoomed")
    except tk.TclError:
        window.geometry("1400x800")

    window.configure(bg="#F3F7FB")

    show_receipt_management_page(window)

    window.mainloop()


# ============================================================
# RUN DIRECTLY
# ============================================================

if __name__ == "__main__":
    open_receipt_management()
