
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

DB_NAME = "college_fee_tracker.db"


def get_connection():
    return sqlite3.connect(DB_NAME)


def show_fee_management_page(parent_frame):
    """Render Fee Management inside the admin dashboard content frame."""

    for widget in parent_frame.winfo_children():
        widget.destroy()

    # ============================================================
    # COLORS
    # ============================================================
    WHITE = "#FFFFFF"
    TEXT = "#1F2937"
    GRAY = "#6B7280"
    BORDER = "#D6E2EC"
    BLUE = "#1976D2"
    BLUE_HOVER = "#1565C0"
    GREEN = "#2E7D32"
    RED = "#D32F2F"
    LIGHT_BG = "#F3F7FB"

    page_window = parent_frame.winfo_toplevel()

    # ============================================================
    # DATABASE
    # ============================================================
    def initialize_fee_table():
        try:
            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                CREATE TABLE IF NOT EXISTS fees (
                    fee_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id INTEGER NOT NULL,
                    total_fee REAL NOT NULL,
                    paid_fee REAL NOT NULL DEFAULT 0,
                    pending_fee REAL NOT NULL DEFAULT 0,
                    due_date TEXT,
                    status TEXT,
                    FOREIGN KEY(student_id) REFERENCES students(student_id)
                )
            """)

            conn.commit()
            conn.close()

        except sqlite3.Error as e:
            messagebox.showerror(
                "Database Error",
                f"Could not create fees table.\n\n{e}",
                parent=page_window
            )

    initialize_fee_table()

    # ============================================================
    # BODY
    # ============================================================
    body = tk.Frame(parent_frame, bg=LIGHT_BG)
    body.pack(fill="both", expand=True, padx=30, pady=25)

    # ============================================================
    # BUTTON
    # ============================================================
    def styled_button(parent, text, command, bg=BLUE):
        button = tk.Button(
            parent,
            text=text,
            font=("Arial", 11, "bold"),
            bg=bg,
            fg=WHITE,
            activebackground=BLUE_HOVER if bg == BLUE else bg,
            activeforeground=WHITE,
            bd=0,
            padx=18,
            pady=10,
            cursor="hand2",
            command=command
        )

        def enter(event):
            if bg == BLUE:
                button.configure(bg=BLUE_HOVER)

        def leave(event):
            if bg == BLUE:
                button.configure(bg=bg)

        button.bind("<Enter>", enter)
        button.bind("<Leave>", leave)

        return button

    # ============================================================
    # ACTION AREA
    # ============================================================
    action_frame = tk.Frame(body, bg=LIGHT_BG)
    action_frame.pack(fill="x", pady=(0, 18))

    search_frame = tk.Frame(
        action_frame,
        bg=WHITE,
        highlightbackground=BORDER,
        highlightthickness=1
    )
    search_frame.pack(
        side="left",
        fill="x",
        expand=True,
        padx=(0, 15)
    )

    tk.Label(
        search_frame,
        text="🔍",
        font=("Arial", 14),
        bg=WHITE,
        fg=BLUE
    ).pack(side="left", padx=(15, 5))

    search_entry = tk.Entry(
        search_frame,
        font=("Arial", 12),
        bd=0,
        bg=WHITE,
        fg=TEXT
    )
    search_entry.pack(side="left", fill="x", expand=True, ipady=11)

    # ============================================================
    # TABLE CARD
    # ============================================================
    table_card = tk.Frame(
        body,
        bg=WHITE,
        highlightbackground=BORDER,
        highlightthickness=1
    )
    table_card.pack(fill="both", expand=True)

    table_header = tk.Frame(table_card, bg=WHITE, height=65)
    table_header.pack(fill="x")
    table_header.pack_propagate(False)

    tk.Label(
        table_header,
        text="Fee Records",
        font=("Arial", 17, "bold"),
        fg=TEXT,
        bg=WHITE
    ).pack(side="left", padx=20)

    fee_count_label = tk.Label(
        table_header,
        text="",
        font=("Arial", 10),
        fg=GRAY,
        bg=WHITE
    )
    fee_count_label.pack(side="left", padx=5)

    # ============================================================
    # TREEVIEW
    # ============================================================
    tree_frame = tk.Frame(table_card, bg=WHITE)
    tree_frame.pack(fill="both", expand=True, padx=15, pady=(0, 15))

    columns = (
        "fee_id", "student_id", "name", "course",
        "total_fee", "paid_fee", "pending_fee",
        "due_date", "status"
    )

    headings = {
        "fee_id": "Fee ID",
        "student_id": "Student ID",
        "name": "Student Name",
        "course": "Course",
        "total_fee": "Total Fee",
        "paid_fee": "Paid Fee",
        "pending_fee": "Pending Fee",
        "due_date": "Due Date",
        "status": "Status"
    }

    widths = {
        "fee_id": 70,
        "student_id": 90,
        "name": 160,
        "course": 110,
        "total_fee": 120,
        "paid_fee": 120,
        "pending_fee": 130,
        "due_date": 120,
        "status": 110
    }

    style = ttk.Style()
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    # Create the custom Treeview layout before configuring it.
    # This prevents: "Layout FeeTreeview not found".
    try:
        style.layout("FeeTreeview", style.layout("Treeview"))
    except tk.TclError:
        pass

    style.configure(
        "FeeTreeview",
        background="white",
        foreground=TEXT,
        rowheight=42,
        fieldbackground="white",
        font=("Arial", 10)
    )

    style.configure(
        "FeeTreeview.Heading",
        background="#EAF2F8",
        foreground=TEXT,
        font=("Arial", 10, "bold"),
        padding=10
    )

    style.map(
        "FeeTreeview",
        background=[("selected", "#DCEEFF")],
        foreground=[("selected", TEXT)]
    )

    tree = ttk.Treeview(
        tree_frame,
        columns=columns,
        show="headings",
        selectmode="browse",
        style="FeeTreeview"
    )

    for column in columns:
        tree.heading(column, text=headings[column])
        tree.column(
            column,
            width=widths[column],
            anchor="center",
            stretch=True
        )

    scrollbar_y = ttk.Scrollbar(
        tree_frame,
        orient="vertical",
        command=tree.yview
    )
    scrollbar_x = ttk.Scrollbar(
        tree_frame,
        orient="horizontal",
        command=tree.xview
    )

    tree.configure(
        yscrollcommand=scrollbar_y.set,
        xscrollcommand=scrollbar_x.set
    )

    tree.grid(row=0, column=0, sticky="nsew")
    scrollbar_y.grid(row=0, column=1, sticky="ns")
    scrollbar_x.grid(row=1, column=0, sticky="ew")

    tree_frame.grid_rowconfigure(0, weight=1)
    tree_frame.grid_columnconfigure(0, weight=1)

    # ============================================================
    # DATABASE HELPERS
    # ============================================================
    def get_students():
        conn = None
        try:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT student_id, name
                FROM students
                ORDER BY student_id
            """)
            return cursor.fetchall()
        except sqlite3.Error as e:
            messagebox.showerror(
                "Database Error",
                f"Could not load students.\n\n{e}",
                parent=page_window
            )
            return []
        finally:
            if conn:
                conn.close()

    def load_fees(search_text=""):
        for item in tree.get_children():
            tree.delete(item)

        conn = None

        try:
            conn = get_connection()
            cursor = conn.cursor()

            query = """
                SELECT
                    f.fee_id,
                    f.student_id,
                    s.name,
                    s.course,
                    f.total_fee,
                    f.paid_fee,
                    f.pending_fee,
                    f.due_date,
                    f.status
                FROM fees f
                JOIN students s
                    ON f.student_id = s.student_id
            """

            params = ()

            if search_text.strip():
                keyword = "%" + search_text.strip() + "%"
                query += """
                    WHERE
                        CAST(f.fee_id AS TEXT) LIKE ?
                        OR CAST(f.student_id AS TEXT) LIKE ?
                        OR s.name LIKE ?
                        OR s.course LIKE ?
                        OR f.status LIKE ?
                """
                params = (
                    keyword, keyword, keyword,
                    keyword, keyword
                )

            query += " ORDER BY f.fee_id"

            cursor.execute(query, params)
            rows = cursor.fetchall()

            for row in rows:
                formatted_row = list(row)
                formatted_row[4] = f"₹{row[4]:,.2f}"
                formatted_row[5] = f"₹{row[5]:,.2f}"
                formatted_row[6] = f"₹{row[6]:,.2f}"

                tree.insert("", "end", values=formatted_row)

            fee_count_label.config(text=f"({len(rows)} records)")

        except sqlite3.Error as e:
            messagebox.showerror(
                "Database Error",
                f"Could not load fee records.\n\n{e}",
                parent=page_window
            )
        finally:
            if conn:
                conn.close()

    # ============================================================
    # INLINE FORM
    # ============================================================
    form_card = tk.Frame(
        body,
        bg=WHITE,
        highlightbackground=BORDER,
        highlightthickness=1
    )

    form_title = tk.Label(
        form_card,
        text="Add Fee Record",
        font=("Arial", 17, "bold"),
        fg=TEXT,
        bg=WHITE
    )

    form_title.pack(anchor="w", padx=20, pady=(15, 5))

    form_subtitle = tk.Label(
        form_card,
        text="Select a student and enter fee details.",
        font=("Arial", 10),
        fg=GRAY,
        bg=WHITE
    )
    form_subtitle.pack(anchor="w", padx=20, pady=(0, 12))

    form_grid = tk.Frame(form_card, bg=WHITE)
    form_grid.pack(fill="x", padx=20, pady=(0, 15))

    tk.Label(
        form_grid, text="Student", font=("Arial", 10, "bold"),
        fg=TEXT, bg=WHITE
    ).grid(row=0, column=0, sticky="w", padx=(0, 10), pady=5)

    tk.Label(
        form_grid, text="Total Fee", font=("Arial", 10, "bold"),
        fg=TEXT, bg=WHITE
    ).grid(row=0, column=1, sticky="w", padx=10, pady=5)

    tk.Label(
        form_grid, text="Paid Fee", font=("Arial", 10, "bold"),
        fg=TEXT, bg=WHITE
    ).grid(row=0, column=2, sticky="w", padx=10, pady=5)

    tk.Label(
        form_grid, text="Due Date", font=("Arial", 10, "bold"),
        fg=TEXT, bg=WHITE
    ).grid(row=0, column=3, sticky="w", padx=10, pady=5)

    student_combo = ttk.Combobox(
        form_grid,
        state="readonly",
        font=("Arial", 10)
    )
    student_combo.grid(
        row=1, column=0, sticky="ew",
        padx=(0, 10), ipady=5
    )

    total_entry = tk.Entry(
        form_grid, font=("Arial", 10),
        bd=1, relief="solid"
    )
    total_entry.grid(
        row=1, column=1, sticky="ew",
        padx=10, ipady=5
    )

    paid_entry = tk.Entry(
        form_grid, font=("Arial", 10),
        bd=1, relief="solid"
    )
    paid_entry.grid(
        row=1, column=2, sticky="ew",
        padx=10, ipady=5
    )

    due_entry = tk.Entry(
        form_grid, font=("Arial", 10),
        bd=1, relief="solid"
    )
    due_entry.grid(
        row=1, column=3, sticky="ew",
        padx=10, ipady=5
    )

    for i in range(4):
        form_grid.grid_columnconfigure(i, weight=1)

    form_buttons = tk.Frame(form_card, bg=WHITE)
    form_buttons.pack(fill="x", padx=20, pady=(0, 15))

    form_mode = {"value": "add"}
    editing_fee_id = {"value": None}

    def refresh_student_combo():
        students = get_students()
        student_combo["values"] = [
            f"{student_id} - {name}"
            for student_id, name in students
        ]

    def clear_form():
        form_mode["value"] = "add"
        editing_fee_id["value"] = None
        form_title.config(text="Add Fee Record")
        form_subtitle.config(
            text="Select a student and enter fee details."
        )

        student_combo.set("")
        total_entry.delete(0, tk.END)
        paid_entry.delete(0, tk.END)
        due_entry.delete(0, tk.END)

        cancel_button.pack_forget()
        save_button.config(text="＋  Add Fee Record", bg=BLUE)

    def save_fee():
        student_value = student_combo.get().strip()
        total_value = total_entry.get().strip()
        paid_value = paid_entry.get().strip()
        due_date = due_entry.get().strip()

        if not student_value:
            messagebox.showwarning(
                "Missing Information",
                "Please select a student.",
                parent=page_window
            )
            return

        if not total_value:
            messagebox.showwarning(
                "Missing Information",
                "Please enter total fee.",
                parent=page_window
            )
            return

        if not paid_value:
            messagebox.showwarning(
                "Missing Information",
                "Please enter paid fee.",
                parent=page_window
            )
            return

        if not due_date:
            messagebox.showwarning(
                "Missing Information",
                "Please enter due date.",
                parent=page_window
            )
            return

        try:
            student_id = int(student_value.split(" - ")[0])
            total_fee = float(total_value)
            paid_fee = float(paid_value)
        except ValueError:
            messagebox.showerror(
                "Invalid Amount",
                "Please enter valid numeric fee amounts.",
                parent=page_window
            )
            return

        if total_fee <= 0:
            messagebox.showerror(
                "Invalid Total Fee",
                "Total fee must be greater than 0.",
                parent=page_window
            )
            return

        if paid_fee < 0:
            messagebox.showerror(
                "Invalid Paid Fee",
                "Paid fee cannot be negative.",
                parent=page_window
            )
            return

        if paid_fee > total_fee:
            messagebox.showerror(
                "Invalid Amount",
                "Paid fee cannot be greater than total fee.",
                parent=page_window
            )
            return

        pending_fee = total_fee - paid_fee

        if pending_fee == 0:
            status = "Paid"
        elif paid_fee == 0:
            status = "Pending"
        else:
            status = "Partial"

        conn = None

        try:
            conn = get_connection()
            cursor = conn.cursor()

            if form_mode["value"] == "add":
                cursor.execute("""
                    INSERT INTO fees
                    (
                        student_id,
                        total_fee,
                        paid_fee,
                        pending_fee,
                        due_date,
                        status
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    student_id,
                    total_fee,
                    paid_fee,
                    pending_fee,
                    due_date,
                    status
                ))
                success_text = "Fee record added successfully!"

            else:
                cursor.execute("""
                    UPDATE fees
                    SET
                        student_id = ?,
                        total_fee = ?,
                        paid_fee = ?,
                        pending_fee = ?,
                        due_date = ?,
                        status = ?
                    WHERE fee_id = ?
                """, (
                    student_id,
                    total_fee,
                    paid_fee,
                    pending_fee,
                    due_date,
                    status,
                    editing_fee_id["value"]
                ))
                success_text = "Fee record updated successfully!"

            conn.commit()

            messagebox.showinfo(
                "Success",
                success_text,
                parent=page_window
            )

            clear_form()
            load_fees()

        except sqlite3.Error as e:
            messagebox.showerror(
                "Database Error",
                str(e),
                parent=page_window
            )
        finally:
            if conn:
                conn.close()

    def edit_selected_fee():
        selected = tree.selection()

        if not selected:
            messagebox.showwarning(
                "Select Record",
                "Please select a fee record to update.",
                parent=page_window
            )
            return

        values = tree.item(selected[0], "values")

        editing_fee_id["value"] = values[0]
        form_mode["value"] = "update"

        form_title.config(text="Update Fee Record")
        form_subtitle.config(
            text=f"Editing Fee ID {values[0]}. Update the details below."
        )

        student_values = student_combo["values"]
        selected_student = ""

        for item in student_values:
            if item.startswith(str(values[1]) + " - "):
                selected_student = item
                break

        student_combo.set(selected_student)

        total_entry.delete(0, tk.END)
        total_entry.insert(
            0,
            str(values[4]).replace("₹", "").replace(",", "")
        )

        paid_entry.delete(0, tk.END)
        paid_entry.insert(
            0,
            str(values[5]).replace("₹", "").replace(",", "")
        )

        due_entry.delete(0, tk.END)
        due_entry.insert(0, values[7])

        save_button.config(
            text="✓  Update Fee Record",
            bg=GREEN
        )

        if not cancel_button.winfo_ismapped():
            cancel_button.pack(side="left", padx=(8, 0))

        form_card.pack(
            fill="x",
            before=action_frame,
            pady=(0, 18)
        )

    def delete_selected_fee():
        selected = tree.selection()

        if not selected:
            messagebox.showwarning(
                "Select Record",
                "Please select a fee record to delete.",
                parent=page_window
            )
            return

        values = tree.item(selected[0], "values")
        fee_id = values[0]
        student_name = values[2]

        confirm = messagebox.askyesno(
            "Delete Fee Record",
            f"Are you sure you want to delete this fee record?\n\n"
            f"Fee ID: {fee_id}\n"
            f"Student: {student_name}\n\n"
            f"This action cannot be undone.",
            parent=page_window
        )

        if not confirm:
            return

        conn = None

        try:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute(
                "DELETE FROM fees WHERE fee_id = ?",
                (fee_id,)
            )
            conn.commit()

            messagebox.showinfo(
                "Deleted",
                "Fee record deleted successfully.",
                parent=page_window
            )

            load_fees()

        except sqlite3.Error as e:
            messagebox.showerror(
                "Database Error",
                str(e),
                parent=page_window
            )
        finally:
            if conn:
                conn.close()

    save_button = styled_button(
        form_buttons,
        "＋  Add Fee Record",
        save_fee
    )
    save_button.pack(side="left")

    cancel_button = styled_button(
        form_buttons,
        "✕  Cancel",
        clear_form,
        bg=GRAY
    )

    # ============================================================
    # ACTION BUTTONS
    # ============================================================
    def perform_search(event=None):
        load_fees(search_entry.get())

    search_entry.bind("<KeyRelease>", perform_search)

    def refresh_fees():
        search_entry.delete(0, tk.END)
        clear_form()
        refresh_student_combo()
        load_fees()

    styled_button(
        action_frame,
        "↻  Refresh",
        refresh_fees
    ).pack(side="right", padx=5)

    def add_fee():
        clear_form()
        refresh_student_combo()
        form_card.pack(
            fill="x",
            before=action_frame,
            pady=(0, 18)
        )
        student_combo.focus_set()

    styled_button(
        action_frame,
        "＋  Add Fee",
        add_fee
    ).pack(side="right", padx=5)

    # ============================================================
    # BOTTOM BUTTONS
    # ============================================================
    bottom_frame = tk.Frame(body, bg=LIGHT_BG)
    bottom_frame.pack(fill="x", pady=(15, 0))

    styled_button(
        bottom_frame,
        "✎  Update Selected",
        edit_selected_fee,
        bg=GREEN
    ).pack(side="left", padx=(0, 8))

    styled_button(
        bottom_frame,
        "🗑  Delete Selected",
        delete_selected_fee,
        bg=RED
    ).pack(side="left", padx=8)

    # ============================================================
    # NAVIGATION HELPERS
    # ============================================================
    # These are intentionally not used to create new admin windows.
    # The Admin Dashboard controls navigation between internal pages.

    def double_click_update(event=None):
        edit_selected_fee()

    tree.bind("<Double-1>", double_click_update)

    # Initial setup
    refresh_student_combo()
    load_fees()


def open_fee_management(parent=None):
    """
    Backward-compatible wrapper.

    When called by the new Admin Dashboard, render inside its page frame.
    When run directly, create a standalone test window.
    """
    if parent is not None:
        show_fee_management_page(parent)
        return

    window = tk.Tk()
    window.title("College Fee Tracker - Fee Management")
    window.state("zoomed")
    window.configure(bg="#F3F7FB")

    show_fee_management_page(window)
    window.mainloop()


if __name__ == "__main__":
    open_fee_management()
