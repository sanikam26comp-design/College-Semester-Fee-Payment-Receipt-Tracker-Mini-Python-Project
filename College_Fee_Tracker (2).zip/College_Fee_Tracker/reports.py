import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3
import csv


# ============================================================
# DATABASE
# ============================================================

DB_NAME = "college_fee_tracker.db"


def get_connection():
    return sqlite3.connect(DB_NAME)


# ============================================================
# REPORTS PAGE - INTERNAL PAGE VERSION
# ============================================================

def show_reports_page(parent_frame):
    """
    Display Reports inside the admin dashboard page container.

    This function does NOT create a Toplevel window.
    It only replaces the contents of the supplied parent_frame.
    """

    # ------------------------------------------------------------
    # CLEAR CURRENT ADMIN PAGE
    # ------------------------------------------------------------
    for widget in parent_frame.winfo_children():
        widget.destroy()

    root = parent_frame.winfo_toplevel()

    # ------------------------------------------------------------
    # COLORS
    # ------------------------------------------------------------
    SIDEBAR = "#174A70"
    BLUE = "#1976D2"
    BLUE_HOVER = "#1565C0"
    WHITE = "#FFFFFF"
    TEXT = "#1F2937"
    GRAY = "#6B7280"
    BORDER = "#D6E2EC"
    LIGHT_BLUE = "#EAF3FA"
    GREEN = "#2E7D32"
    RED = "#D32F2F"
    ORANGE = "#EF6C00"
    BG = "#F3F7FB"

    # ------------------------------------------------------------
    # TREEVIEW STYLE
    # ------------------------------------------------------------
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    style.configure(
        "Reports.Treeview",
        background=WHITE,
        foreground=TEXT,
        rowheight=42,
        fieldbackground=WHITE,
        font=("Arial", 10),
        borderwidth=0,
    )

    style.configure(
        "Reports.Treeview.Heading",
        background="#EAF2F8",
        foreground=TEXT,
        font=("Arial", 10, "bold"),
        padding=10,
        relief="flat",
    )

    style.map(
        "Reports.Treeview",
        background=[("selected", "#DCEEFF")],
        foreground=[("selected", TEXT)],
    )

    # ------------------------------------------------------------
    # HELPERS
    # ------------------------------------------------------------
    def show_error(title, message):
        messagebox.showerror(title, message, parent=root)

    def show_warning(title, message):
        messagebox.showwarning(title, message, parent=root)

    def show_info(title, message):
        messagebox.showinfo(title, message, parent=root)

    def styled_button(parent_widget, text, command, bg=BLUE):
        button = tk.Button(
            parent_widget,
            text=text,
            font=("Arial", 11, "bold"),
            bg=bg,
            fg=WHITE,
            activebackground=BLUE_HOVER if bg != RED else "#B71C1C",
            activeforeground=WHITE,
            bd=0,
            relief="flat",
            padx=18,
            pady=10,
            cursor="hand2",
            command=command,
        )

        hover_color = BLUE_HOVER if bg == BLUE else bg
        if bg == GREEN:
            hover_color = "#1B5E20"
        elif bg == SIDEBAR:
            hover_color = "#21658F"
        elif bg == RED:
            hover_color = "#B71C1C"

        def on_enter(event):
            button.configure(bg=hover_color)

        def on_leave(event):
            button.configure(bg=bg)

        button.bind("<Enter>", on_enter)
        button.bind("<Leave>", on_leave)
        return button

    def create_tree(parent_widget, columns, headings, widths):
        frame = tk.Frame(
            parent_widget,
            bg=WHITE,
            highlightbackground=BORDER,
            highlightthickness=1,
        )

        tree = ttk.Treeview(
            frame,
            columns=columns,
            show="headings",
            selectmode="browse",
            style="Reports.Treeview",
        )

        for column in columns:
            tree.heading(column, text=headings[column])
            tree.column(
                column,
                width=widths.get(column, 120),
                anchor="center",
                stretch=True,
            )

        scrollbar_y = ttk.Scrollbar(
            frame,
            orient="vertical",
            command=tree.yview,
        )
        scrollbar_x = ttk.Scrollbar(
            frame,
            orient="horizontal",
            command=tree.xview,
        )

        tree.configure(
            yscrollcommand=scrollbar_y.set,
            xscrollcommand=scrollbar_x.set,
        )

        tree.pack(
            side="left",
            fill="both",
            expand=True,
        )
        scrollbar_y.pack(side="right", fill="y")
        scrollbar_x.pack(side="bottom", fill="x")

        return frame, tree

    # ============================================================
    # MAIN REPORT PAGE
    # ============================================================

    page = tk.Frame(parent_frame, bg=BG)
    page.pack(fill="both", expand=True)

    # ------------------------------------------------------------
    # BODY
    # ------------------------------------------------------------
    body = tk.Frame(page, bg=BG)
    body.pack(fill="both", expand=True, padx=30, pady=25)

    # ------------------------------------------------------------
    # SUMMARY CARDS
    # ------------------------------------------------------------
    summary_frame = tk.Frame(body, bg=BG)
    summary_frame.pack(fill="x", pady=(0, 20))

    def create_card(parent_widget, title, value, icon, color):
        card = tk.Frame(
            parent_widget,
            bg=WHITE,
            highlightbackground=BORDER,
            highlightthickness=1,
        )
        card.pack(side="left", fill="both", expand=True, padx=7)

        tk.Label(
            card,
            text=icon,
            font=("Arial", 24),
            bg=WHITE,
            fg=color,
        ).pack(side="left", padx=(18, 10), pady=18)

        text_frame = tk.Frame(card, bg=WHITE)
        text_frame.pack(side="left", pady=14)

        tk.Label(
            text_frame,
            text=title,
            font=("Arial", 10, "bold"),
            fg=GRAY,
            bg=WHITE,
        ).pack(anchor="w")

        value_label = tk.Label(
            text_frame,
            text=value,
            font=("Arial", 18, "bold"),
            fg=color,
            bg=WHITE,
        )
        value_label.pack(anchor="w", pady=(3, 0))

        return value_label

    student_value = create_card(
        summary_frame, "Total Students", "0", "👨‍🎓", BLUE
    )
    total_fee_value = create_card(
        summary_frame, "Total Fees", "₹0.00", "₹", SIDEBAR
    )
    collected_value = create_card(
        summary_frame, "Collected", "₹0.00", "✓", GREEN
    )
    pending_value = create_card(
        summary_frame, "Pending", "₹0.00", "⏳", ORANGE
    )
    percentage_value = create_card(
        summary_frame, "Collection", "0%", "📊", BLUE
    )

    # ------------------------------------------------------------
    # ACTION FRAME / SEARCH
    # ------------------------------------------------------------
    action_frame = tk.Frame(body, bg=BG)
    action_frame.pack(fill="x", pady=(0, 15))

    search_frame = tk.Frame(
        action_frame,
        bg=WHITE,
        highlightbackground=BORDER,
        highlightthickness=1,
    )
    search_frame.pack(side="left", fill="x", expand=True, padx=(0, 10))

    tk.Label(
        search_frame,
        text="🔍",
        font=("Arial", 14),
        bg=WHITE,
        fg=BLUE,
    ).pack(side="left", padx=(15, 5))

    search_entry = tk.Entry(
        search_frame,
        font=("Arial", 12),
        bd=0,
        bg=WHITE,
        fg=TEXT,
        insertbackground=TEXT,
    )
    search_entry.pack(side="left", fill="x", expand=True, ipady=11)

    # ------------------------------------------------------------
    # TABLE CARD
    # ------------------------------------------------------------
    table_card = tk.Frame(
        body,
        bg=WHITE,
        highlightbackground=BORDER,
        highlightthickness=1,
    )
    table_card.pack(fill="both", expand=True)

    table_header = tk.Frame(table_card, bg=WHITE, height=60)
    table_header.pack(fill="x")
    table_header.pack_propagate(False)

    tk.Label(
        table_header,
        text="Student Fee Report",
        font=("Arial", 17, "bold"),
        fg=TEXT,
        bg=WHITE,
    ).pack(side="left", padx=20)

    report_count_label = tk.Label(
        table_header,
        text="",
        font=("Arial", 10),
        fg=GRAY,
        bg=WHITE,
    )
    report_count_label.pack(side="left")

    columns = (
        "student_id",
        "name",
        "course",
        "department",
        "semester",
        "total_fee",
        "paid_fee",
        "pending_fee",
        "status",
    )

    headings = {
        "student_id": "Student ID",
        "name": "Student Name",
        "course": "Course",
        "department": "Department",
        "semester": "Semester",
        "total_fee": "Total Fee",
        "paid_fee": "Paid",
        "pending_fee": "Pending",
        "status": "Status",
    }

    widths = {
        "student_id": 100,
        "name": 170,
        "course": 120,
        "department": 160,
        "semester": 90,
        "total_fee": 130,
        "paid_fee": 130,
        "pending_fee": 130,
        "status": 140,
    }

    tree_frame, tree = create_tree(
        table_card,
        columns,
        headings,
        widths,
    )
    tree_frame.pack(fill="both", expand=True, padx=15, pady=(0, 15))

    # ------------------------------------------------------------
    # LOAD MAIN REPORT
    # ------------------------------------------------------------
    def load_report(search_text=""):
        for item in tree.get_children():
            tree.delete(item)

        conn = None

        try:
            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("SELECT COUNT(*) FROM students")
            total_students = cursor.fetchone()[0] or 0

            cursor.execute(
                "SELECT COALESCE(SUM(total_fee), 0) FROM fees"
            )
            total_fee = cursor.fetchone()[0] or 0

            cursor.execute(
                "SELECT COALESCE(SUM(paid_fee), 0) FROM fees"
            )
            collected = cursor.fetchone()[0] or 0

            cursor.execute(
                "SELECT COALESCE(SUM(pending_fee), 0) FROM fees"
            )
            pending = cursor.fetchone()[0] or 0

            percentage = (collected / total_fee * 100) if total_fee > 0 else 0

            student_value.config(text=str(total_students))
            total_fee_value.config(text=f"₹{total_fee:,.2f}")
            collected_value.config(text=f"₹{collected:,.2f}")
            pending_value.config(text=f"₹{pending:,.2f}")
            percentage_value.config(text=f"{percentage:.1f}%")

            query = """
                SELECT
                    s.student_id,
                    s.name,
                    s.course,
                    s.department,
                    s.semester,
                    COALESCE(f.total_fee, 0),
                    COALESCE(f.paid_fee, 0),
                    COALESCE(f.pending_fee, 0),
                    COALESCE(f.status, 'Pending')
                FROM students s
                LEFT JOIN fees f
                    ON s.student_id = f.student_id
            """

            params = ()

            if search_text.strip():
                keyword = "%" + search_text.strip() + "%"
                query += """
                    WHERE
                        CAST(s.student_id AS TEXT) LIKE ?
                        OR s.name LIKE ?
                        OR s.course LIKE ?
                        OR s.department LIKE ?
                        OR f.status LIKE ?
                """
                params = (
                    keyword,
                    keyword,
                    keyword,
                    keyword,
                    keyword,
                )

            query += " ORDER BY s.student_id"
            cursor.execute(query, params)
            rows = cursor.fetchall()

            for row in rows:
                formatted_row = [
                    row[0],
                    row[1],
                    row[2] or "N/A",
                    row[3] or "N/A",
                    row[4] if row[4] is not None else "N/A",
                    f"₹{row[5]:,.2f}",
                    f"₹{row[6]:,.2f}",
                    f"₹{row[7]:,.2f}",
                    row[8],
                ]
                tree.insert("", "end", values=formatted_row)

            report_count_label.config(text=f"({len(rows)} records)")

        except sqlite3.Error as e:
            show_error("Database Error", f"Could not generate report.\n\n{e}")
        finally:
            if conn:
                conn.close()

    # ------------------------------------------------------------
    # SEARCH
    # ------------------------------------------------------------
    def perform_search(event=None):
        load_report(search_entry.get())

    search_entry.bind("<KeyRelease>", perform_search)

    # ------------------------------------------------------------
    # REFRESH
    # ------------------------------------------------------------
    def refresh_report():
        search_entry.delete(0, tk.END)
        load_report()

    styled_button(
        action_frame,
        "↻  Refresh",
        refresh_report,
    ).pack(side="right", padx=5)

    # ------------------------------------------------------------
    # EXPORT CSV
    # ------------------------------------------------------------
    def export_report():
        items = tree.get_children()

        if not items:
            show_warning("No Data", "There is no report data to export.")
            return

        filename = filedialog.asksaveasfilename(
            parent=root,
            title="Export Fee Report",
            defaultextension=".csv",
            filetypes=[
                ("CSV Files", "*.csv"),
                ("All Files", "*.*"),
            ],
            initialfile="student_fee_report.csv",
        )

        if not filename:
            return

        try:
            with open(
                filename,
                "w",
                newline="",
                encoding="utf-8-sig",
            ) as file:
                writer = csv.writer(file)

                writer.writerow([
                    "Student ID",
                    "Student Name",
                    "Course",
                    "Department",
                    "Semester",
                    "Total Fee",
                    "Paid",
                    "Pending",
                    "Status",
                ])

                for item in items:
                    writer.writerow(tree.item(item, "values"))

            show_info(
                "Export Successful",
                "Fee report exported successfully.",
            )

        except Exception as e:
            show_error("Export Error", str(e))

    styled_button(
        action_frame,
        "⬇  Export CSV",
        export_report,
        bg=GREEN,
    ).pack(side="right", padx=5)

    # ------------------------------------------------------------
    # INTERNAL REPORT VIEW HELPER
    # ------------------------------------------------------------
    def clear_page():
        for widget in parent_frame.winfo_children():
            widget.destroy()

    def create_internal_title(parent_widget, title, subtitle, back_command=None):
        top = tk.Frame(parent_widget, bg=BG)
        top.pack(fill="x", pady=(0, 15))

        left = tk.Frame(top, bg=BG)
        left.pack(side="left", fill="x", expand=True)

        tk.Label(
            left,
            text=title,
            font=("Arial", 21, "bold"),
            fg=TEXT,
            bg=BG,
        ).pack(anchor="w")

        tk.Label(
            left,
            text=subtitle,
            font=("Arial", 10),
            fg="#78909C",
            bg=BG,
        ).pack(anchor="w", pady=(3, 0))

        if back_command is not None:
            styled_button(
                top,
                "←  Back to Reports",
                back_command,
                bg=SIDEBAR,
            ).pack(side="right")

        return top

    # ============================================================
    # INTERNAL PAYMENT REPORT
    # ============================================================
    def show_payment_report():
        clear_page()
        page_body = tk.Frame(parent_frame, bg=BG)
        page_body.pack(fill="both", expand=True, padx=30, pady=25)

        create_internal_title(
            page_body,
            "Payment Report",
            "Detailed list of payment transactions",
            lambda: show_reports_page(parent_frame),
        )

        columns = (
            "payment_id",
            "student_id",
            "name",
            "amount",
            "date",
            "mode",
            "transaction",
        )

        headings = {
            "payment_id": "Payment ID",
            "student_id": "Student ID",
            "name": "Student Name",
            "amount": "Amount",
            "date": "Payment Date",
            "mode": "Payment Mode",
            "transaction": "Transaction ID",
        }

        widths = {
            "payment_id": 110,
            "student_id": 110,
            "name": 180,
            "amount": 130,
            "date": 140,
            "mode": 140,
            "transaction": 180,
        }

        table_frame, payment_tree = create_tree(
            page_body,
            columns,
            headings,
            widths,
        )
        table_frame.pack(fill="both", expand=True)

        conn = None
        try:
            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    p.payment_id,
                    p.student_id,
                    s.name,
                    p.amount,
                    p.payment_date,
                    p.payment_mode,
                    p.transaction_id
                FROM payments p
                LEFT JOIN students s
                    ON p.student_id = s.student_id
                ORDER BY p.payment_id DESC
            """)

            rows = cursor.fetchall()

            for row in rows:
                formatted = list(row)
                formatted[3] = f"₹{row[3]:,.2f}"
                payment_tree.insert("", "end", values=formatted)

        except sqlite3.Error as e:
            show_error("Database Error", str(e))
        finally:
            if conn:
                conn.close()

    # ============================================================
    # INTERNAL STUDENT REPORT
    # ============================================================
    def show_student_report():
        clear_page()
        page_body = tk.Frame(parent_frame, bg=BG)
        page_body.pack(fill="both", expand=True, padx=30, pady=25)

        create_internal_title(
            page_body,
            "Student Report",
            "Complete list of registered students",
            lambda: show_reports_page(parent_frame),
        )

        columns = (
            "id",
            "name",
            "username",
            "course",
            "department",
            "semester",
            "academic_year",
            "contact",
        )

        headings = {
            "id": "Student ID",
            "name": "Name",
            "username": "Username",
            "course": "Course",
            "department": "Department",
            "semester": "Semester",
            "academic_year": "Academic Year",
            "contact": "Contact",
        }

        widths = {
            "id": 100,
            "name": 170,
            "username": 150,
            "course": 130,
            "department": 160,
            "semester": 100,
            "academic_year": 150,
            "contact": 140,
        }

        table_frame, student_tree = create_tree(
            page_body,
            columns,
            headings,
            widths,
        )
        table_frame.pack(fill="both", expand=True)

        conn = None
        try:
            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    student_id,
                    name,
                    username,
                    course,
                    department,
                    semester,
                    academic_year,
                    contact
                FROM students
                ORDER BY student_id
            """)

            rows = cursor.fetchall()

            for row in rows:
                student_tree.insert("", "end", values=row)

        except sqlite3.Error as e:
            show_error("Database Error", str(e))
        finally:
            if conn:
                conn.close()

    # ------------------------------------------------------------
    # BOTTOM REPORT BUTTONS
    # ------------------------------------------------------------
    bottom_frame = tk.Frame(body, bg=BG)
    bottom_frame.pack(fill="x", pady=(15, 0))

    styled_button(
        bottom_frame,
        "▤  Payment Report",
        show_payment_report,
        bg=SIDEBAR,
    ).pack(side="left", padx=(0, 8))

    styled_button(
        bottom_frame,
        "👨‍🎓  Student Report",
        show_student_report,
        bg=BLUE,
    ).pack(side="left", padx=8)

    # ------------------------------------------------------------
    # INITIAL LOAD
    # ------------------------------------------------------------
    load_report()


# ============================================================
# BACKWARD-COMPATIBLE ENTRY POINT
# ============================================================

def open_reports(parent=None):
    """
    Compatibility function.

    If a parent is supplied, Reports is displayed as an internal page.
    If no parent is supplied, a standalone test window is created.
    """

    if parent is not None:
        show_reports_page(parent)
        return

    window = tk.Tk()
    window.title("College Fee Tracker - Reports")
    window.state("zoomed")
    window.configure(bg="#F3F7FB")

    # Use a page container so the same internal-page code is tested.
    page_container = tk.Frame(window, bg="#F3F7FB")
    page_container.pack(fill="both", expand=True)

    show_reports_page(page_container)
    window.mainloop()


# ============================================================
# RUN FILE DIRECTLY
# ============================================================

if __name__ == "__main__":
    open_reports()
