import tkinter as tk
from tkinter import messagebox
import sqlite3


# ============================================================
# DATABASE
# ============================================================

DB_NAME = "college_fee_tracker.db"


def get_connection():
    return sqlite3.connect(DB_NAME)


# ============================================================
# COLORS
# ============================================================

SIDEBAR = "#174A70"
SIDEBAR_ACTIVE = "#276D96"
BLUE = "#1976D2"
BLUE_HOVER = "#1565C0"
WHITE = "#FFFFFF"
LIGHT_BG = "#F3F7FB"
TEXT = "#1F2937"
GRAY = "#6B7280"
BORDER = "#C7D5DF"
RED = "#D32F2F"
RED_BG = "#FDECEC"
RED_HOVER = "#F9DADA"


# ============================================================
# INTERNAL SETTINGS PAGE
# ============================================================

def show_settings_page(parent_frame):
    """
    Display Administrator Settings inside the Admin Dashboard's
    existing page container.

    No Toplevel window is created here.
    """

    # Clear the existing page
    for widget in parent_frame.winfo_children():
        widget.destroy()

    # --------------------------------------------------------
    # PAGE CONTAINER
    # --------------------------------------------------------

    page = tk.Frame(parent_frame, bg=LIGHT_BG)
    page.pack(fill="both", expand=True)

    # --------------------------------------------------------
    # BODY
    # --------------------------------------------------------

    body = tk.Frame(page, bg=LIGHT_BG)
    body.pack(
        fill="both",
        expand=True,
        padx=35,
        pady=25
    )

    # --------------------------------------------------------
    # ADMINISTRATOR ACCOUNT CARD
    # --------------------------------------------------------

    admin_card = tk.Frame(
        body,
        bg=WHITE,
        highlightbackground=BORDER,
        highlightthickness=1
    )
    admin_card.pack(
        fill="x",
        padx=10,
        pady=(10, 15)
    )

    tk.Label(
        admin_card,
        text="👤   Administrator Account",
        font=("Arial", 21, "bold"),
        fg=TEXT,
        bg=WHITE
    ).pack(
        anchor="w",
        padx=30,
        pady=(30, 5)
    )

    tk.Label(
        admin_card,
        text="Update the administrator login credentials",
        font=("Arial", 11),
        fg=GRAY,
        bg=WHITE
    ).pack(
        anchor="w",
        padx=30,
        pady=(0, 25)
    )

    # --------------------------------------------------------
    # FORM
    # --------------------------------------------------------

    form_frame = tk.Frame(admin_card, bg=WHITE)
    form_frame.pack(fill="x", padx=30)

    # Username
    tk.Label(
        form_frame,
        text="Username",
        font=("Arial", 10, "bold"),
        fg=TEXT,
        bg=WHITE
    ).pack(anchor="w")

    username_entry = tk.Entry(
        form_frame,
        font=("Arial", 11),
        bg="#F8FAFC",
        fg=TEXT,
        relief="solid",
        bd=1
    )
    username_entry.pack(
        fill="x",
        pady=(6, 18),
        ipady=9
    )

    # Current password
    tk.Label(
        form_frame,
        text="Current Password",
        font=("Arial", 10, "bold"),
        fg=TEXT,
        bg=WHITE
    ).pack(anchor="w")

    current_password_entry = tk.Entry(
        form_frame,
        font=("Arial", 11),
        show="*",
        bg="#F8FAFC",
        fg=TEXT,
        relief="solid",
        bd=1
    )
    current_password_entry.pack(
        fill="x",
        pady=(6, 18),
        ipady=9
    )

    # New password
    tk.Label(
        form_frame,
        text="New Password",
        font=("Arial", 10, "bold"),
        fg=TEXT,
        bg=WHITE
    ).pack(anchor="w")

    new_password_entry = tk.Entry(
        form_frame,
        font=("Arial", 11),
        show="*",
        bg="#F8FAFC",
        fg=TEXT,
        relief="solid",
        bd=1
    )
    new_password_entry.pack(
        fill="x",
        pady=(6, 18),
        ipady=9
    )

    # Confirm password
    tk.Label(
        form_frame,
        text="Confirm New Password",
        font=("Arial", 10, "bold"),
        fg=TEXT,
        bg=WHITE
    ).pack(anchor="w")

    confirm_password_entry = tk.Entry(
        form_frame,
        font=("Arial", 11),
        show="*",
        bg="#F8FAFC",
        fg=TEXT,
        relief="solid",
        bd=1
    )
    confirm_password_entry.pack(
        fill="x",
        pady=(6, 25),
        ipady=9
    )

    # --------------------------------------------------------
    # CHANGE PASSWORD
    # --------------------------------------------------------

    def change_password():
        username = username_entry.get().strip()
        current_password = current_password_entry.get()
        new_password = new_password_entry.get()
        confirm_password = confirm_password_entry.get()

        if not username:
            messagebox.showwarning(
                "Missing Username",
                "Please enter the username.",
                parent=parent_frame.winfo_toplevel()
            )
            return

        if not current_password:
            messagebox.showwarning(
                "Missing Password",
                "Please enter the current password.",
                parent=parent_frame.winfo_toplevel()
            )
            return

        if not new_password:
            messagebox.showwarning(
                "Missing Password",
                "Please enter a new password.",
                parent=parent_frame.winfo_toplevel()
            )
            return

        if not confirm_password:
            messagebox.showwarning(
                "Missing Password",
                "Please confirm the new password.",
                parent=parent_frame.winfo_toplevel()
            )
            return

        if new_password != confirm_password:
            messagebox.showerror(
                "Password Mismatch",
                "New password and confirm password do not match.",
                parent=parent_frame.winfo_toplevel()
            )
            return

        if len(new_password) < 6:
            messagebox.showwarning(
                "Weak Password",
                "Password must contain at least 6 characters.",
                parent=parent_frame.winfo_toplevel()
            )
            return

        if new_password == current_password:
            messagebox.showwarning(
                "Same Password",
                "New password must be different from the current password.",
                parent=parent_frame.winfo_toplevel()
            )
            return

        conn = None

        try:
            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute(
                """
                SELECT admin_id
                FROM admin
                WHERE username = ?
                AND password = ?
                """,
                (username, current_password)
            )

            admin = cursor.fetchone()

            if not admin:
                messagebox.showerror(
                    "Invalid Credentials",
                    "Username or current password is incorrect.",
                    parent=parent_frame.winfo_toplevel()
                )
                return

            cursor.execute(
                """
                UPDATE admin
                SET password = ?
                WHERE admin_id = ?
                """,
                (new_password, admin[0])
            )

            conn.commit()

            messagebox.showinfo(
                "Password Updated",
                "Administrator password changed successfully.",
                parent=parent_frame.winfo_toplevel()
            )

            clear_password_fields()

        except sqlite3.Error as e:
            messagebox.showerror(
                "Database Error",
                "Could not update administrator password.\n\n" + str(e),
                parent=parent_frame.winfo_toplevel()
            )

        finally:
            if conn:
                conn.close()

    # --------------------------------------------------------
    # BUTTONS
    # --------------------------------------------------------

    button_frame = tk.Frame(admin_card, bg=WHITE)
    button_frame.pack(
        anchor="w",
        padx=30,
        pady=(0, 30)
    )

    change_button = tk.Button(
        button_frame,
        text="🔐   Change Password",
        font=("Arial", 11, "bold"),
        bg=BLUE,
        fg=WHITE,
        activebackground=BLUE_HOVER,
        activeforeground=WHITE,
        bd=0,
        relief="flat",
        padx=24,
        pady=11,
        cursor="hand2",
        command=change_password
    )
    change_button.pack(side="left", padx=(0, 12))

    def clear_password_fields():
        current_password_entry.delete(0, tk.END)
        new_password_entry.delete(0, tk.END)
        confirm_password_entry.delete(0, tk.END)

    clear_button = tk.Button(
        button_frame,
        text="✕   Clear Fields",
        font=("Arial", 11, "bold"),
        bg=RED_BG,
        fg=RED,
        activebackground=RED_HOVER,
        activeforeground=RED,
        bd=0,
        relief="flat",
        padx=24,
        pady=11,
        cursor="hand2",
        command=clear_password_fields
    )
    clear_button.pack(side="left")

    # --------------------------------------------------------
    # INFORMATION MESSAGE
    # --------------------------------------------------------

    info_frame = tk.Frame(
        body,
        bg="#EAF3FA",
        highlightbackground="#C7DDEB",
        highlightthickness=1
    )
    info_frame.pack(
        fill="x",
        padx=10,
        pady=(5, 10)
    )

    tk.Label(
        info_frame,
        text="🔒",
        font=("Segoe UI Emoji", 10) ,
        fg=BLUE,
        bg="#EAF3FA"
    ).pack(
        side="left",
        padx=(20, 10),
        pady=15
    )

    tk.Label(
        info_frame,
        text=(
            "Administrator settings are restricted to the admin account. "
            "Keep your password secure and do not share it with others."
        ),
        font=("Arial", 10),
        fg=TEXT,
        bg="#EAF3FA",
        justify="left",
        anchor="w",
        wraplength=1000
    ).pack(
        side="left",
        fill="x",
        expand=True,
        pady=15,
        padx=(0, 20)
    )


# ============================================================
# BACKWARD-COMPATIBLE STANDALONE TESTING
# ============================================================

def open_settings(parent=None):
    """
    Standalone testing function.

    If parent is supplied, the settings page is placed inside
    that parent instead of creating another window.
    """

    if parent is not None:
        show_settings_page(parent)
        return

    window = tk.Tk()
    window.title("College Fee Tracker - Settings")

    try:
        window.state("zoomed")
    except tk.TclError:
        window.geometry("1400x800")

    window.configure(bg=LIGHT_BG)

    show_settings_page(window)

    window.mainloop()


# ============================================================
# RUN DIRECTLY
# ============================================================

if __name__ == "__main__":
    open_settings()
