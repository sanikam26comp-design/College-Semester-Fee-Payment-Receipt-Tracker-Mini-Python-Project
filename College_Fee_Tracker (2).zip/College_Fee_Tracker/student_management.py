import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3


# ============================================================
# DATABASE
# ============================================================

DB_NAME = "college_fee_tracker.db"


def get_connection():
    return sqlite3.connect(DB_NAME)


# ============================================================
# STUDENT MANAGEMENT PAGE
# ============================================================

def show_student_management_page(parent_frame):
    """
    Displays Student Management inside the supplied admin page frame.

    Important:
    - Does NOT create a Toplevel window.
    - Does NOT create another sidebar.
    - Works with the single-window admin_dashboard architecture.
    """

    # Clear the existing admin page
    for widget in parent_frame.winfo_children():
        widget.destroy()

    # ========================================================
    # COLORS
    # ========================================================

    SIDEBAR = "#174A70"
    BLUE = "#1976D2"
    BLUE_HOVER = "#1565C0"
    LIGHT_BLUE = "#EAF3FA"
    WHITE = "#FFFFFF"
    TEXT = "#1F2937"
    GRAY = "#6B7280"
    BORDER = "#D6E2EC"
    RED = "#D32F2F"
    RED_HOVER = "#B71C1C"
    GREEN = "#2E7D32"
    GREEN_HOVER = "#1B5E20"
    ORANGE = "#EF6C00"
    BG = "#F3F7FB"

    # ========================================================
    # OPTIONS
    # ========================================================

    courses = [
        "B.Tech",
        "BCA",
        "B.Sc IT",
        "BBA",
        "B.Com",
        "BA",
        "B.Sc",
        "MCA",
        "M.Tech",
        "MBA",
        "M.Com",
        "M.Sc"
    ]

    departments = [
        "Computer Science",
        "Computer Applications",
        "Information Technology",
        "Civil",
        "Mechanical",
        "Electronics",
        "Electrical",
        "Commerce",
        "Management",
        "Science",
        "Arts"
    ]

    semesters = [str(i) for i in range(1, 9)]

    academic_years = [
        "2026-2027"
    ]

    # ========================================================
    # PAGE ROOT
    # ========================================================

    page = tk.Frame(parent_frame, bg=BG)
    page.pack(fill="both", expand=True)

    # ========================================================
    # BODY
    # ========================================================

    body = tk.Frame(page, bg=BG)
    body.pack(fill="both", expand=True, padx=30, pady=22)

    # ========================================================
    # BUTTON STYLE
    # ========================================================

    def styled_button(parent, text, command, bg=BLUE, hover=BLUE_HOVER):
        button = tk.Button(
            parent,
            text=text,
            font=("Arial", 11, "bold"),
            bg=bg,
            fg=WHITE,
            activebackground=hover,
            activeforeground=WHITE,
            bd=0,
            relief="flat",
            padx=18,
            pady=10,
            cursor="hand2",
            command=command
        )

        def enter(event):
            button.configure(bg=hover)

        def leave(event):
            button.configure(bg=bg)

        button.bind("<Enter>", enter)
        button.bind("<Leave>", leave)

        return button

    # ========================================================
    # TOP ACTION AREA
    # ========================================================

    action_frame = tk.Frame(body, bg=BG)
    action_frame.pack(fill="x", pady=(0, 14))

    # Search
    search_frame = tk.Frame(
        action_frame,
        bg=WHITE,
        highlightbackground=BORDER,
        highlightthickness=1
    )
    search_frame.pack(
        side="left",
        fill="x",
        expand=True,
        padx=(0, 12)
    )

    tk.Label(
        search_frame,
        text="🔍",
        font=("Arial", 14),
        bg=WHITE,
        fg=BLUE
    ).pack(side="left", padx=(15, 5))

    search_entry = tk.Entry(
        search_frame,
        font=("Arial", 12),
        bd=0,
        bg=WHITE,
        fg=TEXT
    )
    search_entry.pack(
        side="left",
        fill="x",
        expand=True,
        ipady=11
    )

    refresh_button = styled_button(
        action_frame,
        "↻  Refresh",
        lambda: refresh_students()
    )
    refresh_button.pack(side="right", padx=5)

    add_button = styled_button(
        action_frame,
        "＋  Add Student",
        lambda: open_form("add")
    )
    add_button.pack(side="right", padx=5)

    # ========================================================
    # INLINE FORM AREA
    # ========================================================

    form_card = tk.Frame(
        body,
        bg=WHITE,
        highlightbackground=BORDER,
        highlightthickness=1
    )

    # Form title
    form_header = tk.Frame(form_card, bg=WHITE, height=58)
    form_header.pack(fill="x")
    form_header.pack_propagate(False)

    form_title = tk.Label(
        form_header,
        text="Add New Student",
        font=("Arial", 16, "bold"),
        fg=TEXT,
        bg=WHITE
    )
    form_title.pack(side="left", padx=20)

    form_mode = {"mode": "add", "student_id": None}

    # Form body
    form_body = tk.Frame(form_card, bg=WHITE)
    form_body.pack(fill="x", padx=20, pady=(0, 12))

    # Variables
    student_id_var = tk.StringVar()
    name_var = tk.StringVar()
    username_var = tk.StringVar()
    password_var = tk.StringVar(value="student123")
    course_var = tk.StringVar()
    department_var = tk.StringVar()
    semester_var = tk.StringVar()
    academic_year_var = tk.StringVar()
    contact_var = tk.StringVar()

    def field_label(parent, text):
        return tk.Label(
            parent,
            text=text,
            font=("Arial", 10, "bold"),
            fg=TEXT,
            bg=WHITE,
            anchor="w"
        )

    def entry_widget(parent, variable, readonly=False):
        return tk.Entry(
            parent,
            textvariable=variable,
            font=("Arial", 10),
            bd=1,
            relief="solid",
            bg="#FFFFFF",
            fg=TEXT,
            state="readonly" if readonly else "normal"
        )

    # Two-column form
    left_form = tk.Frame(form_body, bg=WHITE)
    left_form.pack(side="left", fill="x", expand=True, padx=(0, 12))

    right_form = tk.Frame(form_body, bg=WHITE)
    right_form.pack(side="left", fill="x", expand=True, padx=(12, 0))

    def make_entry_row(parent, label, variable, readonly=False):
        row = tk.Frame(parent, bg=WHITE)
        row.pack(fill="x", pady=5)

        field_label(row, label).pack(
            side="left",
            padx=(0, 10),
            ipadx=2
        )

        entry = entry_widget(row, variable, readonly)
        entry.pack(side="left", fill="x", expand=True, ipady=5)
        return entry

    student_id_entry = make_entry_row(
        left_form, "Student ID", student_id_var
    )

    name_entry = make_entry_row(
        left_form, "Name", name_var
    )

    username_entry = make_entry_row(
        left_form, "Username", username_var, readonly=True
    )

    password_entry = make_entry_row(
        left_form, "Password", password_var, readonly=True
    )

    # Course
    course_row = tk.Frame(right_form, bg=WHITE)
    course_row.pack(fill="x", pady=5)

    field_label(course_row, "Course").pack(
        side="left",
        padx=(0, 10)
    )

    course_combo = ttk.Combobox(
        course_row,
        textvariable=course_var,
        values=courses,
        font=("Arial", 10),
        state="readonly"
    )
    course_combo.pack(side="left", fill="x", expand=True, ipady=4)

    # Department
    department_row = tk.Frame(right_form, bg=WHITE)
    department_row.pack(fill="x", pady=5)

    field_label(department_row, "Department").pack(
        side="left",
        padx=(0, 10)
    )

    department_combo = ttk.Combobox(
        department_row,
        textvariable=department_var,
        values=departments,
        font=("Arial", 10),
        state="readonly"
    )
    department_combo.pack(side="left", fill="x", expand=True, ipady=4)

    # Semester
    semester_row = tk.Frame(right_form, bg=WHITE)
    semester_row.pack(fill="x", pady=5)

    field_label(semester_row, "Semester").pack(
        side="left",
        padx=(0, 10)
    )

    semester_combo = ttk.Combobox(
        semester_row,
        textvariable=semester_var,
        values=semesters,
        font=("Arial", 10),
        state="readonly"
    )
    semester_combo.pack(side="left", fill="x", expand=True, ipady=4)

    # Academic Year
    academic_row = tk.Frame(right_form, bg=WHITE)
    academic_row.pack(fill="x", pady=5)

    field_label(academic_row, "Academic Year").pack(
        side="left",
        padx=(0, 10)
    )

    academic_combo = ttk.Combobox(
        academic_row,
        textvariable=academic_year_var,
        values=academic_years,
        font=("Arial", 10),
        state="readonly"
    )
    academic_combo.pack(side="left", fill="x", expand=True, ipady=4)

    # Contact
    contact_entry = make_entry_row(
        right_form, "Contact", contact_var
    )

    # Form buttons
    form_buttons = tk.Frame(form_card, bg=WHITE)
    form_buttons.pack(fill="x", padx=20, pady=(0, 15))

    def close_form():
        form_card.pack_forget()

        form_mode["mode"] = "add"
        form_mode["student_id"] = None

        student_id_var.set("")
        name_var.set("")
        username_var.set("")
        password_var.set("student123")
        course_var.set("")
        department_var.set("")
        semester_var.set("")
        academic_year_var.set("")
        contact_var.set("")

        course_combo.set("")
        department_combo.set("")
        semester_combo.set("")
        academic_combo.set("")

    def generate_username(event=None):
        name = name_var.get().strip()
        student_id = student_id_var.get().strip()

        if name and student_id:
            first_name = name.split()[0].lower()
            username_var.set(first_name + student_id)
        else:
            username_var.set("")

    name_entry.bind("<KeyRelease>", generate_username)
    student_id_entry.bind("<KeyRelease>", generate_username)

    def open_form(mode="add", values=None):
        form_mode["mode"] = mode

        if mode == "add":
            form_title.config(text="Add New Student")

            student_id_var.set("")
            name_var.set("")
            username_var.set("")
            password_var.set("student123")
            course_var.set("")
            department_var.set("")
            semester_var.set("")
            academic_year_var.set("")
            contact_var.set("")

            course_combo.set("")
            department_combo.set("")
            semester_combo.set("")
            academic_combo.set("")

            student_id_entry.config(state="normal")

        else:
            form_title.config(text="Update Student")

            student_id_var.set(values[0])
            name_var.set(values[1])
            username_var.set(values[2])
            password_var.set("student123")
            course_var.set(values[3] if values[3] else "")
            department_var.set(values[4] if values[4] else "")
            semester_var.set(str(values[5]) if values[5] is not None else "")
            academic_year_var.set(values[6] if values[6] else "")
            contact_var.set(values[7] if values[7] else "")

            course_combo.set(course_var.get())
            department_combo.set(department_var.get())
            semester_combo.set(semester_var.get())
            academic_combo.set(academic_year_var.get())

            form_mode["student_id"] = values[0]
            student_id_entry.config(state="readonly")

        # Always place the form above the table and action bar.
        # This is important because the table uses the remaining space.
        form_card.pack(
            fill="x",
            pady=(0, 14),
            before=bottom_frame
        )

        name_entry.focus_set()

    def save_student():
        student_id = student_id_var.get().strip()
        name = name_var.get().strip()
        username = username_var.get().strip()
        password = "student123"
        course = course_var.get().strip()
        department = department_var.get().strip()
        semester = semester_var.get().strip()
        academic_year = academic_year_var.get().strip()
        contact = contact_var.get().strip()

        # ------------------------------
        # Validation
        # ------------------------------

        if not student_id:
            messagebox.showwarning(
                "Missing Information",
                "Please enter Student ID."
            )
            student_id_entry.focus()
            return

        if not name:
            messagebox.showwarning(
                "Missing Information",
                "Please enter student name."
            )
            name_entry.focus()
            return

        if not username:
            messagebox.showwarning(
                "Username Error",
                "Username could not be generated."
            )
            return

        if course not in courses:
            messagebox.showwarning(
                "Missing Course",
                "Please select a course."
            )
            return

        if department not in departments:
            messagebox.showwarning(
                "Missing Department",
                "Please select a department."
            )
            return

        if semester not in semesters:
            messagebox.showwarning(
                "Missing Semester",
                "Please select a semester."
            )
            return

        if academic_year not in academic_years:
            messagebox.showwarning(
                "Missing Academic Year",
                "Please select academic year."
            )
            return

        if not contact:
            messagebox.showwarning(
                "Missing Contact",
                "Please enter contact number."
            )
            contact_entry.focus()
            return

        if not contact.isdigit():
            messagebox.showerror(
                "Invalid Contact",
                "Contact number must contain numbers only."
            )
            contact_entry.focus()
            return

        if len(contact) != 10:
            messagebox.showerror(
                "Invalid Contact",
                "Contact number must contain exactly 10 digits."
            )
            contact_entry.focus()
            return

        try:
            student_id_number = int(student_id)
        except ValueError:
            messagebox.showerror(
                "Invalid Student ID",
                "Student ID must contain numbers only."
            )
            student_id_entry.focus()
            return

        conn = None

        try:
            conn = get_connection()
            cursor = conn.cursor()

            if form_mode["mode"] == "add":
                cursor.execute(
                    """
                    INSERT INTO students
                    (
                        student_id,
                        name,
                        username,
                        password,
                        course,
                        department,
                        semester,
                        academic_year,
                        contact
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        student_id_number,
                        name,
                        username,
                        password,
                        course,
                        department,
                        int(semester),
                        academic_year,
                        contact
                    )
                )

                message = (
                    "Student added successfully!\n\n"
                    f"Username: {username}\n"
                    f"Password: {password}"
                )

            else:
                cursor.execute(
                    """
                    UPDATE students
                    SET
                        name = ?,
                        username = ?,
                        password = ?,
                        course = ?,
                        department = ?,
                        semester = ?,
                        academic_year = ?,
                        contact = ?
                    WHERE student_id = ?
                    """,
                    (
                        name,
                        username,
                        password,
                        course,
                        department,
                        int(semester),
                        academic_year,
                        contact,
                        form_mode["student_id"]
                    )
                )

                message = "Student updated successfully!"

            conn.commit()

            close_form()
            load_students()

            messagebox.showinfo(
                "Success",
                message
            )

        except sqlite3.IntegrityError as e:
            error_text = str(e).lower()

            if "username" in error_text:
                message = "Username already exists."
            elif "student_id" in error_text:
                message = "Student ID already exists."
            else:
                message = "A duplicate student record already exists."

            messagebox.showerror(
                "Duplicate Record",
                message
            )

        except sqlite3.Error as e:
            messagebox.showerror(
                "Database Error",
                f"Could not save student.\n\n{e}"
            )

        finally:
            if conn:
                conn.close()

    def save_update():
        save_student()

    save_button = styled_button(
        form_buttons,
        "✓  Save Student",
        save_student,
        bg=BLUE,
        hover=BLUE_HOVER
    )
    save_button.pack(side="left", padx=(0, 8))

    cancel_button = styled_button(
        form_buttons,
        "✕  Cancel",
        close_form,
        bg=GRAY,
        hover="#4B5563"
    )
    cancel_button.pack(side="left")

    # ========================================================
    # BOTTOM ACTION BUTTONS
    # ========================================================

    bottom_frame = tk.Frame(
        body,
        bg=BG,
        height=62
    )
    # Keep the action bar at the bottom of the available page.
    # It is packed BEFORE the expandable table so the table cannot push
    # these buttons outside the visible area.
    bottom_frame.pack(
        side="bottom",
        fill="x",
        pady=(12, 0)
    )
    bottom_frame.pack_propagate(False)

    update_button = styled_button(
        bottom_frame,
        "✎  Update Selected",
        lambda: update_student(),
        bg=GREEN,
        hover=GREEN_HOVER
    )
    update_button.pack(
        side="left",
        padx=(0, 8)
    )

    delete_button = styled_button(
        bottom_frame,
        "🗑  Delete Selected",
        lambda: delete_student(),
        bg=RED,
        hover=RED_HOVER
    )
    delete_button.pack(
        side="left",
        padx=8
    )


    # ========================================================
    # TABLE CARD
    # ========================================================

    table_card = tk.Frame(
        body,
        bg=WHITE,
        highlightbackground=BORDER,
        highlightthickness=1
    )
    # The table takes all remaining space after the fixed bottom action bar.
    table_card.pack(fill="both", expand=True)

    table_header = tk.Frame(
        table_card,
        bg=WHITE,
        height=60
    )
    table_header.pack(fill="x")
    table_header.pack_propagate(False)

    tk.Label(
        table_header,
        text="All Students",
        font=("Arial", 17, "bold"),
        fg=TEXT,
        bg=WHITE
    ).pack(side="left", padx=20)

    student_count_label = tk.Label(
        table_header,
        text="",
        font=("Arial", 10),
        fg=GRAY,
        bg=WHITE
    )
    student_count_label.pack(side="left", padx=5)

    # ========================================================
    # TABLE
    # ========================================================

    tree_frame = tk.Frame(table_card, bg=WHITE)
    tree_frame.pack(
        fill="both",
        expand=True,
        padx=15,
        pady=(0, 15)
    )

    columns = (
        "student_id",
        "name",
        "username",
        "course",
        "department",
        "semester",
        "academic_year",
        "contact"
    )

    headings = {
        "student_id": "Student ID",
        "name": "Name",
        "username": "Username",
        "course": "Course",
        "department": "Department",
        "semester": "Semester",
        "academic_year": "Academic Year",
        "contact": "Contact"
    }

    widths = {
        "student_id": 90,
        "name": 160,
        "username": 130,
        "course": 110,
        "department": 180,
        "semester": 80,
        "academic_year": 120,
        "contact": 130
    }

    # Treeview style
    style = ttk.Style()

    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    # Create the layout before configuring the custom Treeview style.
    # Without this, ttk can raise: "Layout StudentTreeview not found".
    try:
        style.layout(
            "StudentTreeview",
            style.layout("Treeview")
        )
    except tk.TclError:
        pass

    style.configure(
        "StudentTreeview",
        background=WHITE,
        foreground=TEXT,
        rowheight=42,
        fieldbackground=WHITE,
        font=("Arial", 10),
        borderwidth=1
    )

    style.configure(
        "StudentTreeview.Heading",
        background="#EAF2F8",
        foreground=TEXT,
        font=("Arial", 10, "bold"),
        padding=10,
        relief="solid"
    )

    style.map(
        "StudentTreeview",
        background=[
            ("selected", "#DCEEFF")
        ],
        foreground=[
            ("selected", TEXT)
        ]
    )

    tree = ttk.Treeview(
        tree_frame,
        columns=columns,
        show="headings",
        selectmode="browse",
        style="StudentTreeview"
    )

    for column in columns:
        tree.heading(
            column,
            text=headings[column]
        )

        tree.column(
            column,
            width=widths[column],
            minwidth=70,
            anchor="center"
        )

    scrollbar_y = ttk.Scrollbar(
        tree_frame,
        orient="vertical",
        command=tree.yview
    )

    scrollbar_x = ttk.Scrollbar(
        table_card,
        orient="horizontal",
        command=tree.xview
    )

    tree.configure(
        yscrollcommand=scrollbar_y.set,
        xscrollcommand=scrollbar_x.set
    )

    tree.pack(
        side="left",
        fill="both",
        expand=True
    )

    scrollbar_y.pack(
        side="right",
        fill="y"
    )

    scrollbar_x.pack(
        side="bottom",
        fill="x",
        padx=15,
        pady=(0, 8)
    )

    # ========================================================
    # LOAD STUDENTS
    # ========================================================

    def load_students(search_text=""):
        for item in tree.get_children():
            tree.delete(item)

        conn = None

        try:
            conn = get_connection()
            cursor = conn.cursor()

            if search_text.strip():
                keyword = "%" + search_text.strip() + "%"

                cursor.execute(
                    """
                    SELECT
                        student_id,
                        name,
                        username,
                        course,
                        department,
                        semester,
                        academic_year,
                        contact
                    FROM students
                    WHERE
                        CAST(student_id AS TEXT) LIKE ?
                        OR name LIKE ?
                        OR username LIKE ?
                        OR course LIKE ?
                        OR department LIKE ?
                        OR contact LIKE ?
                    ORDER BY student_id
                    """,
                    (
                        keyword,
                        keyword,
                        keyword,
                        keyword,
                        keyword,
                        keyword
                    )
                )

            else:
                cursor.execute(
                    """
                    SELECT
                        student_id,
                        name,
                        username,
                        course,
                        department,
                        semester,
                        academic_year,
                        contact
                    FROM students
                    ORDER BY student_id
                    """
                )

            rows = cursor.fetchall()

            for row in rows:
                tree.insert(
                    "",
                    "end",
                    values=row
                )

            student_count_label.config(
                text=f"({len(rows)} students)"
            )

        except sqlite3.Error as e:
            messagebox.showerror(
                "Database Error",
                f"Could not load students.\n\n{e}"
            )

        finally:
            if conn:
                conn.close()

    # ========================================================
    # SEARCH
    # ========================================================

    def perform_search(event=None):
        load_students(search_entry.get())

    search_entry.bind(
        "<KeyRelease>",
        perform_search
    )

    # ========================================================
    # REFRESH
    # ========================================================

    def refresh_students():
        search_entry.delete(0, tk.END)
        load_students()

    # ========================================================
    # UPDATE STUDENT
    # ========================================================

    def update_student():
        selected = tree.selection()

        if not selected:
            messagebox.showwarning(
                "Select Student",
                "Please select a student to update."
            )
            return

        values = tree.item(
            selected[0],
            "values"
        )

        open_form(
            "update",
            values
        )

    # ========================================================
    # DELETE STUDENT
    # ========================================================

    def delete_student():
        selected = tree.selection()

        if not selected:
            messagebox.showwarning(
                "Select Student",
                "Please select a student to delete."
            )
            return

        values = tree.item(
            selected[0],
            "values"
        )

        student_id = values[0]
        student_name = values[1]

        confirm = messagebox.askyesno(
            "Delete Student",
            "Are you sure you want to delete:\n\n"
            f"Student ID: {student_id}\n"
            f"Name: {student_name}\n\n"
            "This action cannot be undone."
        )

        if not confirm:
            return

        conn = None

        try:
            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute(
                """
                DELETE FROM students
                WHERE student_id = ?
                """,
                (student_id,)
            )

            conn.commit()

            messagebox.showinfo(
                "Deleted",
                "Student deleted successfully."
            )

            load_students()

        except sqlite3.IntegrityError:
            messagebox.showerror(
                "Cannot Delete",
                "This student cannot be deleted because related "
                "fee or payment records exist."
            )

        except sqlite3.Error as e:
            messagebox.showerror(
                "Database Error",
                f"Could not delete student.\n\n{e}"
            )

        finally:
            if conn:
                conn.close()

    # ========================================================
    # DOUBLE CLICK
    # ========================================================

    tree.bind(
        "<Double-1>",
        lambda event: update_student()
    )

    # ========================================================
    # INITIAL LOAD
    # ========================================================

    load_students()


# ============================================================
# BACKWARD-COMPATIBLE STANDALONE FUNCTION
# ============================================================

def open_student_management(parent=None):
    """
    Standalone version for testing this file directly.

    The admin dashboard should NOT call this function.
    It should call show_student_management_page(page_container).
    """

    if parent is not None:
        show_student_management_page(parent)
        return

    window = tk.Tk()
    window.title("College Fee Tracker - Student Management")
    window.state("zoomed")
    window.configure(bg="#F3F7FB")

    show_student_management_page(window)

    def close_window():
        window.destroy()

    window.protocol(
        "WM_DELETE_WINDOW",
        close_window
    )

    window.mainloop()


# ============================================================
# RUN DIRECTLY
# ============================================================

if __name__ == "__main__":
    open_student_management()
