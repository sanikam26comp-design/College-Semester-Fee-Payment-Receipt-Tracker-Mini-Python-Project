import tkinter as tk
from tkinter import messagebox
import sqlite3

from admin_dashboard import open_admin_dashboard


# ==========================================================
# DATABASE
# ==========================================================

DB_NAME = "college_fee_tracker.db"


def get_connection():
    return sqlite3.connect(DB_NAME)


# ==========================================================
# INITIALIZE DATABASE
# ==========================================================

def initialize_database():

    conn = None

    try:
        conn = get_connection()
        cursor = conn.cursor()

        # --------------------------------------------------
        # ADMIN TABLE
        # --------------------------------------------------

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS admin (
                admin_id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        """)

        # --------------------------------------------------
        # STUDENTS TABLE
        # --------------------------------------------------

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS students (
                student_id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                course TEXT,
                department TEXT,
                semester INTEGER,
                academic_year TEXT,
                contact TEXT
            )
        """)

        # --------------------------------------------------
        # DEFAULT ADMIN
        # --------------------------------------------------

        cursor.execute("""
            SELECT admin_id
            FROM admin
            LIMIT 1
        """)

        if cursor.fetchone() is None:

            cursor.execute("""
                INSERT INTO admin
                (username, password)
                VALUES (?, ?)
            """, ("admin", "admin12"))

        # --------------------------------------------------
        # DEFAULT STUDENT
        # --------------------------------------------------

        cursor.execute("""
            SELECT student_id
            FROM students
            WHERE student_id = ?
        """, (101,))

        if cursor.fetchone() is None:

            cursor.execute("""
                INSERT INTO students (
                    student_id,
                    name,
                    username,
                    password,
                    course,
                    department,
                    semester,
                    academic_year,
                    contact
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                101,
                "Sanika Mistry",
                "sanika101",
                "Sanika@101",
                "B.Tech",
                "Computer Science",
                5,
                "2024-2025",
                "9876543210"
            ))

        conn.commit()

    except sqlite3.Error as e:

        messagebox.showerror(
            "Database Error",
            "Could not initialize database.\n\n" + str(e)
        )

    finally:

        if conn:
            conn.close()


# ==========================================================
# MAIN WINDOW
# ==========================================================

window = tk.Tk()

window.title("College Fee Tracker")

try:
    window.state("zoomed")
except tk.TclError:
    window.geometry("1400x850")

window.configure(
    bg="#EAF3FB"
)


# ==========================================================
# COLORS
# ==========================================================

BACKGROUND = "#EAF3FB"
WHITE = "#FFFFFF"

BLUE = "#1976D2"
HOVER_BLUE = "#1565C0"
DARK_BLUE = "#124E78"

TEXT = "#263238"
GRAY = "#718096"

FIELD_BG = "#F4F9FD"
FIELD_HOVER_BG = "#EEF8FF"

FIELD_BORDER = "#D5E1EA"
FIELD_HOVER_BORDER = "#1976D2"


# ==========================================================
# BACKGROUND
# ==========================================================

background = tk.Frame(
    window,
    bg=BACKGROUND
)

background.pack(
    fill="both",
    expand=True
)


# ==========================================================
# BACKGROUND DECORATIONS
# ==========================================================

for x, y, w, h, color in [
    (0.02, 0.03, 0.22, 0.25, "#DCEFFA"),
    (0.78, 0.03, 0.20, 0.23, "#DFF1FA"),
    (0.02, 0.75, 0.22, 0.22, "#E1F1FA"),
    (0.80, 0.75, 0.18, 0.22, "#DCEFFA")
]:

    tk.Frame(
        background,
        bg=color
    ).place(
        relx=x,
        rely=y,
        relwidth=w,
        relheight=h
    )


tk.Label(
    background,
    text="▤",
    font=("Arial", 65),
    fg="#C7DFEC",
    bg="#DCEFFA"
).place(
    relx=0.07,
    rely=0.40
)


tk.Label(
    background,
    text="₹",
    font=("Arial", 70, "bold"),
    fg="#C9E1EE",
    bg="#DFF1FA"
).place(
    relx=0.90,
    rely=0.38
)


tk.Label(
    background,
    text="▰\n▰\n▰",
    font=("Arial", 28),
    fg="#C4DDEB",
    bg="#E1F1FA",
    justify="center"
).place(
    relx=0.87,
    rely=0.75
)


# ==========================================================
# LOGIN CARD
# ==========================================================

card_container = tk.Frame(
    background,
    bg="#C7D8E5",
    width=580,
    height=750
)

card_container.place(
    relx=0.5,
    rely=0.58,
    anchor="center"
)

card_container.pack_propagate(False)


login_card = tk.Frame(
    card_container,
    bg=WHITE,
    width=570,
    height=740
)

login_card.place(
    x=0,
    y=0
)

login_card.pack_propagate(False)


content = tk.Frame(
    login_card,
    bg=WHITE
)

content.pack(
    fill="both",
    expand=True,
    padx=55,
    pady=30
)


# ==========================================================
# LOGO
# ==========================================================

logo = tk.Label(
    content,
    text="🎓",
    font=("Segoe UI Emoji", 40),
    bg=WHITE
)

logo.pack(
    pady=(0, 2)
)


# ==========================================================
# TITLE
# ==========================================================

tk.Label(
    content,
    text="College Fee Tracker",
    font=("Arial", 27, "bold"),
    fg=DARK_BLUE,
    bg=WHITE
).pack()


tk.Label(
    content,
    text="Smart • Simple • Secure",
    font=("Arial", 11),
    fg=GRAY,
    bg=WHITE
).pack(
    pady=(3, 13)
)


tk.Label(
    content,
    text="Login to access your account",
    font=("Arial", 18, "bold"),
    fg=TEXT,
    bg=WHITE
).pack(
    pady=(5, 19)
)


# ==========================================================
# LOGIN ROLE
# ==========================================================

tk.Label(
    content,
    text="LOGIN AS",
    font=("Arial", 10, "bold"),
    fg=GRAY,
    bg=WHITE
).pack(
    anchor="w"
)


role_frame = tk.Frame(
    content,
    bg=WHITE
)

role_frame.pack(
    fill="x",
    pady=(7, 17)
)


selected_role = tk.StringVar(
    value="Student"
)


student_button = tk.Button(
    role_frame,
    text="🎓  Student",
    font=("Arial", 11, "bold"),
    bg=BLUE,
    fg=WHITE,
    activebackground=HOVER_BLUE,
    activeforeground=WHITE,
    bd=0,
    relief="flat",
    cursor="hand2",
    height=2
)

student_button.pack(
    side="left",
    fill="x",
    expand=True,
    padx=(0, 5)
)


admin_button = tk.Button(
    role_frame,
    text="💼  Admin",
    font=("Arial", 11, "bold"),
    bg="#EEF3F7",
    fg=TEXT,
    activebackground="#DCE8F0",
    activeforeground=TEXT,
    bd=0,
    relief="flat",
    cursor="hand2",
    height=2
)

admin_button.pack(
    side="left",
    fill="x",
    expand=True,
    padx=(5, 0)
)


# ==========================================================
# INPUT FIELD FUNCTION
# ==========================================================

def create_input(
    parent,
    label_text,
    icon,
    placeholder,
    password=False
):

    tk.Label(
        parent,
        text=label_text,
        font=("Arial", 10, "bold"),
        fg=TEXT,
        bg=WHITE
    ).pack(
        anchor="w"
    )

    outer = tk.Frame(
        parent,
        bg=FIELD_BORDER,
        height=48
    )

    outer.pack(
        fill="x",
        pady=(6, 14)
    )

    outer.pack_propagate(False)

    inner = tk.Frame(
        outer,
        bg=FIELD_BG
    )

    inner.pack(
        fill="both",
        expand=True,
        padx=1,
        pady=1
    )

    tk.Label(
        inner,
        text=icon,
        font=("Segoe UI Emoji", 16),
        fg="#6D8FA8",
        bg=FIELD_BG
    ).pack(
        side="left",
        padx=(14, 8)
    )

    entry = tk.Entry(
        inner,
        font=("Arial", 12),
        bg=FIELD_BG,
        fg="#9AA8B4",
        bd=0,
        relief="flat",
        insertbackground=BLUE
    )

    entry.pack(
        side="left",
        fill="both",
        expand=True,
        padx=(2, 5)
    )

    entry.insert(
        0,
        placeholder
    )

    eye_button = None

    if password:

        eye_button = tk.Button(
            inner,
            text="👁",
            font=("Segoe UI Emoji", 12),
            bg=FIELD_BG,
            fg="#6D8FA8",
            activebackground=FIELD_HOVER_BG,
            activeforeground=BLUE,
            bd=0,
            relief="flat",
            cursor="hand2"
        )

        eye_button.pack(
            side="right",
            padx=(2, 10)
        )

    password_visible = False

    def toggle_password():

        nonlocal password_visible

        if entry.get() == placeholder:
            return

        password_visible = not password_visible

        if password_visible:
            entry.config(show="")
        else:
            entry.config(show="●")

    if eye_button:
        eye_button.config(
            command=toggle_password
        )

    def focus_in(event):

        outer.config(
            bg=FIELD_HOVER_BORDER,
            height=56
        )

        inner.config(
            bg=FIELD_HOVER_BG
        )

        if entry.get() == placeholder:

            entry.delete(
                0,
                tk.END
            )

            entry.config(
                fg=TEXT
            )

            if password:
                entry.config(
                    show="●"
                )

    def focus_out(event):

        if entry.get() == "":

            entry.insert(
                0,
                placeholder
            )

            entry.config(
                fg="#9AA8B4"
            )

            if password:
                entry.config(
                    show=""
                )

        outer.config(
            bg=FIELD_BORDER,
            height=48
        )

        inner.config(
            bg=FIELD_BG
        )

    entry.bind(
        "<FocusIn>",
        focus_in
    )

    entry.bind(
        "<FocusOut>",
        focus_out
    )

    return entry


# ==========================================================
# USERNAME / PASSWORD
# ==========================================================

username_entry = create_input(
    content,
    "Username",
    "👤",
    "Enter your username"
)


password_entry = create_input(
    content,
    "Password",
    "🔑",
    "Enter your password",
    password=True
)


# ==========================================================
# CLEAR FIELDS
# ==========================================================

def clear_login_fields():

    username_entry.delete(
        0,
        tk.END
    )

    username_entry.insert(
        0,
        "Enter your username"
    )

    username_entry.config(
        fg="#9AA8B4"
    )

    password_entry.delete(
        0,
        tk.END
    )

    password_entry.insert(
        0,
        "Enter your password"
    )

    password_entry.config(
        fg="#9AA8B4",
        show=""
    )


# ==========================================================
# ROLE SELECTION
# ==========================================================

def select_student():

    selected_role.set("Student")

    clear_login_fields()

    student_button.config(
        bg=BLUE,
        fg=WHITE
    )

    admin_button.config(
        bg="#EEF3F7",
        fg=TEXT
    )


def select_admin():

    selected_role.set("Admin")

    clear_login_fields()

    admin_button.config(
        bg=BLUE,
        fg=WHITE
    )

    student_button.config(
        bg="#EEF3F7",
        fg=TEXT
    )


student_button.config(
    command=select_student
)

admin_button.config(
    command=select_admin
)


# ==========================================================
# LOGIN FUNCTION
# ==========================================================

def login():

    username = username_entry.get().strip()
    password = password_entry.get()
    role = selected_role.get()

    if username == "Enter your username":
        username = ""

    if password == "Enter your password":
        password = ""

    if username == "" or password == "":

        messagebox.showwarning(
            "Missing Information",
            "Please enter username and password.",
            parent=window
        )

        return

    # ======================================================
    # ADMIN LOGIN
    # ======================================================

    if role == "Admin":

        conn = None

        try:

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT admin_id, username
                FROM admin
                WHERE username = ?
                AND password = ?
            """, (
                username,
                password
            ))

            admin = cursor.fetchone()

            if admin:

                messagebox.showinfo(
                    "Login Successful",
                    "Welcome Admin!",
                    parent=window
                )

                open_admin_dashboard(
                    window,
                    clear_login_fields
                )

            else:

                messagebox.showerror(
                    "Login Failed",
                    "Invalid Admin username or password.",
                    parent=window
                )

        except sqlite3.Error as e:

            messagebox.showerror(
                "Database Error",
                "Could not verify Admin login.\n\n" + str(e),
                parent=window
            )

        finally:

            if conn:
                conn.close()

    # ======================================================
    # STUDENT LOGIN
    # ======================================================

    else:

        conn = None

        try:

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT
                    student_id,
                    name,
                    username
                FROM students
                WHERE username = ?
                AND password = ?
            """, (
                username,
                password
            ))

            student = cursor.fetchone()

            if student:

                messagebox.showinfo(
                    "Login Successful",
                    "Welcome " + str(student[1]) + "!",
                    parent=window
                )

                try:

                    from student_dashboard import open_student_dashboard

                    window.withdraw()

                    # IMPORTANT:
                    # parent, student_id, student_name

                    open_student_dashboard(
                        window,
                        student[0],
                        student[1]
                    )

                except Exception as e:

                    window.deiconify()

                    messagebox.showerror(
                        "Student Dashboard Error",
                        "Could not open Student Dashboard.\n\n"
                        + str(e),
                        parent=window
                    )

            else:

                messagebox.showerror(
                    "Login Failed",
                    "Invalid Student username or password.",
                    parent=window
                )

        except sqlite3.Error as e:

            messagebox.showerror(
                "Database Error",
                "Could not verify Student login.\n\n" + str(e),
                parent=window
            )

        finally:

            if conn:
                conn.close()


# ==========================================================
# LOGIN BUTTON
# ==========================================================

login_button = tk.Button(
    content,
    text="LOGIN   →",
    font=("Arial", 13, "bold"),
    bg=BLUE,
    fg=WHITE,
    activebackground=HOVER_BLUE,
    activeforeground=WHITE,
    bd=0,
    relief="flat",
    cursor="hand2",
    height=2,
    command=login
)

login_button.pack(
    fill="x",
    pady=(2, 0)
)


def login_hover_in(event):

    login_button.config(
        bg=HOVER_BLUE,
        font=("Arial", 14, "bold")
    )


def login_hover_out(event):

    login_button.config(
        bg=BLUE,
        font=("Arial", 13, "bold")
    )


login_button.bind(
    "<Enter>",
    login_hover_in
)

login_button.bind(
    "<Leave>",
    login_hover_out
)


# ==========================================================
# ENTER KEY
# ==========================================================

window.bind(
    "<Return>",
    lambda event: login()
)


# ==========================================================
# FOOTER
# ==========================================================

tk.Label(
    content,
    text="Secure access to your college fee information",
    font=("Arial", 9),
    fg="#9AA8B4",
    bg=WHITE
).pack(
    pady=(14, 0)
)


# ==========================================================
# CARD ANIMATION
# ==========================================================

slide_position = 0.58


def slide_card():

    global slide_position

    slide_position -= 0.006

    if slide_position <= 0.5:

        slide_position = 0.5

        card_container.place_configure(
            rely=slide_position
        )

        return

    card_container.place_configure(
        rely=slide_position
    )

    window.after(
        12,
        slide_card
    )


logo_size = 10


def animate_logo():

    global logo_size

    logo_size += 2

    if logo_size >= 40:

        logo_size = 40

        logo.config(
            font=("Segoe UI Emoji", 40)
        )

        return

    logo.config(
        font=("Segoe UI Emoji", logo_size)
    )

    window.after(
        25,
        animate_logo
    )


# ==========================================================
# START APPLICATION
# ==========================================================

initialize_database()

window.after(
    100,
    slide_card
)

window.after(
    250,
    animate_logo
)

window.mainloop()