import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime

DB_NAME = "college_fee_tracker.db"


# ============================================================
# DATABASE
# ============================================================

def get_connection():
    return sqlite3.connect(DB_NAME)


def ensure_payments_table():
    """Create the payments table if it does not already exist."""
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS payments (
                payment_id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL,
                amount REAL NOT NULL,
                payment_date TEXT NOT NULL,
                payment_mode TEXT,
                transaction_id TEXT,
                FOREIGN KEY (student_id)
                    REFERENCES students(student_id)
            )
        """)

        conn.commit()
    finally:
        if conn:
            conn.close()


# ============================================================
# MAIN PAGE
# ============================================================

def show_payment_management_page(parent_frame):
    """
    Display Payment Management inside the existing Admin Dashboard.
    No Toplevel window is created here.
    """

    # Clear the existing admin page
    for widget in parent_frame.winfo_children():
        widget.destroy()

    BG = "#F3F7FB"
    WHITE = "#FFFFFF"
    TEXT = "#263238"
    LIGHT_TEXT = "#607D8B"
    BORDER = "#D6E2EA"
    BLUE = "#1E88E5"
    BLUE_DARK = "#1565C0"
    GREEN = "#2EAD68"
    GREEN_DARK = "#239653"
    RED = "#E53935"
    RED_DARK = "#C62828"
    ORANGE = "#F39C12"
    GREY = "#607D8B"
    GREY_DARK = "#455A64"
    HEADER_BLUE = "#EAF2F8"

    top = parent_frame.winfo_toplevel()

    try:
        ensure_payments_table()
    except sqlite3.Error as e:
        messagebox.showerror(
            "Database Error",
            f"Could not prepare Payment Management.\n\n{e}",
            parent=top
        )
        return

    # ========================================================
    # CONTENT
    # ========================================================

    content = tk.Frame(parent_frame, bg=BG)
    content.pack(fill="both", expand=True, padx=30, pady=22)

    # ========================================================
    # FORM CARD
    # ========================================================

    form_card = tk.Frame(
        content,
        bg=WHITE,
        highlightbackground=BORDER,
        highlightthickness=1
    )
    form_card.pack(fill="x", pady=(0, 18))

    tk.Label(
        form_card,
        text="Record Payment",
        font=("Arial", 15, "bold"),
        bg=WHITE,
        fg=TEXT
    ).pack(anchor="w", padx=25, pady=(17, 12))

    form = tk.Frame(form_card, bg=WHITE)
    form.pack(fill="x", padx=25, pady=(0, 10))

    # Variables
    student_var = tk.StringVar()
    amount_var = tk.StringVar()
    date_var = tk.StringVar(value=datetime.now().strftime("%d-%m-%Y"))
    mode_var = tk.StringVar(value="UPI")
    transaction_var = tk.StringVar()
    pending_var = tk.StringVar(value="Pending Fee: ₹0.00")
    selected_payment_id = tk.StringVar()

    student_map = {}

    def add_label(row, column, text):
        tk.Label(
            form,
            text=text,
            font=("Arial", 10, "bold"),
            bg=WHITE,
            fg=TEXT
        ).grid(
            row=row,
            column=column,
            sticky="w",
            padx=(0, 10),
            pady=7
        )

    add_label(0, 0, "Student")

    student_combo = ttk.Combobox(
        form,
        textvariable=student_var,
        state="readonly",
        width=30,
        font=("Arial", 10)
    )
    student_combo.grid(row=0, column=1, padx=(0, 28), pady=7)

    add_label(0, 2, "Payment Amount")

    amount_entry = tk.Entry(
        form,
        textvariable=amount_var,
        font=("Arial", 10),
        width=28,
        bd=1,
        relief="solid"
    )
    amount_entry.grid(row=0, column=3, pady=7)

    add_label(1, 0, "Payment Date")

    tk.Entry(
        form,
        textvariable=date_var,
        font=("Arial", 10),
        width=32,
        bd=1,
        relief="solid"
    ).grid(row=1, column=1, padx=(0, 28), pady=7)

    add_label(1, 2, "Payment Mode")

    mode_combo = ttk.Combobox(
        form,
        textvariable=mode_var,
        values=("Cash", "UPI", "Card", "Bank Transfer"),
        state="readonly",
        width=26,
        font=("Arial", 10)
    )
    mode_combo.grid(row=1, column=3, pady=7)

    add_label(2, 0, "Transaction ID")

    tk.Entry(
        form,
        textvariable=transaction_var,
        font=("Arial", 10),
        width=32,
        bd=1,
        relief="solid"
    ).grid(row=2, column=1, padx=(0, 28), pady=7)

    tk.Label(
        form,
        textvariable=pending_var,
        font=("Arial", 10, "bold"),
        bg=WHITE,
        fg=ORANGE
    ).grid(row=2, column=3, sticky="w", pady=7)

    # ========================================================
    # HELPERS
    # ========================================================

    def calculate_pending(student_id):
        conn = None
        try:
            conn = get_connection()
            cursor = conn.cursor()

            # Use only columns required by the payment module.
            cursor.execute("""
                SELECT total_fee, paid_fee
                FROM fees
                WHERE student_id = ?
                ORDER BY fee_id DESC
                LIMIT 1
            """, (student_id,))

            row = cursor.fetchone()

            if not row:
                return None

            total_fee = float(row[0] or 0)
            paid_fee = float(row[1] or 0)

            pending = total_fee - paid_fee
            return max(0, pending)

        except sqlite3.Error:
            return None
        finally:
            if conn:
                conn.close()

    def update_pending_fee(event=None):
        selected = student_var.get()

        if not selected:
            pending_var.set("Pending Fee: ₹0.00")
            return

        student_id = student_map.get(selected)

        if not student_id:
            pending_var.set("Pending Fee: ₹0.00")
            return

        pending = calculate_pending(student_id)

        if pending is None:
            pending_var.set("Pending Fee: No Fee Record")
        else:
            pending_var.set(f"Pending Fee: ₹{pending:,.2f}")

    student_combo.bind("<<ComboboxSelected>>", update_pending_fee)

    # ========================================================
    # TABLE CARD
    # ========================================================

    table_card = tk.Frame(
        content,
        bg=WHITE,
        highlightbackground=BORDER,
        highlightthickness=1
    )
    table_card.pack(fill="both", expand=True)

    table_header = tk.Frame(table_card, bg=WHITE)
    table_header.pack(fill="x", padx=25, pady=(16, 10))

    tk.Label(
        table_header,
        text="Payment Transactions",
        font=("Arial", 15, "bold"),
        bg=WHITE,
        fg=TEXT
    ).pack(side="left")

    search_var = tk.StringVar()

    search_box = tk.Frame(table_header, bg=WHITE)
    search_box.pack(side="right")

    tk.Label(
        search_box,
        text="Search:",
        font=("Arial", 10, "bold"),
        bg=WHITE,
        fg=TEXT
    ).pack(side="left", padx=(0, 8))

    search_entry = tk.Entry(
        search_box,
        textvariable=search_var,
        width=25,
        font=("Arial", 10),
        bd=1,
        relief="solid"
    )
    search_entry.pack(side="left", ipady=5)

    # ========================================================
    # TREEVIEW
    # ========================================================

    style = ttk.Style()

    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    style.configure(
        "Payment.Treeview",
        background=WHITE,
        foreground=TEXT,
        fieldbackground=WHITE,
        rowheight=31,
        font=("Arial", 10)
    )

    style.configure(
        "Payment.Treeview.Heading",
        background=HEADER_BLUE,
        foreground=TEXT,
        font=("Arial", 10, "bold"),
        padding=8
    )

    style.map(
        "Payment.Treeview",
        background=[("selected", "#D6EAF8")],
        foreground=[("selected", TEXT)]
    )

    table_frame = tk.Frame(table_card, bg=WHITE)
    table_frame.pack(
        fill="both",
        expand=True,
        padx=25,
        pady=(0, 12)
    )

    columns = (
        "payment_id",
        "student_id",
        "student_name",
        "amount",
        "payment_date",
        "payment_mode",
        "transaction_id"
    )

    tree = ttk.Treeview(
        table_frame,
        columns=columns,
        show="headings",
        selectmode="browse",
        style="Payment.Treeview"
    )

    headings = {
        "payment_id": "Payment ID",
        "student_id": "Student ID",
        "student_name": "Student Name",
        "amount": "Amount",
        "payment_date": "Payment Date",
        "payment_mode": "Payment Mode",
        "transaction_id": "Transaction ID"
    }

    widths = {
        "payment_id": 95,
        "student_id": 90,
        "student_name": 190,
        "amount": 125,
        "payment_date": 125,
        "payment_mode": 140,
        "transaction_id": 190
    }

    for column in columns:
        tree.heading(column, text=headings[column])
        tree.column(
            column,
            width=widths[column],
            anchor="center" if column != "student_name" else "w",
            stretch=True
        )

    scroll_y = ttk.Scrollbar(
        table_frame,
        orient="vertical",
        command=tree.yview
    )
    scroll_x = ttk.Scrollbar(
        table_frame,
        orient="horizontal",
        command=tree.xview
    )

    tree.configure(
        yscrollcommand=scroll_y.set,
        xscrollcommand=scroll_x.set
    )

    tree.grid(row=0, column=0, sticky="nsew")
    scroll_y.grid(row=0, column=1, sticky="ns")
    scroll_x.grid(row=1, column=0, sticky="ew")

    table_frame.grid_rowconfigure(0, weight=1)
    table_frame.grid_columnconfigure(0, weight=1)

    # ========================================================
    # LOAD STUDENTS
    # ========================================================

    def load_students():
        student_map.clear()

        conn = None
        try:
            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT student_id, name
                FROM students
                ORDER BY name COLLATE NOCASE
            """)

            values = []

            for student_id, name in cursor.fetchall():
                display = f"{student_id} - {name}"
                student_map[display] = student_id
                values.append(display)

            student_combo["values"] = values

        except sqlite3.Error as e:
            messagebox.showerror(
                "Database Error",
                f"Could not load students.\n\n{e}",
                parent=top
            )
        finally:
            if conn:
                conn.close()

    # ========================================================
    # LOAD PAYMENTS
    # ========================================================

    def load_payments(search=""):
        for item in tree.get_children():
            tree.delete(item)

        conn = None

        try:
            conn = get_connection()
            cursor = conn.cursor()

            if search.strip():
                value = f"%{search.strip()}%"

                cursor.execute("""
                    SELECT
                        p.payment_id,
                        p.student_id,
                        COALESCE(s.name, 'Unknown'),
                        p.amount,
                        p.payment_date,
                        COALESCE(p.payment_mode, ''),
                        COALESCE(p.transaction_id, '')
                    FROM payments p
                    LEFT JOIN students s
                        ON p.student_id = s.student_id
                    WHERE
                        CAST(p.payment_id AS TEXT) LIKE ?
                        OR CAST(p.student_id AS TEXT) LIKE ?
                        OR s.name LIKE ?
                        OR CAST(p.amount AS TEXT) LIKE ?
                        OR p.payment_date LIKE ?
                        OR p.payment_mode LIKE ?
                        OR p.transaction_id LIKE ?
                    ORDER BY p.payment_id DESC
                """, (value,) * 7)

            else:
                cursor.execute("""
                    SELECT
                        p.payment_id,
                        p.student_id,
                        COALESCE(s.name, 'Unknown'),
                        p.amount,
                        p.payment_date,
                        COALESCE(p.payment_mode, ''),
                        COALESCE(p.transaction_id, '')
                    FROM payments p
                    LEFT JOIN students s
                        ON p.student_id = s.student_id
                    ORDER BY p.payment_id DESC
                """)

            for row in cursor.fetchall():
                amount = float(row[3] or 0)

                tree.insert(
                    "",
                    "end",
                    values=(
                        row[0],
                        row[1],
                        row[2],
                        f"₹{amount:,.2f}",
                        row[4],
                        row[5],
                        row[6]
                    )
                )

        except sqlite3.Error as e:
            messagebox.showerror(
                "Database Error",
                f"Could not load payment records.\n\n{e}",
                parent=top
            )
        finally:
            if conn:
                conn.close()

    # ========================================================
    # CLEAR FORM
    # ========================================================

    def clear_form():
        selected_payment_id.set("")
        student_var.set("")
        amount_var.set("")
        date_var.set(datetime.now().strftime("%d-%m-%Y"))
        mode_var.set("UPI")
        transaction_var.set("")
        pending_var.set("Pending Fee: ₹0.00")
        tree.selection_remove(tree.selection())

    # ========================================================
    # GET SELECTED PAYMENT
    # ========================================================

    def get_selected_payment():
        selected = tree.selection()

        if not selected:
            messagebox.showwarning(
                "No Selection",
                "Please select a payment record first.",
                parent=top
            )
            return None

        return tree.item(selected[0], "values")

    # ========================================================
    # ADD PAYMENT
    # ========================================================

    def add_payment():
        selected_student = student_var.get().strip()
        amount_text = amount_var.get().strip()
        payment_date = date_var.get().strip()
        payment_mode = mode_var.get().strip()
        transaction_id = transaction_var.get().strip()

        if not selected_student:
            messagebox.showwarning(
                "Missing Student",
                "Please select a student.",
                parent=top
            )
            return

        try:
            amount = float(amount_text)
            if amount <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror(
                "Invalid Amount",
                "Please enter a valid payment amount greater than 0.",
                parent=top
            )
            return

        try:
            datetime.strptime(payment_date, "%d-%m-%Y")
        except ValueError:
            messagebox.showerror(
                "Invalid Date",
                "Please use DD-MM-YYYY format.",
                parent=top
            )
            return

        student_id = student_map.get(selected_student)

        if not student_id:
            messagebox.showerror(
                "Invalid Student",
                "Please select a valid student.",
                parent=top
            )
            return

        conn = None

        try:
            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT fee_id, total_fee, paid_fee
                FROM fees
                WHERE student_id = ?
                ORDER BY fee_id DESC
                LIMIT 1
            """, (student_id,))

            fee = cursor.fetchone()

            if not fee:
                messagebox.showerror(
                    "Fee Record Missing",
                    "No fee record exists for this student.\n\n"
                    "Please create the student's fee record first.",
                    parent=top
                )
                return

            fee_id = fee[0]
            total_fee = float(fee[1] or 0)
            paid_fee = float(fee[2] or 0)
            pending_fee = max(0, total_fee - paid_fee)

            if amount > pending_fee:
                messagebox.showerror(
                    "Invalid Payment",
                    f"Payment cannot be greater than the pending fee.\n\n"
                    f"Pending Fee: ₹{pending_fee:,.2f}",
                    parent=top
                )
                return

            cursor.execute("""
                INSERT INTO payments (
                    student_id,
                    amount,
                    payment_date,
                    payment_mode,
                    transaction_id
                )
                VALUES (?, ?, ?, ?, ?)
            """, (
                student_id,
                amount,
                payment_date,
                payment_mode,
                transaction_id
            ))

            new_paid = paid_fee + amount
            new_pending = max(0, total_fee - new_paid)

            if new_pending == 0:
                status = "Paid"
            elif new_paid == 0:
                status = "Pending"
            else:
                status = "Partially Paid"

            # Update only columns that this module requires.
            cursor.execute("""
                UPDATE fees
                SET paid_fee = ?,
                    pending_fee = ?,
                    status = ?
                WHERE fee_id = ?
            """, (
                new_paid,
                new_pending,
                status,
                fee_id
            ))

            conn.commit()

            messagebox.showinfo(
                "Payment Successful",
                "Payment has been recorded successfully.",
                parent=top
            )

            clear_form()
            load_payments()

        except sqlite3.Error as e:
            if conn:
                conn.rollback()

            messagebox.showerror(
                "Database Error",
                f"Could not record payment.\n\n{e}",
                parent=top
            )
        finally:
            if conn:
                conn.close()

    # ========================================================
    # SELECT PAYMENT
    # ========================================================

    def select_payment(event=None):
        selected = tree.selection()

        if not selected:
            return

        values = tree.item(selected[0], "values")

        payment_id = values[0]
        student_id = values[1]

        selected_payment_id.set(payment_id)

        for display, sid in student_map.items():
            if str(sid) == str(student_id):
                student_var.set(display)
                break

        amount_var.set(
            str(values[3]).replace("₹", "").replace(",", "")
        )
        date_var.set(values[4])
        mode_var.set(values[5])
        transaction_var.set(values[6])

        update_pending_fee()

    tree.bind("<<TreeviewSelect>>", select_payment)

    # ========================================================
    # UPDATE PAYMENT
    # ========================================================

    def update_payment():
        values = get_selected_payment()

        if not values:
            return

        payment_id = values[0]

        selected_student = student_var.get().strip()
        amount_text = amount_var.get().strip()
        payment_date = date_var.get().strip()
        payment_mode = mode_var.get().strip()
        transaction_id = transaction_var.get().strip()

        if not selected_student:
            messagebox.showwarning(
                "Missing Student",
                "Please select a student.",
                parent=top
            )
            return

        try:
            new_amount = float(amount_text)
            if new_amount <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror(
                "Invalid Amount",
                "Please enter a valid payment amount greater than 0.",
                parent=top
            )
            return

        try:
            datetime.strptime(payment_date, "%d-%m-%Y")
        except ValueError:
            messagebox.showerror(
                "Invalid Date",
                "Please use DD-MM-YYYY format.",
                parent=top
            )
            return

        new_student_id = student_map.get(selected_student)

        if not new_student_id:
            messagebox.showerror(
                "Invalid Student",
                "Please select a valid student.",
                parent=top
            )
            return

        conn = None

        try:
            conn = get_connection()
            cursor = conn.cursor()

            # Get original payment
            cursor.execute("""
                SELECT student_id, amount
                FROM payments
                WHERE payment_id = ?
            """, (payment_id,))

            old_payment = cursor.fetchone()

            if not old_payment:
                messagebox.showerror(
                    "Payment Not Found",
                    "The selected payment record no longer exists.",
                    parent=top
                )
                return

            old_student_id = old_payment[0]
            old_amount = float(old_payment[1] or 0)

            # Revert the old payment from its student's fee.
            cursor.execute("""
                SELECT fee_id, total_fee, paid_fee
                FROM fees
                WHERE student_id = ?
                ORDER BY fee_id DESC
                LIMIT 1
            """, (old_student_id,))

            old_fee = cursor.fetchone()

            if old_fee:
                old_fee_id = old_fee[0]
                old_total = float(old_fee[1] or 0)
                old_paid = float(old_fee[2] or 0)

                reverted_paid = max(0, old_paid - old_amount)
                reverted_pending = max(0, old_total - reverted_paid)

                if reverted_pending == 0:
                    old_status = "Paid"
                elif reverted_paid == 0:
                    old_status = "Pending"
                else:
                    old_status = "Partially Paid"

                cursor.execute("""
                    UPDATE fees
                    SET paid_fee = ?,
                        pending_fee = ?,
                        status = ?
                    WHERE fee_id = ?
                """, (
                    reverted_paid,
                    reverted_pending,
                    old_status,
                    old_fee_id
                ))

            # Get the destination student's fee after reverting old payment.
            cursor.execute("""
                SELECT fee_id, total_fee, paid_fee
                FROM fees
                WHERE student_id = ?
                ORDER BY fee_id DESC
                LIMIT 1
            """, (new_student_id,))

            new_fee = cursor.fetchone()

            if not new_fee:
                conn.rollback()
                messagebox.showerror(
                    "Fee Record Missing",
                    "The selected student does not have a fee record.",
                    parent=top
                )
                return

            new_fee_id = new_fee[0]
            new_total = float(new_fee[1] or 0)
            new_paid = float(new_fee[2] or 0)
            available = max(0, new_total - new_paid)

            if new_amount > available:
                conn.rollback()

                messagebox.showerror(
                    "Invalid Payment",
                    "The new payment amount is greater than the "
                    "available pending fee.\n\n"
                    f"Available: ₹{available:,.2f}",
                    parent=top
                )
                return

            final_paid = new_paid + new_amount
            final_pending = max(0, new_total - final_paid)

            if final_pending == 0:
                final_status = "Paid"
            elif final_paid == 0:
                final_status = "Pending"
            else:
                final_status = "Partially Paid"

            cursor.execute("""
                UPDATE payments
                SET student_id = ?,
                    amount = ?,
                    payment_date = ?,
                    payment_mode = ?,
                    transaction_id = ?
                WHERE payment_id = ?
            """, (
                new_student_id,
                new_amount,
                payment_date,
                payment_mode,
                transaction_id,
                payment_id
            ))

            cursor.execute("""
                UPDATE fees
                SET paid_fee = ?,
                    pending_fee = ?,
                    status = ?
                WHERE fee_id = ?
            """, (
                final_paid,
                final_pending,
                final_status,
                new_fee_id
            ))

            conn.commit()

            messagebox.showinfo(
                "Updated",
                "Payment record updated successfully.",
                parent=top
            )

            clear_form()
            load_payments()

        except sqlite3.Error as e:
            if conn:
                conn.rollback()

            messagebox.showerror(
                "Database Error",
                f"Could not update payment.\n\n{e}",
                parent=top
            )
        finally:
            if conn:
                conn.close()

    # ========================================================
    # DELETE PAYMENT
    # ========================================================

    def delete_payment():
        values = get_selected_payment()

        if not values:
            return

        payment_id = values[0]
        student_id = values[1]

        try:
            amount = float(
                values[3].replace("₹", "").replace(",", "")
            )
        except ValueError:
            messagebox.showerror(
                "Error",
                "Invalid payment amount.",
                parent=top
            )
            return

        answer = messagebox.askyesno(
            "Delete Payment",
            "Are you sure you want to delete this payment?\n\n"
            f"Payment ID: {payment_id}\n"
            f"Amount: ₹{amount:,.2f}",
            parent=top
        )

        if not answer:
            return

        conn = None

        try:
            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT fee_id, total_fee, paid_fee
                FROM fees
                WHERE student_id = ?
                ORDER BY fee_id DESC
                LIMIT 1
            """, (student_id,))

            fee = cursor.fetchone()

            if fee:
                fee_id = fee[0]
                total_fee = float(fee[1] or 0)
                paid_fee = float(fee[2] or 0)

                new_paid = max(0, paid_fee - amount)
                new_pending = max(0, total_fee - new_paid)

                if new_pending == 0:
                    status = "Paid"
                elif new_paid == 0:
                    status = "Pending"
                else:
                    status = "Partially Paid"

                cursor.execute("""
                    UPDATE fees
                    SET paid_fee = ?,
                        pending_fee = ?,
                        status = ?
                    WHERE fee_id = ?
                """, (
                    new_paid,
                    new_pending,
                    status,
                    fee_id
                ))

            cursor.execute("""
                DELETE FROM payments
                WHERE payment_id = ?
            """, (payment_id,))

            conn.commit()

            messagebox.showinfo(
                "Deleted",
                "Payment deleted successfully.",
                parent=top
            )

            clear_form()
            load_payments()

        except sqlite3.Error as e:
            if conn:
                conn.rollback()

            messagebox.showerror(
                "Database Error",
                f"Could not delete payment.\n\n{e}",
                parent=top
            )
        finally:
            if conn:
                conn.close()

    # ========================================================
    # BUTTONS
    # ========================================================

    button_frame = tk.Frame(form_card, bg=WHITE)
    button_frame.pack(fill="x", padx=25, pady=(3, 18))

    def make_button(text, command, bg, active_bg):
        return tk.Button(
            button_frame,
            text=text,
            command=command,
            font=("Arial", 10, "bold"),
            bg=bg,
            fg=WHITE,
            activebackground=active_bg,
            activeforeground=WHITE,
            bd=0,
            relief="flat",
            padx=18,
            pady=9,
            cursor="hand2"
        )

    make_button(
        "＋  Add Payment",
        add_payment,
        GREEN,
        GREEN_DARK
    ).pack(side="left", padx=(0, 8))

    make_button(
        "✎  Update Selected",
        update_payment,
        BLUE,
        BLUE_DARK
    ).pack(side="left", padx=8)

    make_button(
        "✕  Delete Selected",
        delete_payment,
        RED,
        RED_DARK
    ).pack(side="left", padx=8)

    make_button(
        "⟳  Clear",
        clear_form,
        GREY,
        GREY_DARK
    ).pack(side="left", padx=8)

    make_button(
        "⟳  Refresh",
        lambda: (load_students(), load_payments()),
        ORANGE,
        "#D68910"
    ).pack(side="right")

    # Search
    search_var.trace_add(
        "write",
        lambda *args: load_payments(search_var.get())
    )

    # ========================================================
    # INITIAL LOAD
    # ========================================================

    load_students()
    load_payments()


# ============================================================
# BACKWARD-COMPATIBLE TEST FUNCTION
# ============================================================

def open_payment_management(parent=None):
    """
    Compatibility wrapper.

    Admin Dashboard should use:
        show_payment_management_page(page_container)

    This function is kept only so the module can also be tested
    independently.
    """

    if parent is not None:
        show_payment_management_page(parent)
        return

    window = tk.Tk()
    window.title("College Fee Tracker - Payment Management")
    window.state("zoomed")
    window.configure(bg="#F3F7FB")

    show_payment_management_page(window)

    window.mainloop()


# ============================================================
# DIRECT EXECUTION
# ============================================================

if __name__ == "__main__":
    open_payment_management()
