import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3


# ============================================================
# DATABASE
# ============================================================

DB_NAME = "college_fee_tracker.db"


def get_connection():
    return sqlite3.connect(DB_NAME)


# ============================================================
# ADMIN DASHBOARD
# ============================================================

def open_admin_dashboard(parent=None, clear_login_fields=None):

    # --------------------------------------------------------
    # CREATE ONLY ONE DASHBOARD WINDOW
    # --------------------------------------------------------

    if parent:
        window = tk.Toplevel(parent)
        parent.withdraw()
    else:
        window = tk.Tk()

    window.title("College Fee Tracker - Admin Dashboard")
    window.state("zoomed")
    window.configure(bg="#F3F7FB")

    # ========================================================
    # COLORS
    # ========================================================

    SIDEBAR = "#174A70"
    SIDEBAR_ACTIVE = "#21658F"

    BLUE = "#1976D2"
    GREEN = "#2E8B57"
    ORANGE = "#EF8C00"

    WHITE = "#FFFFFF"
    TEXT = "#1F2937"
    GRAY = "#78909C"
    LIGHT_BG = "#F3F7FB"
    BORDER = "#E1E8EE"

    # ========================================================
    # TREEVIEW STYLE
    # ========================================================

    style = ttk.Style()

    try:
        style.theme_use("clam")
    except Exception:
        pass

    style.configure(
        "Treeview",
        background="white",
        foreground=TEXT,
        fieldbackground="white",
        rowheight=40,
        font=("Arial", 10)
    )

    style.configure(
        "Treeview.Heading",
        background="#EAF2F8",
        foreground=TEXT,
        font=("Arial", 10, "bold"),
        padding=8
    )

    style.map(
        "Treeview",
        background=[
            ("selected", "#DCEEFF")
        ],
        foreground=[
            ("selected", TEXT)
        ]
    )

    # ========================================================
    # MAIN FRAME
    # ========================================================

    main_frame = tk.Frame(
        window,
        bg=LIGHT_BG
    )

    main_frame.pack(
        fill="both",
        expand=True
    )

    # ========================================================
    # SIDEBAR
    # ========================================================

    sidebar = tk.Frame(
        main_frame,
        bg=SIDEBAR,
        width=270
    )

    sidebar.pack(
        side="left",
        fill="y"
    )

    sidebar.pack_propagate(False)

    # ========================================================
    # SIDEBAR LOGO
    # ========================================================

    tk.Label(
        sidebar,
        text="🎓",
        font=("Arial", 38),
        bg=SIDEBAR,
        fg="white"
    ).pack(
        pady=(35, 5)
    )

    tk.Label(
        sidebar,
        text="College Fee Tracker",
        font=("Arial", 19, "bold"),
        bg=SIDEBAR,
        fg="white"
    ).pack()

    tk.Label(
        sidebar,
        text="ADMIN PANEL",
        font=("Arial", 10, "bold"),
        bg=SIDEBAR,
        fg="#B9D4E8"
    ).pack(
        pady=(25, 20)
    )

    # ========================================================
    # RIGHT SIDE
    # ========================================================

    right_frame = tk.Frame(
        main_frame,
        bg=LIGHT_BG
    )

    right_frame.pack(
        side="left",
        fill="both",
        expand=True
    )

    # ========================================================
    # HEADER
    # ========================================================

    header = tk.Frame(
        right_frame,
        bg=WHITE,
        height=105
    )

    header.pack(
        fill="x"
    )

    header.pack_propagate(False)

    # Header title

    header_title_frame = tk.Frame(
        header,
        bg=WHITE
    )

    header_title_frame.pack(
        side="left",
        padx=35,
        pady=15
    )

    page_title_label = tk.Label(
        header_title_frame,
        text="Admin Dashboard",
        font=("Arial", 27, "bold"),
        fg=TEXT,
        bg=WHITE
    )

    page_title_label.pack(
        anchor="w"
    )

    page_subtitle_label = tk.Label(
        header_title_frame,
        text="Manage students, fees and payments",
        font=("Arial", 11),
        fg=GRAY,
        bg=WHITE
    )

    page_subtitle_label.pack(
        anchor="w",
        pady=(3, 0)
    )

    # Administrator

    tk.Label(
        header,
        text="👤   Administrator",
        font=("Arial", 12, "bold"),
        fg=TEXT,
        bg=WHITE
    ).pack(
        side="right",
        padx=25
    )

    # ========================================================
    # PAGE CONTAINER
    # ========================================================

    page_container = tk.Frame(
        right_frame,
        bg=LIGHT_BG
    )

    page_container.pack(
        fill="both",
        expand=True
    )

    # ========================================================
    # SIDEBAR BUTTONS
    # ========================================================

    sidebar_buttons = {}

    def sidebar_button(text, command):

        button = tk.Button(
            sidebar,
            text=text,
            font=("Arial", 13, "bold"),
            bg=SIDEBAR,
            fg="white",
            activebackground=SIDEBAR_ACTIVE,
            activeforeground="white",
            bd=0,
            relief="flat",
            anchor="w",
            padx=30,
            cursor="hand2",
            command=command
        )

        button.pack(
            fill="x",
            ipady=14
        )

        sidebar_buttons[text] = button

        def mouse_enter(event):
            if button.cget("bg") != SIDEBAR_ACTIVE:
                button.configure(
                    bg="#1D5A82"
                )

        def mouse_leave(event):
            if button.cget("bg") != SIDEBAR_ACTIVE:
                button.configure(
                    bg=SIDEBAR
                )

        button.bind(
            "<Enter>",
            mouse_enter
        )

        button.bind(
            "<Leave>",
            mouse_leave
        )

        return button

    # ========================================================
    # PAGE CLEAR
    # ========================================================

    def clear_page():

        for widget in page_container.winfo_children():
            widget.destroy()

    # ========================================================
    # UPDATE ACTIVE SIDEBAR BUTTON
    # ========================================================

    def set_active_button(selected_text):

        for text, button in sidebar_buttons.items():

            if text == selected_text:
                button.configure(
                    bg=SIDEBAR_ACTIVE
                )
            else:
                button.configure(
                    bg=SIDEBAR
                )

    # ========================================================
    # HEADER UPDATE
    # ========================================================

    def update_header(title, subtitle):

        page_title_label.configure(
            text=title
        )

        page_subtitle_label.configure(
            text=subtitle
        )

    # ========================================================
    # DATABASE DATA
    # ========================================================

    def get_dashboard_data():

        data = {
            "students": 0,
            "total_fees": 0,
            "collected": 0,
            "pending": 0,
            "payments": []
        }

        connection = None

        try:

            connection = get_connection()
            cursor = connection.cursor()

            # Total students

            cursor.execute(
                """
                SELECT COUNT(*)
                FROM students
                """
            )

            result = cursor.fetchone()

            if result:
                data["students"] = result[0] or 0

            # Total fees

            cursor.execute(
                """
                SELECT COALESCE(SUM(total_fee), 0)
                FROM fees
                """
            )

            result = cursor.fetchone()

            if result:
                data["total_fees"] = result[0] or 0

            # Fees collected

            cursor.execute(
                """
                SELECT COALESCE(SUM(paid_fee), 0)
                FROM fees
                """
            )

            result = cursor.fetchone()

            if result:
                data["collected"] = result[0] or 0

            # Pending fees

            cursor.execute(
                """
                SELECT COALESCE(SUM(pending_fee), 0)
                FROM fees
                """
            )

            result = cursor.fetchone()

            if result:
                data["pending"] = result[0] or 0

            # Check payments table

            cursor.execute(
                """
                SELECT name
                FROM sqlite_master
                WHERE type='table'
                AND name='payments'
                """
            )

            payments_table = cursor.fetchone()

            if payments_table:

                cursor.execute(
                    """
                    SELECT
                        p.payment_id,
                        s.name,
                        p.amount,
                        p.payment_date,
                        p.payment_mode
                    FROM payments p
                    LEFT JOIN students s
                        ON p.student_id = s.student_id
                    ORDER BY p.payment_id DESC
                    LIMIT 5
                    """
                )

                data["payments"] = cursor.fetchall()

        except sqlite3.Error as e:

            messagebox.showerror(
                "Database Error",
                f"Could not load dashboard data.\n\n{e}",
                parent=window
            )

        finally:

            if connection:
                connection.close()

        return data

    # ========================================================
    # STAT CARD
    # ========================================================

    def create_stat_card(
        parent_widget,
        title,
        value,
        icon,
        accent
    ):

        card = tk.Frame(
            parent_widget,
            bg=WHITE,
            height=145,
            highlightbackground=BORDER,
            highlightthickness=1
        )

        card.pack(
            side="left",
            fill="both",
            expand=True,
            padx=7
        )

        tk.Frame(
            card,
            bg=accent,
            width=5
        ).pack(
            side="left",
            fill="y"
        )

        inner = tk.Frame(
            card,
            bg=WHITE
        )

        inner.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=15
        )

        tk.Label(
            inner,
            text=icon,
            font=("Arial", 24),
            bg=WHITE,
            fg=accent
        ).pack(
            side="left",
            padx=(0, 15)
        )

        text_frame = tk.Frame(
            inner,
            bg=WHITE
        )

        text_frame.pack(
            side="left",
            fill="both",
            expand=True
        )

        tk.Label(
            text_frame,
            text=title,
            font=("Arial", 11),
            fg=GRAY,
            bg=WHITE
        ).pack(
            anchor="w"
        )

        value_label = tk.Label(
            text_frame,
            text=value,
            font=("Arial", 23, "bold"),
            fg=TEXT,
            bg=WHITE
        )

        value_label.pack(
            anchor="w",
            pady=(8, 0)
        )

        return value_label

    # ========================================================
    # DASHBOARD PAGE
    # ========================================================

    def show_dashboard():

        clear_page()

        set_active_button("⌂   Dashboard")

        update_header(
            "Admin Dashboard",
            "Manage students, fees and payments"
        )

        body = tk.Frame(
            page_container,
            bg=LIGHT_BG
        )

        body.pack(
            fill="both",
            expand=True,
            padx=35,
            pady=30
        )

        # ----------------------------------------------------
        # OVERVIEW
        # ----------------------------------------------------

        tk.Label(
            body,
            text="Overview",
            font=("Arial", 23, "bold"),
            fg=TEXT,
            bg=LIGHT_BG
        ).pack(
            anchor="w",
            pady=(0, 15)
        )

        # ----------------------------------------------------
        # STATISTICS
        # ----------------------------------------------------

        stats_frame = tk.Frame(
            body,
            bg=LIGHT_BG
        )

        stats_frame.pack(
            fill="x"
        )

        dashboard_data = get_dashboard_data()

        students_value = create_stat_card(
            stats_frame,
            "Total Students",
            str(dashboard_data["students"]),
            "♟",
            BLUE
        )

        total_fees_value = create_stat_card(
            stats_frame,
            "Total Fees",
            f"₹{dashboard_data['total_fees']:,.0f}",
            "₹",
            GREEN
        )

        collected_value = create_stat_card(
            stats_frame,
            "Fees Collected",
            f"₹{dashboard_data['collected']:,.0f}",
            "▣",
            BLUE
        )

        pending_value = create_stat_card(
            stats_frame,
            "Pending Fees",
            f"₹{dashboard_data['pending']:,.0f}",
            "⚠",
            ORANGE
        )

        # ----------------------------------------------------
        # LOWER AREA
        # ----------------------------------------------------

        lower_frame = tk.Frame(
            body,
            bg=LIGHT_BG
        )

        lower_frame.pack(
            fill="both",
            expand=True,
            pady=(25, 0)
        )

        # ----------------------------------------------------
        # RECENT PAYMENTS
        # ----------------------------------------------------

        recent_card = tk.Frame(
            lower_frame,
            bg=WHITE,
            highlightbackground=BORDER,
            highlightthickness=1
        )

        recent_card.pack(
            side="left",
            fill="both",
            expand=True,
            padx=(0, 10)
        )

        tk.Label(
            recent_card,
            text="Recent Payments",
            font=("Arial", 18, "bold"),
            fg=TEXT,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=20,
            pady=(20, 3)
        )

        tk.Label(
            recent_card,
            text="Latest fee transactions recorded in the system",
            font=("Arial", 10),
            fg=GRAY,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=20,
            pady=(0, 15)
        )

        payment_frame = tk.Frame(
            recent_card,
            bg=WHITE
        )

        payment_frame.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=(0, 20)
        )

        payment_columns = (
            "student",
            "amount",
            "date",
            "mode"
        )

        payment_tree = ttk.Treeview(
            payment_frame,
            columns=payment_columns,
            show="headings",
            height=7
        )

        payment_tree.heading(
            "student",
            text="Student"
        )

        payment_tree.heading(
            "amount",
            text="Amount"
        )

        payment_tree.heading(
            "date",
            text="Date"
        )

        payment_tree.heading(
            "mode",
            text="Payment Mode"
        )

        payment_tree.column(
            "student",
            width=230,
            anchor="center"
        )

        payment_tree.column(
            "amount",
            width=160,
            anchor="center"
        )

        payment_tree.column(
            "date",
            width=150,
            anchor="center"
        )

        payment_tree.column(
            "mode",
            width=150,
            anchor="center"
        )

        payment_scrollbar = ttk.Scrollbar(
            payment_frame,
            orient="vertical",
            command=payment_tree.yview
        )

        payment_tree.configure(
            yscrollcommand=payment_scrollbar.set
        )

        payment_tree.pack(
            side="left",
            fill="both",
            expand=True
        )

        payment_scrollbar.pack(
            side="right",
            fill="y"
        )

        # Load payments

        if not dashboard_data["payments"]:

            payment_tree.insert(
                "",
                "end",
                values=(
                    "No payment transactions",
                    "-",
                    "-",
                    "-"
                )
            )

        else:

            for row in dashboard_data["payments"]:

                student_name = row[1] or "Unknown Student"
                amount = row[2] or 0
                payment_date = row[3] or "-"
                payment_mode = row[4] or "-"

                payment_tree.insert(
                    "",
                    "end",
                    values=(
                        student_name,
                        f"₹{amount:,.2f}",
                        payment_date,
                        payment_mode
                    )
                )

        # ----------------------------------------------------
        # QUICK ACTIONS
        # ----------------------------------------------------

        quick_card = tk.Frame(
            lower_frame,
            bg=WHITE,
            width=320,
            highlightbackground=BORDER,
            highlightthickness=1
        )

        quick_card.pack(
            side="right",
            fill="y",
            padx=(10, 0)
        )

        quick_card.pack_propagate(False)

        tk.Label(
            quick_card,
            text="Quick Actions",
            font=("Arial", 18, "bold"),
            fg=TEXT,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=25,
            pady=(25, 3)
        )

        tk.Label(
            quick_card,
            text="Frequently used operations",
            font=("Arial", 10),
            fg=GRAY,
            bg=WHITE
        ).pack(
            anchor="w",
            padx=25,
            pady=(0, 20)
        )

        def quick_button(text, command):

            button = tk.Button(
                quick_card,
                text=text,
                font=("Arial", 11, "bold"),
                bg="#F1F6FA",
                fg=TEXT,
                activebackground="#DCEEFF",
                activeforeground=TEXT,
                bd=0,
                anchor="w",
                padx=20,
                cursor="hand2",
                command=command
            )

            button.pack(
                fill="x",
                padx=20,
                pady=5,
                ipady=10
            )

        quick_button(
            "＋   Add Student",
            show_students
        )

        quick_button(
            "▣   Record Payment",
            show_payments
        )

        quick_button(
            "▧   Generate Receipt",
            show_receipts
        )

        quick_button(
            "▣   View Reports",
            show_reports
        )

    # ========================================================
    # INTERNAL PAGE LOADER
    # ========================================================

    def load_internal_page(
        module_name,
        function_name,
        title,
        subtitle,
        button_name
    ):

        clear_page()

        set_active_button(button_name)

        update_header(
            title,
            subtitle
        )

        try:

            module = __import__(module_name)

            page_function = getattr(
                module,
                function_name
            )

            # The new internal-page functions will receive
            # the page_container instead of creating a Toplevel.

            page_function(
                page_container
            )

        except ImportError as e:

            messagebox.showerror(
                "Module Error",
                f"Could not load {module_name}.py\n\n{e}",
                parent=window
            )

            show_dashboard()

        except AttributeError:

            messagebox.showerror(
                "Page Function Missing",
                (
                    f"{module_name}.py does not yet contain "
                    f"the internal page function:\n\n"
                    f"{function_name}()\n\n"
                    f"We need to convert that module to the "
                    f"one-window layout."
                ),
                parent=window
            )

            show_dashboard()

        except Exception as e:

            messagebox.showerror(
                "Page Error",
                f"Could not open {title}.\n\n{e}",
                parent=window
            )

            show_dashboard()

    # ========================================================
    # STUDENTS
    # ========================================================

    def show_students():

        load_internal_page(
            "student_management",
            "show_student_management_page",
            "Student Management",
            "Add, update, delete and manage student records",
            "♟   Students"
        )

    # ========================================================
    # FEES
    # ========================================================

    def show_fees():

        load_internal_page(
            "fee_management",
            "show_fee_management_page",
            "Fee Management",
            "Manage student fee records and pending balances",
            "₹   Fees"
        )

    # ========================================================
    # PAYMENTS
    # ========================================================

    def show_payments():

        load_internal_page(
            "payment_management",
            "show_payment_management_page",
            "Payment Management",
            "Record and manage student payments",
            "▤   Payments"
        )

    # ========================================================
    # RECEIPTS
    # ========================================================

    def show_receipts():

        load_internal_page(
            "receipt_management",
            "show_receipt_management_page",
            "Receipt Management",
            "View and generate student payment receipts",
            "▧   Receipts"
        )

    # ========================================================
    # REPORTS
    # ========================================================

    def show_reports():

        load_internal_page(
            "reports",
            "show_reports_page",
            "Reports",
            "View fee, payment and student reports",
            "▣   Reports"
        )

    # ========================================================
    # SETTINGS
    # ========================================================

    def show_settings():

        load_internal_page(
            "settings",
            "show_settings_page",
            "Settings",
            "Manage administrator settings",
            "⚙   Settings"
        )

    # ========================================================
    # SIDEBAR MENU
    # ========================================================

    sidebar_button(
        "⌂   Dashboard",
        command=show_dashboard
    )

    sidebar_button(
        "♟   Students",
        command=show_students
    )

    sidebar_button(
        "₹   Fees",
        command=show_fees
    )

    sidebar_button(
        "▤   Payments",
        command=show_payments
    )

    sidebar_button(
        "▧   Receipts",
        command=show_receipts
    )

    sidebar_button(
        "▣   Reports",
        command=show_reports
    )

    sidebar_button(
        "⚙   Settings",
        command=show_settings
    )

    # ========================================================
    # LOGOUT
    # ========================================================

    logout_frame = tk.Frame(
        sidebar,
        bg=SIDEBAR
    )

    logout_frame.pack(
        side="bottom",
        fill="x"
    )

    def logout():

        answer = messagebox.askyesno(
            "Logout",
            "Are you sure you want to logout?",
            parent=window
        )

        if answer:

            window.destroy()

            if parent:

                parent.deiconify()

                try:
                    parent.state("zoomed")
                except Exception:
                    pass

                if clear_login_fields:
                    clear_login_fields()

    logout_button = tk.Button(
        logout_frame,
        text="↪   Logout",
        font=("Arial", 13, "bold"),
        bg=SIDEBAR,
        fg="white",
        activebackground="#1D5A82",
        activeforeground="white",
        bd=0,
        anchor="w",
        padx=30,
        cursor="hand2",
        command=logout
    )

    logout_button.pack(
        fill="x",
        ipady=15
    )

    # ========================================================
    # CLOSE WINDOW
    # ========================================================

    def close_dashboard():

        if parent:

            window.destroy()

            parent.deiconify()

            try:
                parent.state("zoomed")
            except Exception:
                pass

        else:

            window.destroy()

    window.protocol(
        "WM_DELETE_WINDOW",
        close_dashboard
    )

    # ========================================================
    # START WITH DASHBOARD PAGE
    # ========================================================

    show_dashboard()

    # ========================================================
    # RUN DIRECTLY
    # ========================================================

    if not parent:
        window.mainloop()


# ============================================================
# TEST DIRECTLY
# ============================================================

if __name__ == "__main__":
    open_admin_dashboard()